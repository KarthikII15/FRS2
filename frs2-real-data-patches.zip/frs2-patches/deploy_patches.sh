#!/bin/bash
# ============================================================
# Deploy real-data patches to FRS2 frontend
# Run this on the VM (172.20.100.222)
# Usage: bash deploy_patches.sh /path/to/patches
# ============================================================
set -e

PROJECT="$HOME/FRS_/FRS--Java-Verison"
PATCHES_DIR="$(dirname "$(readlink -f "$0")")"

echo ""
echo "=================================================="
echo " Deploying real-data patches"
echo "=================================================="
echo ""

# ── 1. Copy new hook ──────────────────────────────────────
echo "[1/4] Copying useApiData hook..."
cp "$PATCHES_DIR/src/app/hooks/useApiData.ts" \
   "$PROJECT/src/app/hooks/useApiData.ts"
echo "  ✅ src/app/hooks/useApiData.ts"

# ── 2. Copy patched components ────────────────────────────
echo ""
echo "[2/4] Copying patched components..."

cp "$PATCHES_DIR/src/app/components/AdminDashboard.tsx" \
   "$PROJECT/src/app/components/AdminDashboard.tsx"
echo "  ✅ AdminDashboard.tsx"

cp "$PATCHES_DIR/src/app/components/hr/PresenceMonitor.tsx" \
   "$PROJECT/src/app/components/hr/PresenceMonitor.tsx"
echo "  ✅ hr/PresenceMonitor.tsx"

cp "$PATCHES_DIR/src/app/components/hr/AttendanceStatusDashboard.tsx" \
   "$PROJECT/src/app/components/hr/AttendanceStatusDashboard.tsx"
echo "  ✅ hr/AttendanceStatusDashboard.tsx"

# ── 3. Rebuild frontend container ─────────────────────────
echo ""
echo "[3/4] Rebuilding frontend container..."
cd "$PROJECT"
docker compose build frontend
docker compose up -d frontend

echo ""
echo "[4/4] Waiting for frontend to be ready..."
sleep 8
STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://172.20.100.222:5173 2>/dev/null || echo "000")
if [ "$STATUS" = "200" ]; then
  echo "  ✅ Frontend rebuilt and running"
else
  echo "  ⚠️  Frontend returned HTTP $STATUS — check logs:"
  echo "     docker compose logs --tail=20 frontend"
fi

echo ""
echo "=================================================="
echo " ✅ Patches deployed"
echo "=================================================="
echo ""
echo "What changed:"
echo "  • AdminDashboard    → real devices, alerts, accuracy from /api/live/devices"
echo "  • PresenceMonitor   → real today's attendance from /api/live/attendance"
echo "  • AttendanceStatus  → real present/absent/late from /api/live/attendance"
echo "  • useApiData hook   → central auto-refreshing data hook (30s interval)"
echo ""
echo "Open: http://172.20.100.222:5173"
echo "Hard refresh: Ctrl+Shift+R"
echo ""
