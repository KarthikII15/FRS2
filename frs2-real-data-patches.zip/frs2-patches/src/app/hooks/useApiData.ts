/**
 * useApiData.ts
 * 
 * Central hook that fetches ALL live data from the backend APIs.
 * Replaces every mockEmployees / mockDevices / mockAlerts import.
 * 
 * Endpoints used:
 *   GET /api/live/employees   → employees list
 *   GET /api/live/attendance  → attendance records
 *   GET /api/live/devices     → facility devices
 *   GET /api/live/alerts      → system alerts
 *   GET /api/live/metrics     → dashboard KPI metrics
 *   GET /api/attendance/today → who is present right now
 *   GET /api/employees        → full employee list with face_enrolled flag
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { apiRequest } from '../services/http/apiClient';
import { useAuth } from '../contexts/AuthContext';
import { useScopeHeaders } from './useScopeHeaders';
import { authConfig } from '../config/authConfig';

// ── Types ────────────────────────────────────────────────────────────────────

export interface LiveEmployee {
  pk_employee_id: number;
  employee_code: string;
  full_name: string;
  email: string;
  position_title: string;
  location_label: string;
  join_date: string;
  status: 'active' | 'inactive' | 'on-leave';
  department_name: string;
  shift_type: string;
  face_enrolled?: boolean;
}

export interface LiveAttendanceRecord {
  pk_attendance_id: number;
  fk_employee_id: number;
  employee_code: string;
  full_name: string;
  attendance_date: string;
  check_in: string | null;
  check_out: string | null;
  break_start: string | null;
  break_end: string | null;
  status: 'present' | 'late' | 'absent' | 'on-leave' | 'on-break';
  working_hours: number;
  break_duration_minutes: number;
  overtime_hours: number;
  is_late: boolean;
  is_early_departure: boolean;
  device_id: string | null;
  location_label: string | null;
  recognition_accuracy: number | null;
}

export interface LiveDevice {
  pk_device_id: number;
  external_device_id: string;
  name: string;
  location_label: string;
  ip_address: string;
  status: 'online' | 'offline' | 'error';
  recognition_accuracy: number;
  total_scans: number;
  error_rate: number;
  model: string;
  last_active: string;
}

export interface LiveAlert {
  pk_alert_id: number;
  alert_type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  message: string;
  fk_employee_id: number | null;
  employee_code: string | null;
  fk_device_id: number | null;
  external_device_id: string | null;
  is_read: boolean;
  created_at: string;
}

export interface DashboardMetrics {
  totalEmployees: number;
  presentToday: number;
  lateToday: number;
  absentToday: number;
  onBreak: number;
  onLeave: number;
  avgWorkingHours: number;
  totalOvertimeHours: number;
  attendanceRate: number;
  punctualityRate: number;
}

export interface ApiDataState {
  employees: LiveEmployee[];
  attendance: LiveAttendanceRecord[];
  devices: LiveDevice[];
  alerts: LiveAlert[];
  metrics: DashboardMetrics | null;
  isLoading: boolean;
  error: string | null;
  lastRefreshed: Date | null;
}

const EMPTY_METRICS: DashboardMetrics = {
  totalEmployees: 0,
  presentToday: 0,
  lateToday: 0,
  absentToday: 0,
  onBreak: 0,
  onLeave: 0,
  avgWorkingHours: 0,
  totalOvertimeHours: 0,
  attendanceRate: 0,
  punctualityRate: 0,
};

// ── Hook ─────────────────────────────────────────────────────────────────────

export function useApiData(options: {
  autoRefreshMs?: number;  // default 30000 (30s)
  fetchMetrics?: boolean;  // default true
} = {}) {
  const { accessToken } = useAuth();
  const scopeHeaders = useScopeHeaders();
  const { autoRefreshMs = 30000, fetchMetrics = true } = options;

  const [state, setState] = useState<ApiDataState>({
    employees: [],
    attendance: [],
    devices: [],
    alerts: [],
    metrics: null,
    isLoading: true,
    error: null,
    lastRefreshed: null,
  });

  const isMountedRef = useRef(true);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchAll = useCallback(async () => {
    // In mock mode, return empty — mock data stays in the mock files
    if (authConfig.mode === 'mock') {
      setState(prev => ({ ...prev, isLoading: false }));
      return;
    }

    if (!accessToken) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: 'Not authenticated',
      }));
      return;
    }

    setState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      const opts = { accessToken, scopeHeaders };

      const fetches: Promise<any>[] = [
        apiRequest<{ data: LiveEmployee[] }>('/live/employees', opts),
        apiRequest<{ data: LiveAttendanceRecord[] }>('/live/attendance?limit=500', opts),
        apiRequest<{ data: LiveDevice[] }>('/live/devices', opts),
        apiRequest<{ data: LiveAlert[] }>('/live/alerts', opts),
      ];

      if (fetchMetrics) {
        fetches.push(apiRequest<DashboardMetrics>('/live/metrics', opts));
      }

      const results = await Promise.allSettled(fetches);

      const getValue = <T>(r: PromiseSettledResult<any>, fallback: T): T =>
        r.status === 'fulfilled' ? r.value : fallback;

      const employeesRes  = getValue(results[0], { data: [] });
      const attendanceRes = getValue(results[1], { data: [] });
      const devicesRes    = getValue(results[2], { data: [] });
      const alertsRes     = getValue(results[3], { data: [] });
      const metricsRes    = fetchMetrics ? getValue(results[4], EMPTY_METRICS) : EMPTY_METRICS;

      if (isMountedRef.current) {
        setState({
          employees:  employeesRes.data  ?? [],
          attendance: attendanceRes.data ?? [],
          devices:    devicesRes.data    ?? [],
          alerts:     alertsRes.data     ?? [],
          metrics:    metricsRes,
          isLoading:  false,
          error:      null,
          lastRefreshed: new Date(),
        });
      }
    } catch (err) {
      if (isMountedRef.current) {
        setState(prev => ({
          ...prev,
          isLoading: false,
          error: err instanceof Error ? err.message : 'Failed to fetch data',
        }));
      }
    }
  }, [accessToken, scopeHeaders, fetchMetrics]);

  // Initial fetch
  useEffect(() => {
    isMountedRef.current = true;
    fetchAll();
    return () => {
      isMountedRef.current = false;
    };
  }, [fetchAll]);

  // Auto-refresh
  useEffect(() => {
    if (autoRefreshMs > 0) {
      timerRef.current = setInterval(fetchAll, autoRefreshMs);
      return () => {
        if (timerRef.current) clearInterval(timerRef.current);
      };
    }
  }, [fetchAll, autoRefreshMs]);

  return { ...state, refresh: fetchAll };
}
