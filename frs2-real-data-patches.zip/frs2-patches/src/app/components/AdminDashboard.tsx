import React, { useEffect, useMemo, useState } from 'react';
import { Sidebar } from './shared/Sidebar';
import { MobileNav } from './shared/MobileNav';
import { MetricCard } from './shared/MetricCard';
import {
  Users,
  Monitor,
  Activity,
  FileText,
  Settings,
  Database,
  AlertCircle,
  Building2,
  ShieldCheck,
  RefreshCw,
  Loader2,
} from 'lucide-react';
import { UserManagement } from './admin/UserManagement';
import { SystemHealth } from './admin/SystemHealth';
import { OperationsConsole } from './admin/OperationsConsole';
import { AuditLogs } from './admin/AuditLogs';
import { AccuracyLogs } from './admin/AccuracyLogs';
import { LiveOfficeIntelligence } from './hr/LiveOfficeIntelligence';
import { Map, Activity as ActivityIcon } from 'lucide-react';
import { lightTheme } from '../../theme/lightTheme';
import { cn } from './ui/utils';
import { useAuth } from '../contexts/AuthContext';
import { useApiData } from '../hooks/useApiData';
import { Button } from './ui/button';
import { toast } from 'sonner';

export const AdminDashboard: React.FC = () => {
  const { can } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  // ── Real data from backend ────────────────────────────────────────────────
  const { employees, devices, alerts, metrics, isLoading, error, refresh, lastRefreshed } = useApiData({
    autoRefreshMs: 30000,
  });

  const navigationItems = [
    { label: 'Overview', icon: Activity, value: 'overview', permission: 'devices.read' as const },
    { label: 'Users', icon: Users, value: 'users', permission: 'users.read' as const },
    { label: 'Operations Console', icon: Building2, value: 'operations', permission: 'facility.manage' as const },
    { label: 'Live Office Intelligence', icon: ActivityIcon, value: 'presence-monitor', permission: 'attendance.read' as const },
    { label: 'Accuracy', icon: Database, value: 'accuracy', permission: 'devices.read' as const },
    { label: 'Audit Logs', icon: FileText, value: 'audit', permission: 'audit.read' as const },
  ];

  const visibleNavigationItems = useMemo(
    () => navigationItems.filter((item) => !item.permission || can(item.permission)),
    [can]
  );

  useEffect(() => {
    if (!visibleNavigationItems.some((item) => item.value === activeTab)) {
      setActiveTab(visibleNavigationItems[0]?.value ?? 'overview');
    }
  }, [activeTab, visibleNavigationItems]);

  // ── Derived metrics from real data ────────────────────────────────────────
  const onlineDevices  = devices.filter(d => d.status === 'online').length;
  const offlineDevices = devices.filter(d => d.status === 'offline').length;
  const errorDevices   = devices.filter(d => d.status === 'error').length;
  const criticalAlerts = alerts.filter(a => a.severity === 'critical' || a.severity === 'high').length;
  const unreadAlerts   = alerts.filter(a => !a.is_read).length;
  const avgAccuracy    = devices.length > 0
    ? devices.reduce((sum, d) => sum + (d.recognition_accuracy || 0), 0) / devices.length
    : 0;

  // ── Map live devices to shape SystemHealth + AccuracyLogs expect ──────────
  const mappedDevices = devices.map(d => ({
    id: d.external_device_id,
    name: d.name,
    type: 'Camera' as const,
    status: d.status === 'online' ? 'Online' : d.status === 'error' ? 'Warning' : 'Offline',
    location: d.location_label,
    assignedPoint: d.location_label,
    lastActive: d.last_active,
    ipAddress: d.ip_address,
    recognitionAccuracy: d.recognition_accuracy,
    totalScans: d.total_scans,
    errorRate: d.error_rate,
    model: d.model,
  }));

  // Map live alerts to shape AuditLogs / SystemHealth expect
  const mappedAlerts = alerts.map(a => ({
    id: String(a.pk_alert_id),
    type: a.alert_type,
    severity: a.severity,
    title: a.title,
    message: a.message,
    deviceId: a.external_device_id,
    employeeId: a.employee_code,
    read: a.is_read,
    timestamp: a.created_at,
  }));

  const handleRefresh = () => {
    refresh();
    toast.success('Dashboard refreshed');
  };

  const renderContent = () => {
    if (isLoading && devices.length === 0) {
      return (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          <span className="ml-3 text-slate-400">Loading live data...</span>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <AlertCircle className="w-10 h-10 text-red-400" />
          <p className="text-slate-400 text-sm">{error}</p>
          <Button variant="outline" size="sm" onClick={handleRefresh}>Retry</Button>
        </div>
      );
    }

    switch (activeTab) {
      case 'overview':
        return <SystemHealth devices={mappedDevices as any} alerts={mappedAlerts as any} />;
      case 'users':
        return <UserManagement users={[]} employees={employees as any} />;
      case 'operations':
        return <OperationsConsole />;
      case 'presence-monitor':
        return <LiveOfficeIntelligence role="admin" />;
      case 'accuracy':
        return <AccuracyLogs devices={mappedDevices as any} />;
      case 'audit':
        return <AuditLogs logs={mappedAlerts as any} />;
      default:
        return null;
    }
  };

  return (
    <div className={cn("min-h-screen", lightTheme.background.primary, "dark:bg-background")}>
      <Sidebar
        role="admin"
        activeTab={activeTab}
        onTabChange={setActiveTab}
        navigationItems={visibleNavigationItems}
        alerts={unreadAlerts}
      />
      <MobileNav
        role="admin"
        activeTab={activeTab}
        onTabChange={setActiveTab}
        navigationItems={visibleNavigationItems}
      />
      <main className="lg:pl-64 min-h-screen">
        <div className="p-6 lg:p-8">

          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className={cn("text-2xl font-bold", lightTheme.text.primary)}>Admin Dashboard</h1>
              {lastRefreshed && (
                <p className="text-xs text-slate-500 mt-1">
                  Last updated: {lastRefreshed.toLocaleTimeString()}
                </p>
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={isLoading}
              className="gap-2"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4" />
              )}
              Refresh
            </Button>
          </div>

          {/* Live KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <MetricCard
              title="Total Devices"
              value={String(devices.length)}
              icon={Monitor}
              trend={onlineDevices > 0 ? `${onlineDevices} online` : 'All offline'}
              trendUp={onlineDevices > 0}
            />
            <MetricCard
              title="Online Devices"
              value={String(onlineDevices)}
              icon={Activity}
              trend={offlineDevices > 0 ? `${offlineDevices} offline` : 'All healthy'}
              trendUp={offlineDevices === 0}
            />
            <MetricCard
              title="Critical Alerts"
              value={String(criticalAlerts)}
              icon={AlertCircle}
              trend={`${unreadAlerts} unread`}
              trendUp={criticalAlerts === 0}
            />
            <MetricCard
              title="Avg Accuracy"
              value={`${avgAccuracy.toFixed(1)}%`}
              icon={ShieldCheck}
              trend={errorDevices > 0 ? `${errorDevices} error` : 'All nominal'}
              trendUp={errorDevices === 0}
            />
          </div>

          {/* Main content */}
          {renderContent()}
        </div>
      </main>
    </div>
  );
};
