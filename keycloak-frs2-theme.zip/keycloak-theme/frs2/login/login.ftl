<#import "template.ftl" as layout>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>FaceRecog Attendance — Enterprise Login</title>
  <link rel="stylesheet" href="${url.resourcesPath}/css/login.css" />
</head>
<body>

  <!-- Top Bar -->
  <header class="topbar">
    <div class="topbar-logo">
      <div class="logo-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 3H5a2 2 0 0 0-2 2v4"/>
          <path d="M15 3h4a2 2 0 0 1 2 2v4"/>
          <path d="M9 21H5a2 2 0 0 1-2-2v-4"/>
          <path d="M15 21h4a2 2 0 0 0 2-2v-4"/>
          <circle cx="12" cy="12" r="3"/>
        </svg>
      </div>
      <span class="logo-text">FACERECOG ATTENDANCE</span>
    </div>
    <div class="topbar-right">
      <a href="#" class="support-link">SUPPORT</a>
    </div>
  </header>

  <!-- Main Layout -->
  <div class="main-layout">

    <!-- Left — Branding -->
    <div class="left-panel">
      <div class="left-bg-glow"></div>
      <div class="left-content">

        <div class="ai-badge">
          <span class="ai-dot"></span>
          <span class="ai-label">AI ENGINE ACTIVE</span>
        </div>

        <h1 class="hero-title">
          FaceMatch<br/>
          <span class="hero-gradient">Identity.</span>
        </h1>

        <p class="hero-desc">
          Enterprise-grade attendance tracking via advanced facial
          recognition. Seamlessly identify, verify, and monitor your
          workforce with zero-friction biometrics.
        </p>

        <div class="stats-row">
          <div class="stat">
            <div class="stat-number">98.4%</div>
            <div class="stat-label">ACCURACY<br/>FACE RECOGNITION</div>
          </div>
          <div class="stat">
            <div class="stat-number">&lt;10ms</div>
            <div class="stat-label">LATENCY<br/>EDGE RESPONSE</div>
          </div>
          <div class="stat">
            <div class="stat-number">SOC2</div>
            <div class="stat-label">COMPLIANCE<br/>DATA PRIVACY</div>
          </div>
        </div>

      </div>
    </div>

    <!-- Right — Login Form -->
    <div class="right-panel">
      <div class="form-container">

        <div class="form-header">
          <h2 class="form-title">Enterprise Login</h2>
          <p class="form-subtitle">Welcome back. Please authenticate to continue.</p>
        </div>

        <#if message?has_content && message.type != "success">
        <div class="alert alert-${message.type}">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <span>${kcSanitize(message.summary)?no_esc}</span>
        </div>
        </#if>

        <form action="${url.loginAction}" method="post" class="login-form">
          <input type="hidden" name="credentialId" value="${(auth.selectedCredential)!''}" />

          <!-- Email -->
          <div class="field-group">
            <label class="field-label" for="username">WORK EMAIL</label>
            <div class="field-wrap">
              <svg class="field-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              <input
                class="field-input"
                id="username"
                name="username"
                type="text"
                autofocus
                autocomplete="email"
                placeholder="Enter your work email"
                value="${(login.username)!''}"
              />
            </div>
          </div>

          <!-- Password -->
          <div class="field-group">
            <div class="field-label-row">
              <label class="field-label" for="password">PASSWORD</label>
              <#if realm.resetPasswordAllowed>
              <a class="forgot-link" href="${url.loginResetCredentialsUrl}">FORGOT?</a>
              </#if>
            </div>
            <div class="field-wrap">
              <svg class="field-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
              <input
                class="field-input field-input-password"
                id="password"
                name="password"
                type="password"
                autocomplete="current-password"
                placeholder="Enter your password"
              />
              <button type="button" class="toggle-pw" onclick="togglePassword()" aria-label="Toggle password">
                <svg id="eye-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </button>
            </div>
          </div>

          <!-- Remember me -->
          <#if realm.rememberMe>
          <div class="remember-row">
            <label class="remember-label">
              <input class="remember-check" type="checkbox" name="rememberMe" <#if login.rememberMe??>checked</#if> />
              <span class="remember-text">Remember this device for 30 days</span>
            </label>
          </div>
          </#if>

          <!-- Submit -->
          <button class="submit-btn" type="submit" name="login">
            Sign In to Dashboard <span class="btn-arrow">→</span>
          </button>

        </form>

        <!-- Realm info -->
        <div class="realm-info">
          Authenticating against realm:
          <span class="realm-name">${realm.name}</span>
        </div>

      </div>
    </div>

  </div>

  <script>
    function togglePassword() {
      var pw = document.getElementById('password');
      var icon = document.getElementById('eye-icon');
      if (pw.type === 'password') {
        pw.type = 'text';
        icon.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
      } else {
        pw.type = 'password';
        icon.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
      }
    }
  </script>

</body>
</html>
