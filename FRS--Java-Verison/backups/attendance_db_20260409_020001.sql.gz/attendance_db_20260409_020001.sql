--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-2.pgdg120+1)
-- Dumped by pg_dump version 15.4 (Debian 15.4-2.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: sync_face_enrolled(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_face_enrolled() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE hr_employee
      SET face_enrolled = TRUE
      WHERE pk_employee_id = NEW.employee_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE hr_employee
      SET face_enrolled = (
        EXISTS (
          SELECT 1 FROM employee_face_embeddings
          WHERE employee_id = OLD.employee_id
        )
      )
      WHERE pk_employee_id = OLD.employee_id;
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      NEW.updated_at = NOW();
      RETURN NEW;
    END;
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attendance_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_events (
    pk_attendance_event_id bigint NOT NULL,
    fk_employee_id bigint,
    fk_device_id uuid,
    fk_original_event_id uuid,
    event_type character varying(50) NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    confidence_score double precision,
    verification_method character varying(50),
    recognition_model_version character varying(50),
    frame_image_url text,
    face_bounding_box jsonb,
    location_zone character varying(120),
    entry_exit_direction character varying(20),
    fk_shift_id bigint,
    is_expected_entry boolean,
    is_on_time boolean,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: attendance_events_pk_attendance_event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_events_pk_attendance_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_events_pk_attendance_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_events_pk_attendance_event_id_seq OWNED BY public.attendance_events.pk_attendance_event_id;


--
-- Name: attendance_record; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_record (
    pk_attendance_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    fk_employee_id bigint NOT NULL,
    attendance_date date NOT NULL,
    check_in timestamp with time zone,
    check_out timestamp with time zone,
    break_start timestamp with time zone,
    break_end timestamp with time zone,
    status character varying(20) NOT NULL,
    working_hours numeric(8,2) DEFAULT 0 NOT NULL,
    break_duration_minutes integer DEFAULT 0 NOT NULL,
    overtime_hours numeric(8,2) DEFAULT 0 NOT NULL,
    is_late boolean DEFAULT false NOT NULL,
    is_early_departure boolean DEFAULT false NOT NULL,
    device_id character varying(80),
    location_label character varying(180),
    recognition_accuracy numeric(5,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    duration_minutes integer,
    CONSTRAINT attendance_record_status_check CHECK (((status)::text = ANY ((ARRAY['present'::character varying, 'late'::character varying, 'absent'::character varying, 'on-leave'::character varying, 'on-break'::character varying])::text[])))
);


--
-- Name: attendance_record_pk_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_record_pk_attendance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_record_pk_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_record_pk_attendance_id_seq OWNED BY public.attendance_record.pk_attendance_id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    pk_audit_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    fk_user_id bigint,
    action character varying(120) NOT NULL,
    details text NOT NULL,
    ip_address character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_name character varying(255),
    user_role character varying(50),
    user_agent character varying(500),
    method character varying(10),
    entity_type character varying(100),
    entity_id character varying(100),
    entity_name character varying(255),
    before_data text,
    after_data text,
    source character varying(50) DEFAULT 'ui'::character varying
);


--
-- Name: audit_log_pk_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_pk_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_pk_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_pk_audit_id_seq OWNED BY public.audit_log.pk_audit_id;


--
-- Name: auth_session_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_session_token (
    token_id uuid DEFAULT gen_random_uuid() NOT NULL,
    fk_user_id bigint NOT NULL,
    access_token character varying(128) NOT NULL,
    refresh_token character varying(128) NOT NULL,
    access_expires_at timestamp with time zone NOT NULL,
    refresh_expires_at timestamp with time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    user_agent character varying(512),
    ip_address character varying(45),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: device_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_events (
    pk_event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    fk_device_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    processing_status character varying(20) DEFAULT 'pending'::character varying,
    payload_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    detected_face_embedding jsonb,
    confidence_score double precision,
    frame_url text,
    processing_attempts integer DEFAULT 0,
    processing_error text,
    CONSTRAINT device_events_event_type_check CHECK (((event_type)::text = ANY ((ARRAY['FACE_DETECTED'::character varying, 'MOTION_DETECTED'::character varying, 'EMPLOYEE_ENTRY'::character varying, 'EMPLOYEE_EXIT'::character varying, 'DEVICE_HEARTBEAT'::character varying, 'DEVICE_ERROR'::character varying, 'FRAME_CAPTURED'::character varying])::text[]))),
    CONSTRAINT device_events_processing_status_check CHECK (((processing_status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'completed'::character varying, 'failed'::character varying, 'ignored'::character varying])::text[])))
);


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    pk_device_id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_code character varying(50) NOT NULL,
    device_name character varying(100),
    device_type character varying(20),
    fk_site_id uuid,
    location_description text,
    ip_address inet,
    mac_address character varying(17),
    keycloak_client_id character varying(100),
    api_key_hash character varying(64),
    status character varying(20) DEFAULT 'offline'::character varying,
    config_json jsonb DEFAULT '{}'::jsonb,
    capabilities jsonb DEFAULT '["face_detection"]'::jsonb,
    last_heartbeat_at timestamp with time zone,
    last_seen_at timestamp with time zone,
    firmware_version character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    camera_mode character varying(10) DEFAULT 'MIXED'::character varying,
    CONSTRAINT devices_device_type_check CHECK (((device_type)::text = ANY ((ARRAY['camera'::character varying, 'lpu'::character varying, 'sensor'::character varying, 'gateway'::character varying])::text[]))),
    CONSTRAINT devices_status_check CHECK (((status)::text = ANY ((ARRAY['online'::character varying, 'offline'::character varying, 'error'::character varying, 'maintenance'::character varying])::text[])))
);


--
-- Name: employee_face_embeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_face_embeddings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    employee_id bigint NOT NULL,
    embedding public.vector(512) NOT NULL,
    model_version character varying(50) DEFAULT 'arcface-r50-fp16'::character varying,
    quality_score double precision,
    is_primary boolean DEFAULT false,
    enrolled_by bigint,
    enrolled_at timestamp with time zone DEFAULT now(),
    angle character varying(20),
    photo_path character varying(255)
);


--
-- Name: COLUMN employee_face_embeddings.angle; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.employee_face_embeddings.angle IS 'Pose angle captured: front, left, right, up, down';


--
-- Name: facility_device; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.facility_device (
    pk_device_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    external_device_id character varying(80) NOT NULL,
    name character varying(200) NOT NULL,
    location_label character varying(200) NOT NULL,
    ip_address character varying(64) NOT NULL,
    status character varying(20) NOT NULL,
    recognition_accuracy numeric(5,2) DEFAULT 0 NOT NULL,
    total_scans integer DEFAULT 0 NOT NULL,
    error_rate numeric(5,2) DEFAULT 0 NOT NULL,
    model character varying(120),
    last_active timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT facility_device_status_check CHECK (((status)::text = ANY ((ARRAY['online'::character varying, 'offline'::character varying, 'error'::character varying])::text[])))
);


--
-- Name: facility_device_pk_device_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.facility_device_pk_device_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: facility_device_pk_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.facility_device_pk_device_id_seq OWNED BY public.facility_device.pk_device_id;


--
-- Name: frs_building; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_building (
    pk_building_id integer NOT NULL,
    fk_site_id integer,
    name character varying(100) NOT NULL,
    address text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_building_pk_building_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_building_pk_building_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_building_pk_building_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_building_pk_building_id_seq OWNED BY public.frs_building.pk_building_id;


--
-- Name: frs_camera; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_camera (
    pk_camera_id integer NOT NULL,
    fk_nug_id integer,
    fk_floor_id integer,
    fk_zone_id integer,
    name character varying(100) NOT NULL,
    cam_id character varying(100),
    rtsp_url text,
    ip_address character varying(50),
    model character varying(100),
    status character varying(20) DEFAULT 'offline'::character varying,
    recognition_accuracy numeric(5,4) DEFAULT 0,
    total_scans integer DEFAULT 0,
    error_rate numeric(5,4) DEFAULT 0,
    last_active timestamp with time zone,
    map_x numeric(10,4),
    map_y numeric(10,4),
    map_angle numeric(6,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_camera_pk_camera_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_camera_pk_camera_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_camera_pk_camera_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_camera_pk_camera_id_seq OWNED BY public.frs_camera.pk_camera_id;


--
-- Name: frs_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_customer (
    pk_customer_id bigint NOT NULL,
    customer_name character varying(200) NOT NULL,
    fk_tenant_id bigint NOT NULL
);


--
-- Name: frs_customer_pk_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_customer_pk_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_customer_pk_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_customer_pk_customer_id_seq OWNED BY public.frs_customer.pk_customer_id;


--
-- Name: frs_customer_user_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_customer_user_map (
    fk_user_id bigint NOT NULL,
    fk_customer_id bigint NOT NULL
);


--
-- Name: frs_floor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_floor (
    pk_floor_id integer NOT NULL,
    fk_building_id integer,
    floor_number integer NOT NULL,
    floor_name character varying(100),
    floor_plan_url text,
    floor_plan_data jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_floor_pk_floor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_floor_pk_floor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_floor_pk_floor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_floor_pk_floor_id_seq OWNED BY public.frs_floor.pk_floor_id;


--
-- Name: frs_nug_box; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_nug_box (
    pk_nug_id integer NOT NULL,
    fk_site_id integer,
    fk_building_id integer,
    fk_floor_id integer,
    fk_zone_id integer,
    name character varying(100) NOT NULL,
    device_code character varying(100),
    ip_address character varying(50),
    port integer DEFAULT 5000,
    match_threshold numeric(4,3) DEFAULT 0.38,
    conf_threshold numeric(4,3) DEFAULT 0.35,
    cooldown_seconds integer DEFAULT 3,
    x_threshold integer DEFAULT 25,
    tracking_window integer DEFAULT 6,
    status character varying(20) DEFAULT 'offline'::character varying,
    cpu_percent numeric(5,2),
    memory_used_mb numeric(10,2),
    memory_total_mb numeric(10,2),
    gpu_percent numeric(5,2),
    temperature_c numeric(5,2),
    disk_used_gb numeric(10,2),
    uptime_seconds bigint,
    last_heartbeat timestamp with time zone,
    map_x numeric(10,4),
    map_y numeric(10,4),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_nug_box_pk_nug_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_nug_box_pk_nug_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_nug_box_pk_nug_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_nug_box_pk_nug_id_seq OWNED BY public.frs_nug_box.pk_nug_id;


--
-- Name: frs_site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_site (
    pk_site_id bigint NOT NULL,
    site_name character varying(200) NOT NULL,
    fk_customer_id bigint NOT NULL,
    timezone character varying(100) DEFAULT 'Asia/Manila'::character varying,
    timezone_label character varying(100) DEFAULT 'Philippine Standard Time (UTC+8)'::character varying,
    location_address text
);


--
-- Name: frs_site_pk_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_site_pk_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_site_pk_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_site_pk_site_id_seq OWNED BY public.frs_site.pk_site_id;


--
-- Name: frs_telemetry_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_telemetry_history (
    pk_history_id integer NOT NULL,
    fk_nug_id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    cpu numeric(5,2),
    gpu numeric(5,2),
    ram numeric(5,2)
);


--
-- Name: frs_telemetry_history_pk_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_telemetry_history_pk_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_telemetry_history_pk_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_telemetry_history_pk_history_id_seq OWNED BY public.frs_telemetry_history.pk_history_id;


--
-- Name: frs_tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_tenant (
    pk_tenant_id bigint NOT NULL,
    tenant_name character varying(200) NOT NULL
);


--
-- Name: frs_tenant_pk_tenant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_tenant_pk_tenant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_tenant_pk_tenant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_tenant_pk_tenant_id_seq OWNED BY public.frs_tenant.pk_tenant_id;


--
-- Name: frs_tenant_user_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_tenant_user_map (
    fk_user_id bigint NOT NULL,
    fk_tenant_id bigint NOT NULL
);


--
-- Name: frs_unit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_unit (
    pk_unit_id bigint NOT NULL,
    unit_name character varying(200) NOT NULL,
    fk_site_id bigint NOT NULL
);


--
-- Name: frs_unit_pk_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_unit_pk_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_unit_pk_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_unit_pk_unit_id_seq OWNED BY public.frs_unit.pk_unit_id;


--
-- Name: frs_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_user (
    pk_user_id bigint NOT NULL,
    email character varying(320) NOT NULL,
    username character varying(150) NOT NULL,
    fk_user_type_id integer NOT NULL,
    role character varying(20) NOT NULL,
    password_hash character varying(255),
    department character varying(150),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    keycloak_sub character varying(64),
    auth_provider character varying(20) DEFAULT 'internal'::character varying NOT NULL,
    last_identity_sync_at timestamp with time zone,
    CONSTRAINT frs_user_auth_provider_check CHECK (((auth_provider)::text = ANY ((ARRAY['internal'::character varying, 'keycloak'::character varying, 'federated'::character varying])::text[]))),
    CONSTRAINT frs_user_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'hr'::character varying])::text[])))
);


--
-- Name: frs_user_membership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_user_membership (
    pk_membership_id bigint NOT NULL,
    fk_user_id bigint NOT NULL,
    role character varying(20) NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    permissions text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT frs_user_membership_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'hr'::character varying])::text[])))
);


--
-- Name: frs_user_membership_pk_membership_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_user_membership_pk_membership_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_user_membership_pk_membership_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_user_membership_pk_membership_id_seq OWNED BY public.frs_user_membership.pk_membership_id;


--
-- Name: frs_user_pk_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_user_pk_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_user_pk_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_user_pk_user_id_seq OWNED BY public.frs_user.pk_user_id;


--
-- Name: frs_zone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_zone (
    pk_zone_id integer NOT NULL,
    fk_floor_id integer,
    zone_name character varying(100) NOT NULL,
    zone_type character varying(50) DEFAULT 'common'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_zone_pk_zone_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_zone_pk_zone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_zone_pk_zone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_zone_pk_zone_id_seq OWNED BY public.frs_zone.pk_zone_id;


--
-- Name: hr_department; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_department (
    pk_department_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    name character varying(150) NOT NULL,
    code character varying(30) NOT NULL,
    color character varying(20)
);


--
-- Name: hr_department_pk_department_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hr_department_pk_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hr_department_pk_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hr_department_pk_department_id_seq OWNED BY public.hr_department.pk_department_id;


--
-- Name: hr_employee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_employee (
    pk_employee_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    fk_department_id bigint,
    fk_shift_id bigint,
    employee_code character varying(40) NOT NULL,
    full_name character varying(180) NOT NULL,
    email character varying(320) NOT NULL,
    position_title character varying(180) NOT NULL,
    location_label character varying(180),
    status character varying(20) NOT NULL,
    join_date date NOT NULL,
    phone_number character varying(40),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    face_enrolled boolean DEFAULT false,
    CONSTRAINT hr_employee_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'on-leave'::character varying])::text[])))
);


--
-- Name: hr_employee_pk_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hr_employee_pk_employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hr_employee_pk_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hr_employee_pk_employee_id_seq OWNED BY public.hr_employee.pk_employee_id;


--
-- Name: hr_leave_request; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_leave_request (
    pk_leave_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    fk_employee_id bigint NOT NULL,
    leave_type character varying(60) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    days integer DEFAULT 1 NOT NULL,
    reason text,
    status character varying(20) DEFAULT 'Pending'::character varying NOT NULL,
    approved_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hr_leave_request_status_check CHECK (((status)::text = ANY ((ARRAY['Pending'::character varying, 'Approved'::character varying, 'Rejected'::character varying])::text[])))
);


--
-- Name: hr_leave_request_pk_leave_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hr_leave_request_pk_leave_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hr_leave_request_pk_leave_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hr_leave_request_pk_leave_id_seq OWNED BY public.hr_leave_request.pk_leave_id;


--
-- Name: hr_shift; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_shift (
    pk_shift_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    name character varying(120) NOT NULL,
    shift_type character varying(30) NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    grace_period_minutes integer DEFAULT 10 NOT NULL,
    is_flexible boolean DEFAULT false NOT NULL,
    CONSTRAINT hr_shift_shift_type_check CHECK (((shift_type)::text = ANY ((ARRAY['morning'::character varying, 'evening'::character varying, 'night'::character varying, 'flexible'::character varying])::text[])))
);


--
-- Name: hr_shift_pk_shift_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hr_shift_pk_shift_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hr_shift_pk_shift_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hr_shift_pk_shift_id_seq OWNED BY public.hr_shift.pk_shift_id;


--
-- Name: system_alert; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_alert (
    pk_alert_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    alert_type character varying(80) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(220),
    message text NOT NULL,
    fk_employee_id bigint,
    fk_device_id bigint,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT system_alert_severity_check CHECK (((severity)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[])))
);


--
-- Name: system_alert_pk_alert_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_alert_pk_alert_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_alert_pk_alert_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_alert_pk_alert_id_seq OWNED BY public.system_alert.pk_alert_id;


--
-- Name: attendance_events pk_attendance_event_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events ALTER COLUMN pk_attendance_event_id SET DEFAULT nextval('public.attendance_events_pk_attendance_event_id_seq'::regclass);


--
-- Name: attendance_record pk_attendance_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record ALTER COLUMN pk_attendance_id SET DEFAULT nextval('public.attendance_record_pk_attendance_id_seq'::regclass);


--
-- Name: audit_log pk_audit_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN pk_audit_id SET DEFAULT nextval('public.audit_log_pk_audit_id_seq'::regclass);


--
-- Name: facility_device pk_device_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device ALTER COLUMN pk_device_id SET DEFAULT nextval('public.facility_device_pk_device_id_seq'::regclass);


--
-- Name: frs_building pk_building_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_building ALTER COLUMN pk_building_id SET DEFAULT nextval('public.frs_building_pk_building_id_seq'::regclass);


--
-- Name: frs_camera pk_camera_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera ALTER COLUMN pk_camera_id SET DEFAULT nextval('public.frs_camera_pk_camera_id_seq'::regclass);


--
-- Name: frs_customer pk_customer_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer ALTER COLUMN pk_customer_id SET DEFAULT nextval('public.frs_customer_pk_customer_id_seq'::regclass);


--
-- Name: frs_floor pk_floor_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_floor ALTER COLUMN pk_floor_id SET DEFAULT nextval('public.frs_floor_pk_floor_id_seq'::regclass);


--
-- Name: frs_nug_box pk_nug_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box ALTER COLUMN pk_nug_id SET DEFAULT nextval('public.frs_nug_box_pk_nug_id_seq'::regclass);


--
-- Name: frs_site pk_site_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_site ALTER COLUMN pk_site_id SET DEFAULT nextval('public.frs_site_pk_site_id_seq'::regclass);


--
-- Name: frs_telemetry_history pk_history_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_telemetry_history ALTER COLUMN pk_history_id SET DEFAULT nextval('public.frs_telemetry_history_pk_history_id_seq'::regclass);


--
-- Name: frs_tenant pk_tenant_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant ALTER COLUMN pk_tenant_id SET DEFAULT nextval('public.frs_tenant_pk_tenant_id_seq'::regclass);


--
-- Name: frs_unit pk_unit_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_unit ALTER COLUMN pk_unit_id SET DEFAULT nextval('public.frs_unit_pk_unit_id_seq'::regclass);


--
-- Name: frs_user pk_user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user ALTER COLUMN pk_user_id SET DEFAULT nextval('public.frs_user_pk_user_id_seq'::regclass);


--
-- Name: frs_user_membership pk_membership_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership ALTER COLUMN pk_membership_id SET DEFAULT nextval('public.frs_user_membership_pk_membership_id_seq'::regclass);


--
-- Name: frs_zone pk_zone_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_zone ALTER COLUMN pk_zone_id SET DEFAULT nextval('public.frs_zone_pk_zone_id_seq'::regclass);


--
-- Name: hr_department pk_department_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_department ALTER COLUMN pk_department_id SET DEFAULT nextval('public.hr_department_pk_department_id_seq'::regclass);


--
-- Name: hr_employee pk_employee_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee ALTER COLUMN pk_employee_id SET DEFAULT nextval('public.hr_employee_pk_employee_id_seq'::regclass);


--
-- Name: hr_leave_request pk_leave_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request ALTER COLUMN pk_leave_id SET DEFAULT nextval('public.hr_leave_request_pk_leave_id_seq'::regclass);


--
-- Name: hr_shift pk_shift_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_shift ALTER COLUMN pk_shift_id SET DEFAULT nextval('public.hr_shift_pk_shift_id_seq'::regclass);


--
-- Name: system_alert pk_alert_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert ALTER COLUMN pk_alert_id SET DEFAULT nextval('public.system_alert_pk_alert_id_seq'::regclass);


--
-- Data for Name: attendance_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_events (pk_attendance_event_id, fk_employee_id, fk_device_id, fk_original_event_id, event_type, occurred_at, confidence_score, verification_method, recognition_model_version, frame_image_url, face_bounding_box, location_zone, entry_exit_direction, fk_shift_id, is_expected_entry, is_on_time, created_at) FROM stdin;
\.


--
-- Data for Name: attendance_record; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_record (pk_attendance_id, tenant_id, customer_id, site_id, unit_id, fk_employee_id, attendance_date, check_in, check_out, break_start, break_end, status, working_hours, break_duration_minutes, overtime_hours, is_late, is_early_departure, device_id, location_label, recognition_accuracy, created_at, duration_minutes) FROM stdin;
97	1	1	1	\N	1	2026-04-09	2026-04-08 16:23:11.972+00	2026-04-08 16:31:04.141+00	\N	\N	present	0.13	0	0.00	f	f	\N	\N	0.72	2026-04-08 16:23:11.982739+00	8
82	1	1	1	\N	2	2026-04-08	2026-04-08 13:30:54.013+00	2026-04-08 14:03:29.115+00	\N	\N	present	0.54	0	0.00	t	f	\N	\N	0.72	2026-04-08 13:30:54.027285+00	33
1	1	1	1	\N	1	2026-04-08	2026-04-08 12:02:36.146+00	2026-04-08 14:05:00.249+00	\N	\N	present	2.04	0	0.00	t	f	\N	\N	0.84	2026-04-08 12:02:36.188643+00	122
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (pk_audit_id, tenant_id, customer_id, site_id, unit_id, fk_user_id, action, details, ip_address, created_at, user_name, user_role, user_agent, method, entity_type, entity_id, entity_name, before_data, after_data, source) FROM stdin;
1	1	1	1	\N	2	dept.create	Department created: Engineering (MLENG)	192.168.1.1	2026-04-07 06:00:51.757938+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	\N	\N	\N	\N	\N	ui
2	1	1	1	\N	2	dept.create	Department created: AI/ML (MLAI)	192.168.1.1	2026-04-07 06:01:08.005456+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	\N	\N	\N	\N	\N	ui
3	1	1	1	\N	1	employee.create	Employee created: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-07 06:03:16.380454+00	Admin User	admin	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	\N	\N	\N	\N	\N	ui
4	1	1	1	\N	1	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-07 06:03:21.917848+00	Admin User	admin	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
5	1	1	1	\N	1	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-07 06:06:38.800302+00	Admin User	admin	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
6	1	1	1	\N	1	face.enroll	Face enrolled for employee 1 (confidence: 0.496)	192.168.1.1	2026-04-07 06:07:02.088699+00	Admin User	admin	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	\N	\N	{"confidence":0.4960938096046448,"model":"arcface-r50"}	ui
7	1	1	1	\N	1	face.enroll.delete	Face enrollment removed for employee 1 (1 embedding(s) deleted)	192.168.1.1	2026-04-07 06:07:13.889807+00	Admin User	admin	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	DELETE	\N	\N	\N	\N	\N	ui
8	1	1	1	\N	1	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-07 06:53:19.198496+00	Admin User	admin	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
9	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-07 06:56:17.726451+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
10	1	1	1	\N	1	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-07 07:13:08.105363+00	Admin User	admin	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
11	1	1	1	\N	2	employee.create	Employee created: Sai Dinesh (MLI002)	192.168.1.1	2026-04-07 07:14:55.044342+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	\N	\N	\N	\N	\N	ui
12	1	1	1	\N	2	employee.view	Viewed profile: Sai Dinesh (MLI002)	192.168.1.1	2026-04-07 08:10:53.476207+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	2	Sai Dinesh	\N	\N	ui
13	1	1	1	\N	2	employee.view	Viewed profile: Sai Dinesh (MLI002)	192.168.1.1	2026-04-07 08:11:24.781984+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	2	Sai Dinesh	\N	\N	ui
14	1	1	1	\N	2	dept.create	Department created: HR (HR)	192.168.1.1	2026-04-07 08:12:06.269163+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	\N	\N	\N	\N	\N	ui
15	1	1	1	\N	2	dept.create	Department created: Sales (SAL)	192.168.1.1	2026-04-07 08:12:15.885517+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	\N	\N	\N	\N	\N	ui
16	1	1	1	\N	2	employee.create	Employee created: Yeshwanth (MLI003)	192.168.1.1	2026-04-07 08:15:33.097909+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	\N	\N	\N	\N	\N	ui
17	1	1	1	\N	2	employee.view	Viewed profile: Yeshwanth (MLI003)	192.168.1.1	2026-04-07 08:15:36.061667+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	3	Yeshwanth	\N	\N	ui
18	1	1	1	\N	2	employee.view	Viewed profile: Sai Dinesh (MLI002)	192.168.1.1	2026-04-07 08:18:27.509136+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	2	Sai Dinesh	\N	\N	ui
19	1	1	1	\N	2	employee.create	Employee created: Anjali (MLI004)	192.168.1.1	2026-04-07 08:22:49.609652+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	\N	\N	\N	\N	\N	ui
20	1	1	1	\N	2	employee.view	Viewed profile: Sai Dinesh (MLI002)	192.168.1.1	2026-04-07 08:30:40.212513+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	2	Sai Dinesh	\N	\N	ui
21	1	1	1	\N	2	employee.view	Viewed profile: Sai Dinesh (MLI002)	192.168.1.1	2026-04-07 08:53:08.245896+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	2	Sai Dinesh	\N	\N	ui
22	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-07 12:44:12.252656+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
23	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-07 12:57:02.063926+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
24	1	1	1	\N	2	employee.view	Viewed profile: Sai Dinesh (MLI002)	192.168.1.1	2026-04-08 05:47:22.915847+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	2	Sai Dinesh	\N	\N	ui
25	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-08 06:08:57.566847+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
26	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-08 06:25:40.950463+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
27	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-08 06:26:05.799272+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
28	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-08 07:07:06.159452+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
29	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-08 09:12:14.201203+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
30	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-08 09:19:23.191296+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
31	1	1	1	\N	\N	face.enroll	Face enrolled for employee 1 (confidence: 0.724)	192.168.1.1	2026-04-08 12:02:35.571006+00	\N	\N	\N	POST	employee	1	\N	\N	{"confidence":0.7240901589393616,"model":"arcface-r50-fp16"}	ui
32	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.954)	192.168.1.1	2026-04-08 12:02:36.195694+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7348818182945251,"similarity":0.9538891746601559,"deviceId":"jetson-orin-01"}	device
33	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.915)	192.168.1.1	2026-04-08 12:02:36.374663+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6884690523147583,"similarity":0.9145882540099903,"deviceId":"jetson-orin-01"}	device
34	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.902)	192.168.1.1	2026-04-08 12:02:36.578721+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.692642092704773,"similarity":0.9015611981503223,"deviceId":"jetson-orin-01"}	device
35	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.929)	192.168.1.1	2026-04-08 12:02:37.696709+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6791782379150391,"similarity":0.9287185840121478,"deviceId":"jetson-orin-01"}	device
36	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-08 12:22:32.694845+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
37	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.431)	192.168.1.1	2026-04-08 12:22:48.512788+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7556356191635132,"similarity":0.4307249412849239,"deviceId":"jetson-orin-01"}	device
38	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.445)	192.168.1.1	2026-04-08 12:22:48.689546+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.752739667892456,"similarity":0.44490509872213635,"deviceId":"jetson-orin-01"}	device
39	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.448)	192.168.1.1	2026-04-08 12:22:50.009732+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7122327089309692,"similarity":0.44756753982724984,"deviceId":"jetson-orin-01"}	device
40	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.438)	192.168.1.1	2026-04-08 12:22:50.213692+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7272009253501892,"similarity":0.43813951359238457,"deviceId":"jetson-orin-01"}	device
41	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.563)	192.168.1.1	2026-04-08 12:22:50.609257+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7585086822509766,"similarity":0.5633117337892893,"deviceId":"jetson-orin-01"}	device
42	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.643)	192.168.1.1	2026-04-08 12:22:50.829388+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7570750117301941,"similarity":0.642753969305804,"deviceId":"jetson-orin-01"}	device
43	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.627)	192.168.1.1	2026-04-08 12:22:51.025194+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7453993558883667,"similarity":0.62714025531312,"deviceId":"jetson-orin-01"}	device
44	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.743)	192.168.1.1	2026-04-08 12:22:52.099863+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7570750117301941,"similarity":0.7425208398676236,"deviceId":"jetson-orin-01"}	device
45	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.734)	192.168.1.1	2026-04-08 12:22:52.305205+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7468788623809814,"similarity":0.7336257100106119,"deviceId":"jetson-orin-01"}	device
46	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.739)	192.168.1.1	2026-04-08 12:22:52.508147+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7498207688331604,"similarity":0.73871830240283,"deviceId":"jetson-orin-01"}	device
47	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.700)	192.168.1.1	2026-04-08 12:22:53.625804+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7379155158996582,"similarity":0.7003031077711367,"deviceId":"jetson-orin-01"}	device
48	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.505)	192.168.1.1	2026-04-08 12:22:55.103343+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6424316167831421,"similarity":0.5046488369607656,"deviceId":"jetson-orin-01"}	device
49	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.565)	192.168.1.1	2026-04-08 12:22:55.304412+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7585086822509766,"similarity":0.5648162582966383,"deviceId":"jetson-orin-01"}	device
50	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.540)	192.168.1.1	2026-04-08 12:22:55.506017+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7641857862472534,"similarity":0.5400519031425572,"deviceId":"jetson-orin-01"}	device
51	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.599)	192.168.1.1	2026-04-08 12:22:56.628455+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7766237258911133,"similarity":0.5994330462583292,"deviceId":"jetson-orin-01"}	device
52	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.638)	192.168.1.1	2026-04-08 12:22:56.822905+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7409262657165527,"similarity":0.6383187428539585,"deviceId":"jetson-orin-01"}	device
53	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.614)	192.168.1.1	2026-04-08 12:22:57.027419+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7348818182945251,"similarity":0.6140298100905464,"deviceId":"jetson-orin-01"}	device
54	1	1	1	\N	\N	face.enroll	Face enrolled for employee 1 (confidence: 0.777)	192.168.1.1	2026-04-08 12:22:57.604814+00	\N	\N	\N	POST	employee	1	\N	\N	{"confidence":0.7766237258911133,"model":"arcface-r50-fp16"}	ui
55	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.887)	192.168.1.1	2026-04-08 12:22:58.102712+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7394237518310547,"similarity":0.8870696415679118,"deviceId":"jetson-orin-01"}	device
56	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.840)	192.168.1.1	2026-04-08 12:22:58.307494+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7424229979515076,"similarity":0.8395128559196946,"deviceId":"jetson-orin-01"}	device
57	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.853)	192.168.1.1	2026-04-08 12:22:58.506502+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7333563566207886,"similarity":0.852557265411649,"deviceId":"jetson-orin-01"}	device
58	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.845)	192.168.1.1	2026-04-08 12:22:59.611494+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.716218888759613,"similarity":0.845125115282933,"deviceId":"jetson-orin-01"}	device
59	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.695)	192.168.1.1	2026-04-08 12:22:59.817296+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7082128524780273,"similarity":0.6952262906723847,"deviceId":"jetson-orin-01"}	device
60	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.794)	192.168.1.1	2026-04-08 12:23:00.012054+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7240901589393616,"similarity":0.7940078587570024,"deviceId":"jetson-orin-01"}	device
61	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.829)	192.168.1.1	2026-04-08 12:23:01.097818+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7138312458992004,"similarity":0.8293451696297341,"deviceId":"jetson-orin-01"}	device
62	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.830)	192.168.1.1	2026-04-08 12:23:01.308852+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6967839002609253,"similarity":0.8296593807504139,"deviceId":"jetson-orin-01"}	device
63	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.778)	192.168.1.1	2026-04-08 12:23:01.505354+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6791782379150391,"similarity":0.7775657307277698,"deviceId":"jetson-orin-01"}	device
64	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.711)	192.168.1.1	2026-04-08 12:23:02.625333+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6740499138832092,"similarity":0.7106845560625832,"deviceId":"jetson-orin-01"}	device
65	1	1	1	\N	\N	face.enroll	Face enrolled for employee 1 (confidence: 0.750)	192.168.1.1	2026-04-08 12:23:11.077902+00	\N	\N	\N	POST	employee	1	\N	\N	{"confidence":0.7498207688331604,"model":"arcface-r50-fp16"}	ui
66	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.941)	192.168.1.1	2026-04-08 12:23:11.622457+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.743914008140564,"similarity":0.9410804650592297,"deviceId":"jetson-orin-01"}	device
67	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.947)	192.168.1.1	2026-04-08 12:23:11.829566+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.743914008140564,"similarity":0.9472691761347309,"deviceId":"jetson-orin-01"}	device
68	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.952)	192.168.1.1	2026-04-08 12:23:12.028015+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7379155158996582,"similarity":0.9524665446559533,"deviceId":"jetson-orin-01"}	device
69	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.961)	192.168.1.1	2026-04-08 12:23:13.098225+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7409262657165527,"similarity":0.9613694525581289,"deviceId":"jetson-orin-01"}	device
70	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.462)	192.168.1.1	2026-04-08 12:23:13.299803+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7424229979515076,"similarity":0.4615153509740908,"deviceId":"jetson-orin-01"}	device
71	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.555)	192.168.1.1	2026-04-08 12:23:13.508549+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7193835973739624,"similarity":0.555278685225849,"deviceId":"jetson-orin-01"}	device
72	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.712)	192.168.1.1	2026-04-08 12:23:14.620128+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7209578156471252,"similarity":0.7119443871660297,"deviceId":"jetson-orin-01"}	device
73	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.545)	192.168.1.1	2026-04-08 12:23:14.825442+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.710628867149353,"similarity":0.5451040807925178,"deviceId":"jetson-orin-01"}	device
74	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.523)	192.168.1.1	2026-04-08 12:23:15.027243+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6619234681129456,"similarity":0.5231120485599163,"deviceId":"jetson-orin-01"}	device
75	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.433)	192.168.1.1	2026-04-08 12:23:16.114753+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5851011872291565,"similarity":0.43286364828472745,"deviceId":"jetson-orin-01"}	device
76	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.424)	192.168.1.1	2026-04-08 12:23:18.103313+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6067314743995667,"similarity":0.424221578869459,"deviceId":"jetson-orin-01"}	device
77	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.441)	192.168.1.1	2026-04-08 12:23:19.627261+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6951309442520142,"similarity":0.44060458316912565,"deviceId":"jetson-orin-01"}	device
78	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.421)	192.168.1.1	2026-04-08 12:23:19.826921+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6113821864128113,"similarity":0.4213098178627581,"deviceId":"jetson-orin-01"}	device
79	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.423)	192.168.1.1	2026-04-08 12:23:20.037128+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.4484260678291321,"similarity":0.42278557774420733,"deviceId":"jetson-orin-01"}	device
80	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.522)	192.168.1.1	2026-04-08 12:23:29.612968+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5370416045188904,"similarity":0.5216258529918013,"deviceId":"jetson-orin-01"}	device
81	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.486)	192.168.1.1	2026-04-08 12:23:33.095499+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.535098671913147,"similarity":0.48605888167904787,"deviceId":"jetson-orin-01"}	device
82	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.543)	192.168.1.1	2026-04-08 12:23:43.409402+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.784649133682251,"similarity":0.5425343272377795,"deviceId":"jetson-orin-01"}	device
83	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.530)	192.168.1.1	2026-04-08 12:23:43.624401+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7988153100013733,"similarity":0.5296006447791135,"deviceId":"jetson-orin-01"}	device
84	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.475)	192.168.1.1	2026-04-08 12:23:44.699653+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7302901148796082,"similarity":0.4752479590992862,"deviceId":"jetson-orin-01"}	device
85	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.506)	192.168.1.1	2026-04-08 12:23:44.90423+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.792464017868042,"similarity":0.5059849777795343,"deviceId":"jetson-orin-01"}	device
86	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.491)	192.168.1.1	2026-04-08 12:23:45.105348+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7833261489868164,"similarity":0.49072025356781146,"deviceId":"jetson-orin-01"}	device
87	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.488)	192.168.1.1	2026-04-08 12:23:45.310447+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.752739667892456,"similarity":0.4881674044232023,"deviceId":"jetson-orin-01"}	device
88	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.435)	192.168.1.1	2026-04-08 12:23:45.51065+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7627751231193542,"similarity":0.43500916600446193,"deviceId":"jetson-orin-01"}	device
89	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.442)	192.168.1.1	2026-04-08 12:23:45.711941+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7379155158996582,"similarity":0.4415321296022032,"deviceId":"jetson-orin-01"}	device
90	1	1	1	\N	\N	face.enroll	Face enrolled for employee 1 (confidence: 0.823)	192.168.1.1	2026-04-08 12:23:52.316656+00	\N	\N	\N	POST	employee	1	\N	\N	{"confidence":0.8227584362030029,"model":"arcface-r50-fp16"}	ui
91	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.950)	192.168.1.1	2026-04-08 12:23:52.90052+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.8360199332237244,"similarity":0.9498693211738082,"deviceId":"jetson-orin-01"}	device
92	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.943)	192.168.1.1	2026-04-08 12:23:53.101492+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.8433818817138672,"similarity":0.9432230646354457,"deviceId":"jetson-orin-01"}	device
93	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.931)	192.168.1.1	2026-04-08 12:23:53.300651+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.8261497020721436,"similarity":0.9314877741889213,"deviceId":"jetson-orin-01"}	device
94	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.911)	192.168.1.1	2026-04-08 12:23:54.419501+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.8402605056762695,"similarity":0.911193334455325,"deviceId":"jetson-orin-01"}	device
95	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.923)	192.168.1.1	2026-04-08 12:23:54.629236+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.813461184501648,"similarity":0.9233147639071367,"deviceId":"jetson-orin-01"}	device
96	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.845)	192.168.1.1	2026-04-08 12:23:54.82352+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.8204694986343384,"similarity":0.8453124410938452,"deviceId":"jetson-orin-01"}	device
121	1	1	1	\N	\N	attendance.mark	Attendance marked: Sai Dinesh via device jetson-orin-01 (sim=0.653)	192.168.1.1	2026-04-08 13:30:54.033317+00	\N	\N	\N	POST	employee	2	Sai Dinesh	\N	{"direction":"","confidence":0.717803955078125,"similarity":0.6526159217450458,"deviceId":"jetson-orin-01"}	device
97	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.813)	192.168.1.1	2026-04-08 12:23:55.899963+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.8261497020721436,"similarity":0.8133847550842301,"deviceId":"jetson-orin-01"}	device
98	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.475)	192.168.1.1	2026-04-08 12:24:11.091573+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.46781787276268005,"similarity":0.4753794328057773,"deviceId":"jetson-orin-01"}	device
99	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.478)	192.168.1.1	2026-04-08 12:24:12.212691+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5331546068191528,"similarity":0.47834666659995106,"deviceId":"jetson-orin-01"}	device
100	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.547)	192.168.1.1	2026-04-08 12:24:12.407508+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5832034945487976,"similarity":0.5470775264229001,"deviceId":"jetson-orin-01"}	device
101	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.550)	192.168.1.1	2026-04-08 12:24:12.623696+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6206216216087341,"similarity":0.5502260179001938,"deviceId":"jetson-orin-01"}	device
102	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.588)	192.168.1.1	2026-04-08 12:24:13.698036+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7000747919082642,"similarity":0.5884913697954383,"deviceId":"jetson-orin-01"}	device
103	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.490)	192.168.1.1	2026-04-08 12:24:42.693895+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.717803955078125,"similarity":0.4903516780913105,"deviceId":"jetson-orin-01"}	device
104	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.423)	192.168.1.1	2026-04-08 12:24:42.886513+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7752646207809448,"similarity":0.4233189133786943,"deviceId":"jetson-orin-01"}	device
105	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.440)	192.168.1.1	2026-04-08 12:24:43.682117+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6654106378555298,"similarity":0.43970616551909414,"deviceId":"jetson-orin-01"}	device
106	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.457)	192.168.1.1	2026-04-08 12:24:43.890322+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6495788097381592,"similarity":0.45694790217779324,"deviceId":"jetson-orin-01"}	device
107	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.467)	192.168.1.1	2026-04-08 12:24:45.037101+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7859662771224976,"similarity":0.4669850907254951,"deviceId":"jetson-orin-01"}	device
108	1	1	1	\N	\N	face.enroll	Face enrolled for employee 1 (confidence: 0.647)	192.168.1.1	2026-04-08 12:24:50.416774+00	\N	\N	\N	POST	employee	1	\N	\N	{"confidence":0.6469058394432068,"model":"arcface-r50-fp16"}	ui
109	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.720)	192.168.1.1	2026-04-08 12:24:51.045802+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6451190710067749,"similarity":0.7197120663929784,"deviceId":"jetson-orin-01"}	device
110	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.736)	192.168.1.1	2026-04-08 12:24:51.243475+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.613236665725708,"similarity":0.7362187720649089,"deviceId":"jetson-orin-01"}	device
111	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.715)	192.168.1.1	2026-04-08 12:24:51.445475+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6252099275588989,"similarity":0.7149922980315347,"deviceId":"jetson-orin-01"}	device
112	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.672)	192.168.1.1	2026-04-08 12:24:52.497585+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6424316167831421,"similarity":0.6721032677035677,"deviceId":"jetson-orin-01"}	device
113	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.432)	192.168.1.1	2026-04-08 12:24:52.698263+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6774741411209106,"similarity":0.4319060553832481,"deviceId":"jetson-orin-01"}	device
114	1	1	1	\N	\N	face.enroll	Face enrolled for employee 1 (confidence: 0.736)	192.168.1.1	2026-04-08 12:25:03.626592+00	\N	\N	\N	POST	employee	1	\N	\N	{"confidence":0.7364015579223633,"model":"arcface-r50-fp16"}	ui
115	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.923)	192.168.1.1	2026-04-08 12:25:04.228216+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7911761403083801,"similarity":0.9232956811956579,"deviceId":"jetson-orin-01"}	device
116	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.891)	192.168.1.1	2026-04-08 12:25:04.451776+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.8000680208206177,"similarity":0.8911925029262197,"deviceId":"jetson-orin-01"}	device
117	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.891)	192.168.1.1	2026-04-08 12:25:04.655762+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.813461184501648,"similarity":0.8907444081376158,"deviceId":"jetson-orin-01"}	device
118	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.856)	192.168.1.1	2026-04-08 12:25:05.69804+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.8098787069320679,"similarity":0.8557566315475016,"deviceId":"jetson-orin-01"}	device
119	1	1	1	\N	2	employee.view	Viewed profile: vallabhaneni Karthik (ML001)	192.168.1.1	2026-04-08 12:25:15.552822+00	HR Manager	hr	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0	POST	employee	1	vallabhaneni Karthik	\N	\N	ui
120	1	1	1	\N	\N	face.enroll	Face enrolled for employee 2 (confidence: 0.736)	192.168.1.1	2026-04-08 13:30:53.408901+00	\N	\N	\N	POST	employee	2	\N	\N	{"confidence":0.7364015579223633,"model":"arcface-r50-fp16"}	ui
122	1	1	1	\N	\N	attendance.mark	Attendance marked: Sai Dinesh via device jetson-orin-01 (sim=0.682)	192.168.1.1	2026-04-08 13:30:54.240568+00	\N	\N	\N	POST	employee	2	Sai Dinesh	\N	{"direction":"","confidence":0.6531269550323486,"similarity":0.6822960215320638,"deviceId":"jetson-orin-01"}	device
123	1	1	1	\N	\N	attendance.mark	Attendance marked: Sai Dinesh via device jetson-orin-01 (sim=0.637)	192.168.1.1	2026-04-08 13:30:54.438037+00	\N	\N	\N	POST	employee	2	Sai Dinesh	\N	{"direction":"","confidence":0.6370307803153992,"similarity":0.6371844363560681,"deviceId":"jetson-orin-01"}	device
124	1	1	1	\N	\N	attendance.mark	Attendance marked: Sai Dinesh via device jetson-orin-01 (sim=0.674)	192.168.1.1	2026-04-08 13:30:55.522207+00	\N	\N	\N	POST	employee	2	Sai Dinesh	\N	{"direction":"","confidence":0.6584183573722839,"similarity":0.6735927036317291,"deviceId":"jetson-orin-01"}	device
125	1	1	1	\N	\N	attendance.mark	Attendance marked: Sai Dinesh via device jetson-orin-01 (sim=0.421)	192.168.1.1	2026-04-08 14:03:29.141279+00	\N	\N	\N	POST	employee	2	Sai Dinesh	\N	{"direction":"","confidence":0.716218888759613,"similarity":0.42131372196826333,"deviceId":"jetson-orin-01"}	device
126	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.442)	192.168.1.1	2026-04-08 14:04:37.911463+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5879430174827576,"similarity":0.44190117302277887,"deviceId":"jetson-orin-01"}	device
127	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.432)	192.168.1.1	2026-04-08 14:04:38.119832+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5869963765144348,"similarity":0.4315529688323384,"deviceId":"jetson-orin-01"}	device
128	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.452)	192.168.1.1	2026-04-08 14:04:39.257562+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5841526389122009,"similarity":0.4522828849277696,"deviceId":"jetson-orin-01"}	device
129	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.436)	192.168.1.1	2026-04-08 14:04:45.658755+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6566590666770935,"similarity":0.4357290067958033,"deviceId":"jetson-orin-01"}	device
130	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.437)	192.168.1.1	2026-04-08 14:04:45.698383+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.590779185295105,"similarity":0.43738386775870675,"deviceId":"jetson-orin-01"}	device
131	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.477)	192.168.1.1	2026-04-08 14:04:54.462733+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6876306533813477,"similarity":0.47655979403958615,"deviceId":"jetson-orin-01"}	device
132	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.441)	192.168.1.1	2026-04-08 14:04:57.659076+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.603931725025177,"similarity":0.44076033367401446,"deviceId":"jetson-orin-01"}	device
133	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.432)	192.168.1.1	2026-04-08 14:04:58.714706+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6645405292510986,"similarity":0.43191769116946466,"deviceId":"jetson-orin-01"}	device
134	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.501)	192.168.1.1	2026-04-08 14:04:59.118624+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6654106378555298,"similarity":0.5006433130077816,"deviceId":"jetson-orin-01"}	device
135	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.515)	192.168.1.1	2026-04-08 14:05:00.252004+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6876306533813477,"similarity":0.5147578904873547,"deviceId":"jetson-orin-01"}	device
136	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.421)	192.168.1.1	2026-04-08 16:23:11.9882+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5822536945343018,"similarity":0.42082304693298667,"deviceId":"jetson-orin-01"}	device
137	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.487)	192.168.1.1	2026-04-08 16:23:13.126576+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6601731777191162,"similarity":0.4871362119045901,"deviceId":"jetson-orin-01"}	device
138	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.451)	192.168.1.1	2026-04-08 16:24:40.136922+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6020615696907043,"similarity":0.45132305716734533,"deviceId":"jetson-orin-01"}	device
139	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.454)	192.168.1.1	2026-04-08 16:25:27.018+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.3638727366924286,"similarity":0.45432870763457633,"deviceId":"jetson-orin-01"}	device
140	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.471)	192.168.1.1	2026-04-08 16:25:38.820288+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7209578156471252,"similarity":0.4705878075429599,"deviceId":"jetson-orin-01"}	device
141	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.526)	192.168.1.1	2026-04-08 16:25:39.019056+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.7098248600959778,"similarity":0.5256230200632008,"deviceId":"jetson-orin-01"}	device
142	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.433)	192.168.1.1	2026-04-08 16:27:59.639149+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5784482359886169,"similarity":0.4326846843098888,"deviceId":"jetson-orin-01"}	device
143	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.463)	192.168.1.1	2026-04-08 16:28:00.044778+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5851011872291565,"similarity":0.46266037714313657,"deviceId":"jetson-orin-01"}	device
144	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.424)	192.168.1.1	2026-04-08 16:28:05.63804+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6842647194862366,"similarity":0.4241675887757155,"deviceId":"jetson-orin-01"}	device
145	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.468)	192.168.1.1	2026-04-08 16:28:44.842283+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.5029296875,"similarity":0.4679455084670936,"deviceId":"jetson-orin-01"}	device
146	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.443)	192.168.1.1	2026-04-08 16:30:14.684066+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.6113821864128113,"similarity":0.4427960774528139,"deviceId":"jetson-orin-01"}	device
147	1	1	1	\N	\N	attendance.mark	Attendance marked: vallabhaneni Karthik via device jetson-orin-01 (sim=0.457)	192.168.1.1	2026-04-08 16:31:04.168172+00	\N	\N	\N	POST	employee	1	vallabhaneni Karthik	\N	{"direction":"","confidence":0.49218809604644775,"similarity":0.45701531600598677,"deviceId":"jetson-orin-01"}	device
\.


--
-- Data for Name: auth_session_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_session_token (token_id, fk_user_id, access_token, refresh_token, access_expires_at, refresh_expires_at, revoked, user_agent, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: device_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_events (pk_event_id, fk_device_id, event_type, occurred_at, received_at, processed_at, processing_status, payload_json, detected_face_embedding, confidence_score, frame_url, processing_attempts, processing_error) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (pk_device_id, device_code, device_name, device_type, fk_site_id, location_description, ip_address, mac_address, keycloak_client_id, api_key_hash, status, config_json, capabilities, last_heartbeat_at, last_seen_at, firmware_version, created_at, updated_at, camera_mode) FROM stdin;
\.


--
-- Data for Name: employee_face_embeddings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_face_embeddings (id, employee_id, embedding, model_version, quality_score, is_primary, enrolled_by, enrolled_at, angle, photo_path) FROM stdin;
6080bb92-9bc0-422a-b98f-f2c99d873230	1	[-0.025774976,-0.04321932,-0.026341459,0.02767436,0.013728882,0.08437265,-0.054082464,-0.05135002,0.034822043,-0.0029323825,0.0038258429,0.007418428,-0.04888415,0.044352286,-0.021176467,-0.0046859807,0.0022680147,-0.07310963,0.009696856,0.015320033,0.05581524,0.026391443,-0.006760308,0.04508538,0.012712545,0.016003145,-0.036154944,-0.0026533064,-0.0023075852,0.004573517,-0.029090568,-0.0041632336,-0.06284629,-0.037754428,-0.013329011,0.014953485,-0.042886097,0.014153744,-0.013728882,0.014145413,-0.04991715,0.008747164,0.020076824,0.026691345,-0.02385893,-0.07390937,-0.04441893,0.015903177,0.052383017,0.076708466,0.00013101222,0.08283981,-0.04915073,-0.016661264,-0.02964039,0.054582305,0.023342432,-0.044318963,0.011404635,-0.054082464,-0.037454523,-0.0037966857,-0.038454197,0.06767806,-7.8034594e-05,-0.011221362,-0.01724441,0.027224507,0.04095339,-0.033622433,-0.025541719,-0.044052385,-0.017844215,0.021842917,0.049817182,0.045118704,-0.03137316,-0.030390147,-0.058314428,-0.004156986,-0.01028,0.053282727,-0.018760584,-0.034188915,0.0029948624,-0.013170729,-0.03502198,0.006943582,0.0053732577,0.06384597,0.0100300815,0.08703845,-0.056415044,-0.07257647,-0.019610308,-0.011171378,-0.08657193,0.0006477067,0.08390613,0.051183406,0.0030885818,-0.10576571,0.063945934,0.0775082,0.011346322,0.017877538,-0.02369232,0.035488494,0.107298546,0.08150691,-0.06551209,-0.015428331,-0.013712221,0.046018414,0.038354233,-0.044718836,0.009946775,-0.019926872,0.008588882,0.105965644,-0.030173551,-0.007022723,0.07364279,0.07444253,-0.008114036,0.022675982,0.043785803,-0.009888461,-0.039687134,-0.054748915,-0.09290321,-0.06681167,-0.078241296,-0.04965057,-0.017810892,-0.07404266,-0.0271412,0.011404635,0.054715592,-0.0034093114,0.026674684,-0.0071643437,-0.07604201,0.043485902,0.008788818,-0.0505836,0.053582627,0.034072287,-0.0667117,0.072376534,-0.007747488,0.051316697,-0.010255008,-0.034588784,0.021443048,-0.013795528,-0.021176467,-0.057514686,-0.079440914,0.03069005,0.028940616,0.0098717995,-0.009563566,0.02080992,0.060413744,-0.052349694,-0.107298546,-0.026008233,0.004100754,-0.007801637,-0.07051047,-0.032089595,0.023592351,0.030440131,0.07364279,-0.0068352837,-0.01962697,-0.02515851,0.013887164,-0.017644279,-0.09616882,-0.08990418,-0.007189336,-0.06761141,0.0010116511,0.044085708,0.011013096,-0.058047846,0.024425413,0.05544869,-0.014770212,0.030773357,-0.013453972,0.075842075,-0.007305965,0.046718188,0.024675334,-0.020909887,0.0039133145,-0.041386582,0.03765446,-0.008214003,0.010679871,-0.009755171,0.063779324,-0.025575042,0.020193452,0.04201971,0.029856987,-0.02199287,0.05754801,0.06371268,-0.012662562,0.022292772,-0.03532188,0.051316697,-0.050650246,0.032756045,0.0051733227,-0.07530892,-0.02145971,0.05861433,0.07664182,-0.012620908,-0.0017827554,-0.017977504,0.025625026,-0.051983148,-0.071443506,0.021143146,0.028390795,0.05008376,0.026524734,0.020310082,0.075708784,0.07724162,0.006335446,0.024275463,-0.0013141573,0.1045661,-0.019410374,-0.076575175,0.037221264,-0.010879806,0.012529271,-0.016752902,0.02925718,0.019943533,-0.04768454,-0.049517278,0.06291293,-0.0023409077,0.010163371,-0.032039613,-0.024808623,0.0111380555,-0.023109173,0.044552222,-0.026458088,0.016094781,-0.064379126,-0.038820747,-0.0613801,0.021526353,0.05601517,0.055615302,-0.0053815884,-0.056581654,-0.019043826,-0.029740358,-0.014570276,-0.09876798,-0.0063271155,-0.00018171192,0.0045485254,-0.0048650894,0.03965381,0.05898088,0.024575366,-0.019393712,-0.026757991,0.0056481687,-0.011304668,-0.1140297,-0.0025325122,0.051949825,-0.037087977,0.06564538,-0.0041444898,0.035588462,-0.07964084,0.051916502,-0.05021705,0.0103466455,-0.050150406,0.070243895,-0.011937796,0.019110471,-0.033955656,0.028107554,0.00017741644,0.0017494328,0.036388204,-0.041153323,0.006352107,0.01569491,0.0001141557,-0.059047524,0.042186324,-0.033239223,-0.11522931,-0.1307576,-0.055248752,-0.0050150407,0.051150084,0.02439209,0.03702133,-0.018643955,0.13362335,-0.11129725,-0.060680326,-0.11909472,0.024975237,-0.061346777,-0.015886515,0.034988657,0.004506872,-0.014953485,0.011896143,0.05638172,-0.013553939,-0.045018736,0.08650529,-0.015519968,-0.050117083,-0.035588462,-0.038920715,0.024675334,-0.041020032,-0.02752441,0.023209142,0.00883047,0.076441884,0.09017076,0.030223534,-0.05068357,-0.006726986,0.070377186,0.05598185,-0.07277641,0.024325447,0.011404635,0.056148462,-0.04558522,0.05318276,-0.010963112,-0.053016145,0.0025241815,-0.089104444,0.021842917,-0.025341785,0.008318136,-0.02330911,-0.007522561,-0.006468736,0.09403618,-0.008084878,0.08150691,-0.01488684,0.008797148,0.023059191,0.00388624,-0.02145971,-0.0060647004,-0.038687456,0.02079326,-0.009205349,-0.004960892,-0.012804182,0.006397926,0.030706711,-0.06684499,-0.05784791,-0.07544221,-0.070577115,-0.008547229,-0.020759936,0.06794464,-0.10603229,0.021559676,-0.061846614,0.069644086,0.04781783,-0.01304577,0.060413744,0.030540098,0.004915073,0.03042347,-0.06627851,-0.103099905,0.02502522,0.0326894,-0.042719483,-0.059047524,-0.02857407,-0.013362334,-0.0030365156,-0.027041232,-0.03582172,-0.0023179986,-0.0037008834,-0.0007518396,-0.025391767,0.05648169,-0.0030677554,0.018727262,0.024858607,-0.03397232,-0.049750537,-0.06607857,-0.03842088,-0.020093486,0.045518577,-0.045551896,0.025258478,0.05121673,0.026508072,0.039320584,0.040253617,0.039487198,0.00026658023,0.07717498,0.01330402,-0.073709436,0.06971073,0.00058991293,0.03358911,0.09743508,-0.07817465,0.096901916,-0.024975237,0.063179515,-0.0007882861,0.04861757,0.036388204,-0.011096402,0.028907293,-0.043485902,-0.08783819,0.040386904,-0.032939322,-0.0735095,-0.046118382,0.043252643,-0.033155918,-0.06461238,-0.015078445,-0.06667838,-0.015053453,0.025991574,0.007814134,-0.049950473,0.0076058675,0.013520616,-0.017227748,-0.004477715,-0.007122691,0.03307261,-0.031306516,-0.0135372775,0.0129041495,-0.053982496,0.043552548,0.021859579,0.010329984,-0.034522142,-0.014736889,-0.015120097,0.032989305,-0.01566992,0.0042527877,0.01277919,-0.009655203,-0.036054976,0.07810801,0.006172999,-0.009022075,-0.03585504,0.03448882,0.04385245,0.019943533,0.062713,-0.0009580227,0.05228305,0.04228629,-0.025075203,0.048417635,-0.021526353,-0.0061563374,0.005494052,0.016261395,0.01607812,0.04191974,0.011213032,0.02397556,-0.02767436,0.025108526,0.01197945,0.0022221962,0.010513258,-0.03962049,0.0122960135]	arcface-r50-fp16	0.7240901589393616	t	\N	2026-04-08 12:02:35.560093+00	\N	\N
d32e45d9-4214-4564-a051-444959f9ab86	1	[-0.026475294,0.008338489,0.0015212428,0.05895997,0.023678474,0.017716337,-0.056011967,0.014862825,-0.018226566,-0.03675549,0.010327443,-0.004889709,0.00939202,0.06814411,-0.026361909,0.039231054,-0.007488105,-0.04558059,-0.01079043,-0.007303855,-0.03169098,0.0040794816,-0.0009655403,0.06791735,-0.059640273,-0.024869012,-0.061530016,-0.021845425,0.0010789249,-0.0041928664,-0.033901982,0.10884917,0.007530624,0.03624526,-0.02150527,-0.042557,0.011650262,0.010884917,0.005253484,0.01865176,0.035564955,-0.0020964332,-0.01182034,0.038002722,0.01666753,-0.02913983,-0.039873566,0.040931825,0.061756786,0.061265454,-0.05733479,0.11346014,-0.01519353,0.0028039054,0.0075117266,-0.01768799,-0.0027755594,-0.01636517,0.042670388,-0.07169683,-0.04233023,0.0089573795,-0.033448443,0.04754592,0.006056625,-0.035338186,-0.01343607,0.029404394,0.086550206,-0.0104880715,-0.005636157,-0.081788056,0.009580995,8.498305e-06,-0.01776358,-0.011092789,-0.076723546,-0.021032834,-0.06810632,-0.034903545,0.005461356,-0.019048605,-0.019558836,-0.012047108,-0.003500748,0.050040383,-0.027798112,-0.03254137,0.0176124,0.015495889,0.014692748,-0.0020739925,-0.011281763,-0.040894028,-0.06803073,-0.03734131,-0.06769058,0.04784828,0.037020057,-0.021391885,-0.033202775,-0.03169098,0.040024746,0.05321515,-0.015524235,-0.04270818,0.006283394,0.016412415,-0.021883218,0.033372853,-0.003951924,0.0069259065,0.00093128876,0.109907426,0.0067936243,-0.077479444,-0.065574065,0.046109717,0.003181854,0.115123115,-0.033864185,-0.08912026,0.07838652,0.085189596,-0.035073623,0.0053904904,-0.016932093,0.019445451,-0.031898852,-0.07517396,-0.010780981,0.013558903,-0.06625437,-0.021524167,0.013190403,-0.07245273,0.037832644,0.020787168,0.04123418,0.039911363,0.0961501,-0.023395013,-0.03206893,0.044938076,-0.024755627,-0.010355789,0.0264186,0.025379242,-0.09494066,0.02921542,0.01490062,-0.0009625876,0.046034127,-0.064062275,-0.05733479,-0.0013275441,0.010100674,-0.01137625,-0.004889709,0.043577462,0.019804502,0.035716135,0.039835773,-0.05752376,-0.0052251383,0.039949156,-0.0712055,-0.017083272,-0.097283944,-0.023678474,0.030084701,-0.042594798,-0.027420165,0.050531715,-0.04932228,-0.027476856,0.0055889133,-0.005092856,-0.0034889372,-0.01063925,-0.034317724,-0.05143879,-0.009349501,-0.020106861,-0.03552716,0.003474764,-0.035338186,-0.12086793,0.014220312,0.016384067,-0.0002087575,0.04886874,0.022317858,0.057561558,-0.007686528,0.055898584,0.05143879,-0.0726795,0.04051608,-0.061378837,0.06697247,0.011442391,-0.043842025,0.0352248,0.09879574,-0.034922443,-0.02687214,0.0116124675,0.027911497,0.0013665201,-0.048906535,0.010705392,0.028176062,-0.06640555,-0.0063920543,0.065725245,-0.079293594,0.031029573,-0.031029573,0.0061558364,0.052156895,-0.04762151,0.01967222,-0.024169806,0.050456125,0.06217253,0.016062811,-0.01445653,-0.03146421,-0.007502278,0.06508274,0.06171899,-0.032560263,0.016950991,0.08707934,0.06939135,0.03904208,0.018699002,0.019180886,0.058241867,0.010913263,-0.009968392,0.005158997,-0.04456013,-0.043842025,-0.06893781,0.023357218,0.006340086,-0.033864185,0.0080928225,-0.016865952,-0.0073227524,0.06296622,-0.015212428,0.020352527,-0.01688485,0.033958673,0.0067889,0.023886345,0.019275375,-0.042972744,-0.032125622,-0.010658148,-0.011877032,0.082241595,0.05888438,-0.00033129548,-0.035980698,-0.007866053,-0.042594798,0.0021566686,-0.04059167,-0.025265858,-0.05306397,0.003299963,-0.042519208,0.0075258994,0.048264023,0.050909664,-0.001299198,0.0029361874,0.01585494,0.04066726,-0.088062,-0.0045967987,0.077781804,0.03208783,0.021184014,-0.06958032,0.022034397,-0.011036096,0.021883218,0.008125893,0.026154036,-0.018613964,0.059489094,-0.04716797,0.052572638,0.02399973,0.061832376,0.029612266,-0.011404596,-0.030462649,0.0067889,-0.05990484,-0.025171371,-0.010658148,-0.008021957,0.02473673,-0.023980834,-0.06632996,-0.10582558,-0.0990981,-0.016025016,0.04762151,0.00040452302,0.08141011,0.013625043,0.05158997,-0.050947458,-0.08919585,-0.05245925,0.017669093,-0.024642242,0.00913218,0.02944219,0.039873566,0.004114914,-0.07052519,0.035791725,0.01049752,-0.023716269,0.029007548,0.019143092,-0.049738023,-0.0069306307,0.06179458,0.013889608,-0.04883095,-0.06549848,0.043653052,-0.04051608,0.022733603,0.0668213,0.03191775,0.0004644633,-0.026154036,0.019577732,0.008664469,-0.048188433,0.06338196,0.040062543,0.03926885,-0.01665808,-0.025057986,0.0028558734,-0.09811543,-0.019577732,-0.08496282,-0.0668213,-0.008385733,0.03652872,0.028308343,0.031218547,-0.034771264,0.107261784,-0.035168108,0.03660431,-0.0039991676,0.01181089,-0.021977706,0.013152608,0.0054282853,0.008494393,0.021013936,0.0116975065,-0.0572592,-0.036131877,0.012425058,0.027420165,0.011281763,0.043123923,-0.007596765,-0.039382234,-0.0763456,0.0022889506,0.0053243497,0.042897154,-0.086701386,0.027136702,-0.044862486,0.023432808,0.059564684,-0.010317994,0.005829856,0.052081306,0.010658148,-0.033675212,-0.013379377,-0.10476732,-0.013407723,0.012906942,0.02099504,0.04644987,-0.09342887,0.008744784,0.008820374,-0.009684931,0.012094352,0.04225464,0.047508128,-0.007757393,-0.028969754,0.061303247,0.050607305,0.033788595,0.030651623,-0.11436722,-0.052799407,-0.05899776,-0.03787044,0.0008114082,0.032635853,-0.11300661,-0.08677698,0.09478948,-0.01556203,0.09380682,0.06549848,-0.021165116,-0.037700363,0.06338196,0.018585619,-0.10121461,0.07649678,-0.0026527261,0.08828877,0.0932021,-0.075211756,0.087003745,0.07430468,-0.0271556,-0.054273404,0.057410378,-0.06266386,-0.005461356,0.058619812,-0.03193665,-0.057221405,0.001737382,-0.05227028,-0.033656314,-0.0025653255,0.008248726,0.03611298,-0.097283944,-0.015099043,-0.03736021,0.044371154,0.008503841,-0.0009560916,-0.040175926,0.006165285,0.01562817,-0.01218884,-0.028365035,-0.11058773,-0.039835773,-0.021977706,0.03652872,-0.061189864,-0.016988786,0.034374416,0.10930271,0.051060844,-0.08118334,0.014919518,-0.0067558293,0.043842025,-0.0077148736,0.043350693,0.00032539005,-0.044522334,-0.05850643,0.044371154,0.056503303,0.0020657247,-0.050985254,-0.01863286,0.03201224,0.07861329,-0.021184014,0.01651635,0.085038416,0.034941338,-0.09660364,-0.01599667,-0.046487667,0.008962104,0.014484877,-0.0087353345,-0.023527294,-0.0040960168,0.021089526,0.020541502,-0.05733479,0.038191695,-0.022431243,0.04542941,-0.02634301,-0.008782579,-0.025133576]	arcface-r50-fp16	0.7766237258911133	t	\N	2026-04-08 12:22:57.594107+00	\N	\N
cb48e7e5-393a-4fd7-a15b-c8ee04286a67	1	[-0.0361411,0.006225493,0.05619566,-0.009324834,0.0038500463,-0.08463667,-0.039294064,-0.051090866,0.004783066,-0.042361233,-0.012075633,0.031036306,0.0193682,0.047444582,0.037213538,-0.016847974,0.008225586,-0.07116687,-0.0015121351,-0.021223513,0.0070244577,-0.015164249,-0.022778546,-0.013083722,-0.008311382,0.008788615,0.018177794,-0.07489895,-0.020311942,0.0066651916,0.003287017,0.0033701311,0.045042325,0.09797778,-0.037213538,-0.036505733,0.017888237,-0.0040886635,-0.031207897,0.008263121,0.02608165,-0.029256063,-0.0041905446,0.003517591,0.052291993,0.053407326,-0.03397478,-0.012268671,-0.010595671,-0.024301406,-0.023572149,0.004405032,0.05405079,-0.01986152,0.012472434,0.06756349,0.025867162,-0.006504326,0.00255642,-0.061686534,-0.058168944,0.019647032,0.08257759,0.04911758,-0.041009963,-0.019089365,0.0059895567,-0.043862645,-0.04055954,0.021255687,-0.060914382,-0.021395104,0.0061075245,0.10758681,-0.006327374,0.018424455,0.00069373223,0.04795935,-0.071209766,-0.034124922,0.037835553,0.046200555,0.008686734,-0.05538061,0.059284277,0.00074199185,-0.00038473652,-0.026574971,-0.078845516,0.012397364,-0.08373582,-0.046886913,0.013598492,0.017427089,-0.113335066,-0.10998906,-0.026961049,-0.0022360296,0.0026100418,0.03144383,-0.0011341014,-0.023164624,0.124745786,-0.010043366,0.01748071,0.019346751,-0.03856481,-0.11376404,-0.037106294,-0.05992774,0.018317211,0.03436086,0.08347844,0.00481792,0.0077215414,-0.013630665,0.010901315,0.043390773,0.019421821,0.025137907,0.004257572,-0.03382464,0.007646471,0.002809783,-0.026853805,-0.027175536,0.017309122,0.00085325714,-0.07773018,0.037921347,-0.050361607,0.046715323,0.00068401324,0.015421634,-0.019604135,-0.020558603,0.05602407,-0.089998856,0.021094821,0.06473225,0.027733203,-0.019475443,-0.0005311911,-0.026017305,-0.03380319,-0.009721635,-0.051305354,0.053321533,-0.049932633,-0.037642512,-0.09814937,-0.026188893,0.03566923,-0.073826514,0.04748748,-0.017587954,0.008541955,-0.025867162,-0.033846088,0.044398863,0.007630384,-0.04169632,-0.032687858,-0.02195277,-0.0051289266,-0.006944025,-0.10115219,0.03047864,-0.005608842,0.026339035,0.0041208365,0.02256406,0.010295388,0.019432545,-0.011121164,-0.025288047,-0.042189643,0.03517591,0.120627634,-0.013952396,-0.073869415,-0.029599242,0.05233489,0.023850983,0.058683712,-0.025116459,-0.04529971,-0.09180055,0.069408074,0.010965661,-0.02037629,-0.01187187,-0.016890872,0.019378923,-0.05336443,0.0056839124,0.0035470831,0.041117206,0.025867162,-0.05233489,-0.010874504,0.030264152,-0.03950855,0.05619566,0.043519463,-0.029985318,0.02760451,0.0002131467,-0.012418812,0.0032682496,-0.04645794,-0.064517766,-0.026896702,-0.014424268,0.004809877,0.072110616,-0.043154836,0.0039197546,0.018553147,0.028741293,0.069708355,-0.016279582,-0.05602407,-0.08223441,0.021588143,0.09368803,0.022156533,0.0007212134,-0.08223441,-0.039637245,-0.01752361,-0.016279582,-0.08189123,0.012236498,-0.04559999,-0.003337958,0.019529065,0.08540883,0.03395333,0.03262351,-0.04311194,0.004525681,0.058254737,0.007828785,-0.06460356,-0.086738646,-0.104240805,-0.08776818,-0.022349572,0.0008539274,-0.073869415,-0.032837998,0.057654176,-0.002305738,0.0017346657,0.00496538,0.049889736,0.039015234,0.06820695,0.0028446373,0.03080037,0.04727299,-0.028312318,0.14096102,-0.007179961,0.010874504,0.039294064,-0.06430328,0.054265276,-0.0031100651,0.044827837,-0.05066189,-0.05773997,0.015679019,-0.055466406,0.0016234004,-0.03950855,-0.0454713,0.064474866,0.018413732,-0.02543819,-0.048388325,0.018285038,-0.03170122,0.042983245,-0.08618098,0.027003946,-0.03185136,0.052635174,-0.08223441,0.09892152,-0.014424268,0.0043111937,0.024944868,0.018799808,-0.016697833,0.017394917,-0.030156909,0.06777798,0.032730754,0.022799995,-0.008289932,-0.06679133,-0.04946076,-0.006257666,-0.024344305,-0.0039438843,0.040495194,0.07155295,-0.05992774,-0.0047508925,0.042768758,-0.013662838,0.07991795,0.10329706,-0.0046007517,-0.0024344304,0.047187198,0.069751255,0.028226523,-0.023143174,-0.080003746,-0.028398113,-0.052935455,0.035454743,0.004678503,0.045900274,-0.10621409,-0.11479358,-0.02425851,-0.029148819,0.016418999,-0.021909874,0.025888612,-0.044999428,-0.03704195,-0.01379153,-0.029084472,0.0044211186,-0.05821184,0.044999428,-0.017641576,0.008386452,-0.05979905,0.037599616,-0.024901971,-0.004906396,-0.0673061,-0.00047455306,-0.03959435,0.04356236,-0.016826525,0.026360484,-0.026832355,-0.02473038,-0.038779296,-0.044184376,-0.05572379,-0.021126995,-0.05366471,-0.032430474,0.047616173,0.034232166,-0.060485408,-0.018167071,-0.052635174,-0.03198005,0.055809584,-0.036119655,-0.029878074,-0.001833866,-0.017137531,-0.0011361121,0.010515238,-0.060614098,-0.023207521,0.005565944,0.028333766,-0.010579584,0.04388409,-0.036312692,0.053879198,-0.023829535,-0.049503658,0.0053031975,0.02691815,-0.009298023,0.110160656,-0.039958976,-0.068550125,-0.025373843,-0.000648824,0.046415042,-0.0057536205,-0.027711753,0.10252491,-0.027861895,-0.025523983,0.02421561,0.035755027,-0.057096507,-0.008525869,0.09506075,0.0038956248,0.017963307,-0.04963235,0.057782866,0.037234988,0.008869048,0.0538363,0.05353602,0.06434618,-0.049031787,0.031722665,-0.066576846,0.016944494,0.001804374,0.018982122,0.037149195,0.024966316,-0.0024893926,-0.06846433,0.032516267,0.04783066,0.05203461,0.011399997,0.043648157,0.026231792,0.07455577,0.028312318,-0.015947128,0.00469459,-0.018306488,-0.07374072,0.020944681,0.0021234239,-0.0066383807,0.03182991,-0.020086732,-0.055123225,0.0029384755,-0.08510854,0.017512884,-0.08862613,0.019486167,-0.03365305,0.04444176,-0.075714,0.020998303,0.001388805,0.05284966,0.01074045,0.0014129349,0.026167445,-0.044012785,0.029878074,-0.051133763,-0.020901782,-0.010756536,-0.028076382,-0.04141749,-0.1144504,-0.0011535393,0.006793884,-0.02507356,0.0048554554,0.030607332,-0.015593223,-0.026617868,0.06254449,-0.021609591,-0.008461522,-0.057825763,0.07086659,-0.004836688,-0.09746301,-0.06378851,-0.0043889456,-0.045814477,-0.05203461,0.02878419,0.008584852,0.015829159,0.027690304,0.010134523,0.0039251167,0.036612976,0.009968296,-0.043304976,-0.022435367,-0.015174974,0.022006392,0.051605634,0.089998856,-0.0022279865,-0.06752059,-0.09737722,0.043776847,0.045685787,-0.08129067,-0.05250648,-0.10201014,-0.0027025393,0.007946753,0.011260581,-0.061343357,-0.003965333,0.012676197,-0.03161542,-0.058640815,-0.0044774213,0.030564435]	arcface-r50-fp16	0.7498207688331604	t	\N	2026-04-08 12:23:11.071527+00	\N	\N
66f99dcf-1bd4-4f42-8dcf-21e41ce6c33f	1	[-0.061472706,-0.079653844,0.039002005,0.016481813,-0.017653193,0.005518685,0.022668678,-0.00649621,-0.039298978,-0.02968046,0.00079346565,0.013536864,-0.0041802595,0.049098972,-0.0224542,0.039496955,0.0060631293,-0.07991782,-0.019039052,-0.016960263,0.015029961,0.039694935,0.061208732,0.031759247,-0.09034475,-0.007634593,-0.009239054,-0.055005368,0.024879452,-0.048175067,0.024730967,-0.069622874,-0.039298978,0.038705036,-0.023361608,-0.007882068,0.035603356,0.06784105,-0.054279443,0.015797133,-0.038936015,0.011507572,0.081963606,-0.012934675,-0.00824503,-8.274934e-05,0.014716493,-0.0031614888,-0.03360706,0.011128111,-0.030719854,-0.018313125,0.04111379,-0.046327256,-0.051045775,0.05771109,0.021827266,0.017339725,0.01913804,-0.032600664,0.05909695,-0.022767669,0.045271367,0.0771461,-0.011144609,-0.02850908,-0.055302337,-0.03332659,-0.06411243,-0.0151042035,-0.0065003345,-0.05909695,0.03428349,0.0072303847,0.021926256,0.07595822,0.0011631309,-0.030043423,-0.018593596,-0.06497035,-0.005077355,0.055797286,0.013635854,-0.019501003,0.08829896,0.031891234,0.011920029,0.0030501252,0.010237202,-0.046723217,-0.060515806,0.15482014,0.027420193,-0.047185168,-0.015021712,-0.04424847,-0.04754813,-0.036263287,0.050814796,0.028212111,0.0009754626,-0.013462622,0.03233669,0.058140047,0.0137100965,0.029136017,0.022635683,-0.099979766,-0.030340394,0.038639043,-0.0017065441,-0.009346293,0.024681473,0.01581363,0.032105714,0.008826597,-0.036461268,-0.015986864,-0.0025881724,0.0849333,-0.059426915,-0.021447804,-0.008950334,-0.012678952,-0.031049822,0.019764977,0.026331304,0.02217373,-0.01347087,0.033343088,-0.082425565,-0.057381123,-0.06520133,-0.05206867,0.025506388,-0.05038584,0.047218166,-0.07747607,-0.033656552,0.023378106,0.025341405,-0.11726999,-0.034844432,0.0065292064,0.0034790812,-0.038837023,0.024351507,0.024351507,-0.056292236,-0.0008919399,0.049296953,0.001299242,0.03652726,-0.053157557,0.036989212,0.050352845,-0.0149969645,0.046162274,-0.034547463,0.029993929,-0.011573565,-0.0027469688,-0.019121543,0.010905383,0.00850488,0.027783155,-0.032881133,0.113838345,0.039793927,0.0050361096,-0.039727934,-0.007461361,0.05117776,-0.038045105,-0.008075923,0.071074724,-0.06460738,0.02157979,0.11067067,0.034712445,-0.09047674,-0.05068281,0.028162617,-0.064871356,0.0059352675,0.01923703,0.0057455366,-0.050847795,0.054345436,-0.01913804,0.020474404,0.060020857,0.051342744,-0.0351744,-0.056127254,-0.030901337,0.03451447,0.029993929,-0.00649621,-0.0003933816,-0.0130666625,-0.01543417,-0.018313125,0.046822205,0.09417236,-0.02862457,-0.038936015,-0.056094255,-0.048472036,0.047515135,-0.042565644,-0.05820604,-0.0185606,-0.007597472,-0.024335008,0.09456832,-0.06889695,0.014040062,-0.012332487,0.012118009,-0.011631309,-0.009404037,-0.041542746,-0.01533518,0.05460941,0.03279864,0.0058445265,0.025852853,-0.12155955,0.013553362,-0.05724914,-0.016300332,0.019369017,0.011548817,0.016457066,0.038837023,-0.0023015144,0.049065977,0.06064779,0.06701614,-0.04111379,-0.061769675,0.029251505,0.054147456,-0.04474342,-0.037682142,0.054840386,-0.064409405,-0.008150166,0.011383834,0.039529953,-0.0165973,0.037649147,-0.008942084,0.035867326,-0.021101339,-0.059294928,-0.013396628,-0.05823904,0.035240393,-0.016044607,-0.0341845,0.020028949,0.009783498,-0.056985166,-0.0067478092,-0.051507726,-0.056589205,-0.021810766,0.015491914,0.031775746,-0.02314713,0.021431306,0.013223397,0.042433657,-0.030389888,-0.030983828,-0.070546776,0.043390557,0.16141947,-0.01816464,-0.053652506,-0.031775746,0.03778113,-0.021744773,-0.013396628,0.005918769,-0.03378854,0.013619356,-0.05223365,-0.0034027766,0.04279662,-0.0066116983,-0.015780635,-0.016638547,-0.010501175,-0.002891329,-0.011697303,0.09239054,-0.0048133824,-0.03271615,-0.012167504,-0.10492925,-0.017719185,-0.019979455,-0.07265856,0.03850706,-0.030356891,0.037154198,-0.0077253343,-0.0019581432,0.07846597,-0.03566935,-0.022256222,0.06173668,0.03642827,0.025093932,0.029317498,0.13924575,-0.02255319,0.008620367,-0.038111098,-0.034250494,-0.006619947,-0.059162945,0.008372893,0.05187069,-0.070546776,0.04045386,-0.013668851,-0.044215474,0.0023510093,-0.028773054,-0.039727934,-0.12961073,-0.06777506,-0.0049288706,0.054972373,-0.030290898,-0.048307054,-0.015846627,0.0043514296,0.06084577,-0.021744773,0.07991782,-0.052959576,-0.026100328,-0.057447117,0.04081682,-0.014081309,-0.033541065,-0.039232984,0.08869492,-0.003967844,0.021992248,-0.019550499,-0.027783155,-0.0351414,-0.014592756,0.01865959,0.012984171,0.026991237,0.03985992,-0.040255878,-0.03401952,-0.026248813,-0.021365313,-0.017257234,0.00087853504,0.0052423384,-0.05889897,-0.075430274,0.005658921,-0.103807375,-0.050022878,0.010179458,-0.061274726,-0.037220187,-0.040189885,-0.012753194,0.027997633,0.038441066,-0.055797286,-0.0020251677,0.03827608,0.035042413,0.069094926,0.06691715,0.0103856865,0.0010940442,0.048802003,0.12584911,0.004256564,0.021596288,0.026694266,0.068369,0.002557238,0.010723902,-0.08744105,0.032881133,-0.050022878,-0.054312438,0.03827608,-1.461325e-05,-0.025407398,-0.0673461,0.011705551,0.059063952,0.058140047,1.8689492e-05,-0.031412784,0.11172656,-0.09305047,0.0028603945,-0.06949089,-0.02949898,-0.084273376,0.08262354,-0.0020189807,0.053091563,0.013751342,-0.06200065,0.04675621,0.009874239,0.035075407,0.0030295022,0.057150148,-0.021150835,0.05830503,0.04523837,-0.09120266,0.017240735,0.017504707,-0.019583495,-0.017983159,0.016696291,0.098593906,0.015285685,0.02189326,-0.047218166,-0.031379785,-0.0312478,0.022520194,-0.009404037,-0.030505376,-0.030224906,-0.0036275662,-0.04992389,-0.01925353,-0.028245108,0.009684509,-0.014518513,0.0048422543,0.0527616,0.03467945,-0.018280128,-0.05675419,0.032006722,-0.0042689377,0.027651168,-0.028921539,-0.05510436,0.012118009,0.045832306,0.024417501,0.070480786,-0.045007393,0.025357904,-0.027865646,-0.011474575,-0.017059254,0.03665925,0.0004248315,0.09074071,0.066851154,-0.07001883,-0.012885181,-0.020441407,-0.028690562,-0.03702221,0.04659123,0.08064374,0.038408067,0.056820184,0.024433998,0.0015436232,-0.03329359,-0.04748214,-0.008521377,-0.015714642,-0.025539385,-0.020243427,0.03464645,0.044809412,0.060086846,0.021612788,-0.072922535,0.043027595,-0.0029098897,-0.060977757,-0.031874735,-0.043588538,0.08354744,-0.018230634,-0.021645784,-0.032947127,-0.01768619,-0.022536693,0.039035004,-0.07991782,-0.07279055,0.015351678]	arcface-r50-fp16	0.8227584362030029	t	\N	2026-04-08 12:23:52.30929+00	\N	\N
bf545451-1567-4625-b860-9f721ad1188b	1	[-0.029654061,-0.069683306,0.009109459,-0.03466707,0.11013653,-0.06933414,0.08340049,-0.036412895,-0.041450843,-0.075718865,-0.049556453,-0.04132614,0.013866828,0.06514417,0.004988068,-0.06035562,0.011827955,0.116122216,-0.056764208,-0.0018533788,0.01255746,-0.043695472,-0.07013223,-0.057911463,0.01843091,0.02728473,0.038707405,-0.13617425,0.08489691,-0.00035929674,0.00057908345,-0.03920621,0.04122638,-0.032247856,0.009140634,0.0091842795,-0.05851003,-0.04945669,0.05990669,0.026835803,-0.009483564,0.000905646,-0.012145945,-0.025613727,-0.053671606,-0.04566576,0.06294941,-0.06723915,0.013305671,0.04072757,0.00028700873,0.015001614,-0.04047817,-0.03322053,-0.03997936,-0.0035571158,-0.07317495,-0.026985446,0.042298812,-0.051576618,-0.01853067,0.04499237,-0.068336524,0.04950657,-0.0102941245,-0.015525361,-0.069683306,-0.038507883,0.025937952,0.02573843,0.02499022,-0.0155503005,0.05172626,0.00023323113,-0.002983488,0.011940187,0.011528672,0.01543807,-0.043146785,-0.052125305,0.104150854,-0.017046722,-0.061452992,0.0704814,0.027808476,-0.040278647,0.009520974,-0.0034854123,-0.022284193,0.025339384,-0.0008518684,-0.056015998,-0.084348224,-0.07157877,-0.10844059,0.0066902456,-0.014477866,0.049930558,0.013580014,-0.002494034,0.005427641,0.06524392,0.017607879,0.11322913,-0.050479244,-0.0012781923,-0.07053128,-0.0591086,-0.027633894,-0.01328073,0.0145277465,-0.02060072,-0.044368863,0.021411281,0.034866594,-0.07467137,0.034292966,0.004093333,0.040153943,0.1050487,-0.010044721,-0.07147901,0.02497775,0.03022769,-0.05621552,-0.059308123,-0.013567544,-0.049755976,-0.0753697,0.04047817,-0.07207758,0.031399887,-0.002981929,0.030302512,-0.025526436,-0.030152868,-0.012015007,-0.0012010331,0.03399368,0.012931565,0.036487713,0.01621122,0.032721724,0.019253941,0.012993916,-0.02499022,0.037136164,-0.024404122,-0.05027972,-0.07122961,0.0017333535,-0.017333535,0.0006172734,-0.059258245,-0.014041411,0.009433683,0.022034789,0.02060072,0.013792007,0.080806695,-0.032971125,-0.00044424977,-0.009826493,-0.04202447,0.01551289,0.052923396,-0.0143531645,-0.00992002,0.040677693,-0.0034074737,-0.08749071,-0.07452173,-0.019702867,0.047536284,-0.013567544,-0.023194514,0.06414655,-0.026686162,-0.049805854,-0.07891123,0.011740664,-0.048159793,0.01069317,-0.014577627,-0.0017208833,-0.046064805,-0.064794995,-0.052773755,-0.013205909,0.029679002,0.05895896,0.009146869,0.04638903,0.02351874,-0.033345234,0.012688397,-0.0033607106,-0.088189036,0.022508655,0.009053343,-0.051177572,0.022034789,-0.032996066,0.0073449295,0.019815098,-0.048783302,-0.008136786,-0.0035539982,-0.05606588,-0.0008962934,-0.030427212,0.012046183,0.03539034,0.0013413226,-0.016286042,0.03169917,0.0020794007,-0.0018970245,0.039405733,-0.015837114,0.05531767,0.06823677,-0.01035024,-0.0056427517,-0.02583819,0.040378407,0.017819872,-0.027184969,0.05177614,-0.003248479,-0.0062070265,0.016423212,0.037435446,0.016086519,0.05092817,0.07816302,0.046937715,0.040802393,0.059457764,0.032696784,0.0077065644,-0.016710026,-0.018967127,-0.011709489,0.0309759,-0.06693987,-0.0206506,-0.022246782,-0.070930324,-0.039455615,-0.0132932,-0.04576552,0.08734106,-0.03404356,0.03449249,-0.025962891,-0.0010233333,0.004938187,0.05970717,0.0074010454,-0.030078048,-0.071728416,0.048508957,-0.0016257983,0.03396874,-0.010344005,-0.00011437483,-0.07028187,0.031100601,-0.09846445,0.017221304,-0.029379718,0.0040559224,0.0034760595,-0.092528656,-0.0125138145,-0.037385568,0.009639441,0.002797994,0.0046139625,-0.023082282,0.031948574,0.006790007,0.07372364,0.018854896,0.008716648,-0.018006925,0.04277268,0.022558536,-0.0784623,-0.0035882911,-0.0058453917,0.06614178,0.005209413,-0.0068274178,-0.050329603,0.091181874,0.022645827,-0.027633894,0.049780916,-0.055816475,0.0043489714,-0.012258176,0.058160868,0.0029226958,-0.044518504,-0.04576552,-0.0033482404,0.100609325,-0.0413012,-0.0068274178,-0.030626735,-0.010450002,0.072726026,-0.028581627,0.0047978973,-0.034467548,-0.021211758,-0.003064544,0.00515018,-0.01997721,-0.121210046,-0.003840812,0.112331286,-0.0057799234,-0.012208295,-0.0044705556,0.0041775065,-0.06424631,0.06958354,-0.025613727,0.040303588,-0.056265403,0.0049755974,-0.079260394,-0.017844811,-0.015650062,0.007606803,-0.06464536,-0.07432221,0.0070394105,0.031424824,-0.008984757,0.04628927,0.00035676375,-0.05177614,0.004202447,-0.04718712,0.009770378,-0.09103224,0.005954506,0.063248694,-0.030751437,0.048808243,0.0012181796,-0.0071142316,0.0021292814,-0.092728175,-0.07107996,-0.05327256,-0.006952119,0.020812713,-0.097616486,0.0033794157,-0.08958569,0.013580014,-0.023369096,-0.031449765,0.07831266,-0.0024005075,0.00815549,-0.016273571,0.05095311,0.0036101139,0.030676616,0.050354544,-0.0015954023,-0.024104837,0.0031175422,-0.03471695,-0.013018857,0.03095096,0.0065218983,-0.035963967,-0.0116970185,-0.02359356,0.011260563,0.10355228,0.00030123253,0.013492723,0.012071123,-0.01988992,0.023406507,-0.023855433,0.025414204,0.07766421,0.041550603,-0.06783772,0.003195481,-0.014041411,-0.049556453,0.027933178,0.09262841,-0.007662919,0.024690935,0.06409667,0.09457376,0.021186817,0.001144138,0.026611341,-0.015774764,0.10105825,0.013642365,-0.045491178,0.021660684,-0.009252866,0.0074384557,0.012526285,-0.00238492,0.0459401,-0.023119694,-0.050529126,0.025588786,0.09302746,-0.021872677,0.05606588,0.032671843,0.061353233,0.028382104,-0.0064034318,0.022234311,0.056165643,0.10275419,-0.083051324,0.06748855,0.063547984,0.024728345,0.12500097,0.029005613,-0.02798306,-0.005938918,-0.03449249,0.05761218,0.066091895,-0.047536284,0.052973278,0.036562536,-0.0428475,-0.019328762,0.0114039695,-0.021922557,0.08035777,0.031050721,0.01631098,-0.012401583,-0.03616349,0.024902927,-0.049581394,0.055018384,-0.0083674835,0.057861585,-0.020151794,-0.06554321,0.10375181,-0.050329603,0.016423212,-0.010537293,0.044343922,0.004264798,0.04574058,-0.010132012,0.06125347,0.007743975,0.03696158,0.0295543,-0.062550366,0.00572069,-0.036587477,-0.039281033,-0.0053216447,0.039405733,-0.017059192,0.026262175,0.020999765,0.037285805,0.10784202,0.06130335,0.028681388,-0.056514807,0.024030015,0.02368085,-0.006771302,0.06205156,0.061452992,-0.03312077,0.017882222,-0.00442691,-0.02070048,-0.083350606,-0.094224595,0.01321838,-0.0037909313,-0.00066169834,0.055616952,0.01998968,0.010418826,-0.058559913,0.0032173037,0.027160028,0.0033451228,0.010923868,-0.026760982]	arcface-r50-fp16	0.6469058394432068	t	\N	2026-04-08 12:24:50.409895+00	\N	\N
e0b6aab7-21ce-4cda-9b07-1e307c15e770	1	[-0.013827527,0.033752717,-0.028086202,0.010265425,-0.0070728776,0.088118404,-0.00061817106,-0.012297979,0.026505327,-0.028578943,0.037078712,0.03777676,0.041308068,0.039213922,0.004085639,0.045167867,0.027942486,0.009341536,0.05613134,0.015490525,-0.017091932,0.064261556,0.015459729,0.020376869,-0.07115992,-0.019288734,0.013704342,-0.0575685,0.039090738,-0.015777957,-0.010727368,0.0069496925,-0.0007545087,-0.10265425,-0.06467217,0.007113939,-0.032993075,-0.0081250835,-0.036832344,0.06701269,0.047179893,0.012616207,0.084833466,0.00038816137,0.0078017227,0.032664582,-0.0069445595,-0.0053226226,-0.067382246,-0.02297402,0.099040814,0.025725154,0.013817262,-0.054283567,-0.048247494,0.09953356,0.006179786,-0.08606532,0.056008156,-0.030118756,-0.05465312,0.016096186,-0.0644258,0.08425861,0.03260299,-0.026710635,0.093456425,0.051080752,0.032828826,-0.022029601,0.032253966,-0.067587554,-0.008520302,-0.032582458,0.012739392,-0.0015577782,0.018765196,0.016044859,-0.052805346,0.03354741,0.0004263359,0.029933978,0.016055124,-0.013765934,0.028188856,0.0043217437,-0.06479536,0.03143273,-0.0021095448,-0.004488557,0.033526875,0.022542872,0.016650518,0.009495518,-0.093538545,-0.04861705,0.010280822,0.03652438,0.054981615,0.015008051,-0.013611953,0.014063632,0.016157778,0.010060116,0.052066233,0.014381859,0.007935173,0.027039127,0.0072884513,0.034840852,-0.06701269,-0.0046605025,0.06869622,0.07645688,-0.07206328,-0.05732213,0.012503287,-0.061879978,0.037058182,0.026176833,0.008063491,-0.015500791,0.03459448,0.08216446,-0.020941466,0.027839832,0.08540833,0.0156034455,-0.08737929,-0.07243284,-0.087954156,-0.104296714,-0.08397117,-0.0133758485,-0.030406188,-0.027018597,0.04960253,-0.028188856,0.04520893,-0.021249428,-0.014217613,0.03190494,0.011230375,0.052558973,-0.033958025,0.020109966,0.006025804,0.029420707,-0.021208366,0.044141326,-0.10593918,-0.052887466,0.015244155,0.01038861,0.08113792,0.019606961,0.015131236,0.030508842,0.021013323,0.020428196,-0.04446982,0.039357636,0.019986782,0.00089116715,-0.013642749,-0.045783795,-0.0063081034,-0.039501354,-0.11645097,0.012770188,0.066437826,-0.027757708,0.0055227983,-0.03291095,-0.05539223,0.050341643,0.036319073,-0.004409,0.039583478,-0.037550922,-0.05009527,-0.00092645455,-0.09813746,0.0454553,0.03843375,0.035846863,0.031987064,-0.02586887,0.027778238,0.0010464317,-0.023364106,0.011856565,-0.02178323,0.00859216,-0.0042473194,-0.02223491,0.037674107,-0.018087678,-0.0037366145,-0.022440217,0.018097943,0.015962735,-0.11094871,-0.07896165,0.045537423,-0.037325084,0.040178873,0.0067238533,-0.065164916,-0.032253966,-0.021742169,0.113740906,-0.019894393,0.03870065,0.004065108,0.04590698,-0.031576447,0.0072884513,-0.044305574,0.03510775,0.024575427,0.0010669626,0.03738668,-0.050834384,0.017215118,0.044839375,0.012482757,0.017985024,-0.059210967,0.015377606,0.0040574092,-0.022111725,0.009362067,0.02779877,0.04323797,0.050834384,0.049643595,-0.00545094,0.016044859,-0.03627801,0.048001125,-0.08331419,0.046810336,0.00592315,-0.0072114607,-0.029441237,0.021475269,0.033013605,-0.019760942,0.041903462,0.027839832,-0.02490392,0.0069496925,-0.012277448,0.0075758835,0.134436,-0.034491826,-0.0035980314,0.051532432,-0.0029128143,0.0072268588,-0.0029872386,-0.05391401,0.088118404,0.0688194,0.035497837,0.013683811,-0.10667829,-0.041451786,-0.052394725,-0.031761225,-0.06146936,-0.019986782,-0.0014435754,-0.013632484,0.029851854,-0.022542872,-0.024698611,0.031638037,-0.05391401,0.012913904,-0.019843066,0.049848903,-0.08491559,-0.0360727,-0.052066233,0.0297492,0.030098224,-0.028989559,0.0025342768,-0.092306696,0.039829846,-0.01864201,-0.01402257,0.024493303,0.014710354,-0.02515029,0.0007724732,0.076539,0.03284936,0.011990016,-0.09099273,-0.072843455,-0.004308912,0.02270712,-0.021906417,0.0042909477,0.0435254,-0.00985994,-0.032767236,0.0012594393,-0.06208529,-0.034820322,-0.025458252,0.05489949,-0.09600225,0.038084727,-0.12211749,-0.025807278,-0.061346177,-0.000421524,-0.060566004,0.03219237,-0.044880435,0.0144537175,0.062249534,-0.017995289,-0.12014653,-0.071816914,-0.013150009,-0.043853894,-0.055063736,0.055474356,0.031350605,-0.11365878,0.06894259,-0.010327017,-0.023097206,0.061838917,0.041451786,-0.0608945,-0.072843455,0.02708019,0.014073897,0.026484795,-0.034019616,-0.042663105,0.01148701,0.025950992,0.018005555,-0.04787794,0.048329618,-0.014258674,0.002681842,-0.02611524,0.022358095,0.044346634,0.028681597,-0.037304554,-0.035846863,-0.013611953,0.048247494,0.034512356,0.06360457,0.009028441,0.07908483,-0.037797295,0.056952577,0.017143259,-0.001347337,-0.008802601,0.05777381,0.020510318,0.05514586,0.038310565,-0.03943976,-0.020263948,-0.04475725,-0.05494055,-0.010296221,-0.0098034805,0.016270697,-0.03096052,-0.06844985,-0.08507984,0.037838355,0.021885885,0.019432448,-0.06890153,0.0011253472,-0.061305117,0.03964507,-0.0054252767,-0.02681329,0.1010939,0.010152505,0.019103955,-0.048288558,-0.004814484,-0.10856713,-0.027449746,-0.034163333,-0.022604465,0.049479347,-0.038967554,0.0410617,-0.07202222,0.02537613,-0.013765934,0.023610476,-0.03358847,-0.02463702,-0.0005103841,0.061510425,0.019422183,-0.042457797,0.034881912,-0.09748047,-0.054201443,-0.085901074,-0.022748182,0.005253331,0.09362067,-0.016075656,0.013457972,-0.023877377,-0.05925203,0.012903639,-0.010167903,0.031165829,-0.038823836,-0.0060668658,0.013755669,-0.059375215,-0.014576903,-0.017759185,0.11776495,0.05925203,-0.076128386,0.08721504,0.0006691774,0.040959045,-0.020510318,-0.018251926,-0.019514572,0.06705375,0.018436702,-0.022132255,-0.018056883,-0.055515416,-0.0493151,-0.07444486,-0.017492283,0.016876359,0.03362953,0.03383484,0.014648761,0.053544454,-0.014576903,-0.014114959,0.0046014767,-0.008417648,-0.061797857,0.026649043,0.006297838,0.014073897,0.01691742,-0.024862858,-0.06352245,-0.0035415716,0.022501811,-0.035415716,-0.029318053,0.047713693,0.04307372,0.03962454,-0.009403129,-0.015305748,0.029359113,-0.016239902,-0.033465285,0.0144537175,-0.038043663,-0.060853437,0.009033574,-0.006261909,-0.006800844,0.021331552,-0.0028768852,0.058636107,0.042868413,-0.0057024434,0.07703175,-0.031822816,0.06302971,0.019216875,-0.027963016,0.036401197,0.048945546,0.002615117,0.046112288,-0.01922714,-0.0053072246,0.06984595,0.049643595,-0.12679853,0.022009071,-0.021249428,-0.0023379505,0.006744384,-0.009259413,0.085983194]	arcface-r50-fp16	0.7364015579223633	t	\N	2026-04-08 12:25:03.619531+00	\N	\N
c514ce06-cb7c-44e5-ba67-68289605998f	2	[0.024380859,0.011485343,-0.035312623,-0.011479516,-0.04908804,0.0074820803,-0.021374041,-0.03405395,-0.044612776,0.010145094,0.04559174,-0.01118233,-0.047572978,0.024753798,-0.01894994,0.00974302,-0.05030009,-0.017831126,0.008641686,-0.06941319,0.11766212,0.0058533875,-0.02804032,0.03706077,0.0021735325,-0.044636086,-0.030604271,-0.036594596,0.04633762,-0.05235125,0.04244507,0.01671231,0.020465003,-0.06302662,0.032119334,-0.040114205,0.051931698,0.036478054,0.050160237,0.0074004997,-0.045451887,0.0014385814,0.04820231,0.02822679,-0.0433308,0.008857291,-0.07109141,0.018553695,0.02298234,-0.0067536845,0.04300448,0.100879885,0.07160421,0.03859914,-0.011293046,0.02417108,0.022609401,-0.06959966,0.047433123,-0.050859496,0.1490822,0.07430801,0.049973767,0.08134723,0.056966368,0.004731658,-0.025686145,0.016968705,0.04368043,-0.1138395,-0.057199452,-0.06521763,0.054635502,-0.03428704,-0.049787298,0.09323464,-0.0069692894,-0.06978613,0.10069341,-0.037317164,-0.058970913,-0.0036419781,-0.04211875,-0.031256914,-0.010197539,-0.024800414,0.08759395,-0.012446824,-0.07081171,0.004437386,0.08913232,0.06908687,-0.0026397058,0.04820231,-0.060322814,0.03377425,-0.049367744,0.036967535,0.045568433,-0.02887943,0.008274575,-0.053656537,-0.033844177,-0.013029542,-0.036850993,0.029625308,0.01453295,0.010337391,0.10060018,0.03223588,0.08092767,0.008379463,-0.027014738,-0.0027882985,0.09262862,-0.006136005,-0.075659916,-0.07449448,0.029462148,0.09029775,-0.0075636604,0.029252369,-0.027877158,-0.035079535,-0.06004311,0.02608239,0.018040903,-0.033867486,-0.006876055,-0.04421653,-0.051045965,-0.06871393,-0.056640044,-0.015978087,-0.08819997,-0.021455621,-0.0032282495,0.018658582,0.04454285,0.002820348,-0.03370432,-0.006567215,-0.055101674,-0.07477418,-0.038342748,-0.06228074,-0.051465522,0.04228191,-0.075053886,0.07556668,0.0121904295,0.050160237,-0.035056226,-0.06684924,-0.0149641605,0.061022073,0.05216478,0.014661147,0.03293514,-0.016863815,0.023937995,-0.006357437,0.045871444,-0.008187167,0.008997143,-0.02435755,-0.050533175,-0.035312623,0.033144917,-0.0045743245,0.023040611,0.038016427,0.04801584,-0.012435171,0.043051098,0.031723086,-0.005282325,-0.069366574,0.01938115,0.029019283,-0.012435171,0.03967134,0.10106635,-0.008461044,-0.06526425,0.018285645,0.023262043,0.00389546,0.045824826,0.03442689,-0.028576419,0.06745526,0.029532073,0.033517852,-0.03899539,0.018565347,0.035172768,0.016141247,-0.018751817,0.04852863,-0.019008214,-0.014707765,0.003435114,-0.029298987,0.051978312,-0.01305285,-0.01915972,-0.032119334,0.028995974,-0.021455621,-0.040953316,0.056966368,-0.026059084,-0.04647747,-0.05603402,0.0072839563,-0.053003896,-0.095845215,-0.053003896,-0.016339371,-0.014707765,0.034496818,-0.043097712,0.013763764,-0.0034292866,-0.03792319,-0.028995974,-0.0040848427,-0.0035778794,-0.049554214,0.047246654,0.051791843,0.04731658,-0.035802104,0.0866616,0.012633294,-0.00040972256,0.031979483,0.03375094,0.060462665,0.031280223,-0.04768952,0.029252369,0.022947377,-0.009346773,0.104888976,0.015954778,-0.008321192,0.041885663,-0.011479516,-0.0476429,0.050906114,0.007965735,-0.026222244,0.043400727,0.0678282,-0.048854955,0.05827165,-0.021164265,0.028926048,-0.045661665,-0.049134657,0.017877743,0.014696111,0.014463024,0.0059204,-0.05291066,-0.018716855,-0.006800302,-0.0060952147,0.0034263732,-0.103956625,-0.024823723,-0.091509804,-0.023984611,0.054588884,-0.012656603,0.004434473,0.0019870633,-0.0033360522,0.025546292,0.11477184,-0.07444786,0.030511037,-0.008851464,0.030487727,-0.030907284,-0.0025726934,-0.048621867,0.03442689,-0.043097712,0.055800933,-0.027224516,0.0067653386,0.014882579,0.009999416,0.054542266,0.031629853,-0.032142643,0.04162927,0.020348461,-0.025266588,-0.092488766,0.034939684,0.053656537,0.023961304,0.0125866765,-0.004020744,0.06848084,-0.066756,0.024217699,0.02869296,-0.01706194,-0.011735911,0.02594254,0.0045218803,0.023704909,-0.024404168,0.021304116,-0.035289314,-0.010296601,-0.10041371,-0.017551422,-0.025476366,-0.023891378,-0.024777107,-0.07710505,-0.040277366,-0.039228477,0.051791843,-0.026781652,0.019451078,0.057525776,0.00237457,0.041908972,-0.026245551,-0.06941319,-0.016677346,-0.0050638067,-0.046057913,0.030557655,0.01180001,-0.02871627,-0.0083445,-0.104609266,-0.05603402,-0.013553986,-0.05761901,-0.0105063785,-0.059297234,-0.0063283015,0.017504804,0.07980885,0.05137229,0.021245845,-0.05738592,-0.024683872,-0.036175042,-0.0019025694,-0.003414719,0.0675485,0.07290949,-0.03081405,0.01515063,0.109923646,0.040463835,-0.055148292,0.08251266,0.039974354,0.028762888,0.08489014,0.065310866,-0.040440526,-0.06642968,0.06092884,0.00033961446,0.0025945453,0.00017062668,0.010733638,-0.03218926,0.043750357,-0.047736138,-0.021677054,0.05738592,-0.049880534,0.065357484,-0.031443384,0.035056226,-0.04302779,0.041163094,0.007965735,0.054029476,0.031117063,0.02577938,-0.048295546,0.029275678,-0.032678742,-0.01539537,-0.06209427,-0.06381911,0.048109077,-0.027644072,-0.025522983,0.04685041,0.032445654,0.027271133,-0.01313443,0.0067886473,0.013414134,0.0113396635,0.016992014,0.022959031,-0.036454745,0.011893244,-0.017656311,0.045708284,-0.05342345,0.02298234,-0.007930771,0.028413257,-0.051279053,-0.05067303,0.038366057,0.015488605,-0.017248409,0.028296715,-0.015791617,0.034869757,0.031979483,0.0010452478,-0.00016325168,0.06456499,0.0010685564,-0.03344793,-0.005591165,0.036501363,0.030068172,-0.0042771394,-0.035009608,0.043796975,-0.037666794,0.0349863,0.011677639,-0.0064623263,0.021105992,0.03065089,-0.049227893,-0.035522398,0.0661966,-0.005940795,-0.05258434,-0.04687372,-0.08195325,0.05710622,0.07780431,-0.023704909,-0.012015615,0.034333657,-0.06004311,-0.0035574844,-0.0068527465,-0.009900354,0.040323984,0.027737306,-0.05645358,-0.06605674,0.030161407,-0.013449097,0.042701468,-0.09430684,-0.035009608,-0.035126153,-0.046267692,0.00020249399,-0.029881703,-0.05137229,0.06959966,-0.040766846,0.102278404,-0.0054921033,0.049321126,-0.07524036,0.055800933,-0.024124464,0.050393324,0.017784508,0.054076094,0.0010073712,-0.018157447,0.030184716,0.0654041,-0.019625893,-0.029462148,0.06251383,0.033494547,0.01698036,0.03426373,-0.030557655,-0.06955304,-0.004256744,0.07477418,-0.034496818,0.005739758,0.05379639,-0.07379522,0.021222536,0.059064146,0.0651244,-0.06787482,-0.029671926,0.02594254,0.006240894]	arcface-r50-fp16	0.7364015579223633	t	\N	2026-04-08 13:30:53.400421+00	\N	\N
\.


--
-- Data for Name: facility_device; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.facility_device (pk_device_id, tenant_id, customer_id, site_id, unit_id, external_device_id, name, location_label, ip_address, status, recognition_accuracy, total_scans, error_rate, model, last_active) FROM stdin;
1	1	1	1	\N	jetson-orin-01	Jetson Orin NX	Main Entrance	172.18.3.202	online	0.00	0	0.00	\N	2026-04-09 01:59:40.67853+00
2	1	1	1	\N	entrance-cam-01	Entrance Camera	Main Entrance	172.18.3.202	online	2.00	90000	0.00	\N	2026-04-09 01:59:40.679477+00
\.


--
-- Data for Name: frs_building; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_building (pk_building_id, fk_site_id, name, address, created_at) FROM stdin;
\.


--
-- Data for Name: frs_camera; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_camera (pk_camera_id, fk_nug_id, fk_floor_id, fk_zone_id, name, cam_id, rtsp_url, ip_address, model, status, recognition_accuracy, total_scans, error_rate, last_active, map_x, map_y, map_angle, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: frs_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_customer (pk_customer_id, customer_name, fk_tenant_id) FROM stdin;
1	Default Customer	1
\.


--
-- Data for Name: frs_customer_user_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_customer_user_map (fk_user_id, fk_customer_id) FROM stdin;
\.


--
-- Data for Name: frs_floor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_floor (pk_floor_id, fk_building_id, floor_number, floor_name, floor_plan_url, floor_plan_data, created_at) FROM stdin;
\.


--
-- Data for Name: frs_nug_box; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_nug_box (pk_nug_id, fk_site_id, fk_building_id, fk_floor_id, fk_zone_id, name, device_code, ip_address, port, match_threshold, conf_threshold, cooldown_seconds, x_threshold, tracking_window, status, cpu_percent, memory_used_mb, memory_total_mb, gpu_percent, temperature_c, disk_used_gb, uptime_seconds, last_heartbeat, map_x, map_y, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: frs_site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_site (pk_site_id, site_name, fk_customer_id, timezone, timezone_label, location_address) FROM stdin;
1	Main Site	1	Asia/Manila	Philippine Standard Time (UTC+8)	\N
\.


--
-- Data for Name: frs_telemetry_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_telemetry_history (pk_history_id, fk_nug_id, "timestamp", cpu, gpu, ram) FROM stdin;
\.


--
-- Data for Name: frs_tenant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_tenant (pk_tenant_id, tenant_name) FROM stdin;
1	Motivity Labs
\.


--
-- Data for Name: frs_tenant_user_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_tenant_user_map (fk_user_id, fk_tenant_id) FROM stdin;
\.


--
-- Data for Name: frs_unit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_unit (pk_unit_id, unit_name, fk_site_id) FROM stdin;
\.


--
-- Data for Name: frs_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_user (pk_user_id, email, username, fk_user_type_id, role, password_hash, department, created_at, keycloak_sub, auth_provider, last_identity_sync_at) FROM stdin;
1	admin@company.com	Admin User	1	admin		\N	2026-04-06 08:54:17.997509+00	91e0a27b-7d07-4dcb-b0bf-9bfcec0167cd	internal	\N
2	hr@company.com	HR Manager	1	hr		\N	2026-04-06 08:54:42.733671+00	f74294d7-388f-4bfc-9c8a-d96805bbd208	internal	\N
\.


--
-- Data for Name: frs_user_membership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_user_membership (pk_membership_id, fk_user_id, role, tenant_id, customer_id, site_id, unit_id, permissions) FROM stdin;
1	1	admin	1	1	1	\N	{users.read,users.manage,devices.read,devices.manage,attendance.read,attendance.manage,analytics.read,audit.read,facility.read,facility.manage,aiinsights.read}
3	1	admin	1	1	1	\N	{devices.read,devices.write,users.read,users.write,facility.manage,audit.read,reports.read,attendance.read,attendance.write,employees.read,employees.write}
4	2	hr	1	1	1	\N	{attendance.read,attendance.write,employees.read,employees.write,reports.read,facility.manage,users.write,devices.write}
2	2	hr	1	1	1	\N	{users.read,devices.read,attendance.read,attendance.manage,analytics.read,facility.read,aiinsights.read,users.write,users.manage,attendance.write,devices.write,analytics.write}
\.


--
-- Data for Name: frs_zone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_zone (pk_zone_id, fk_floor_id, zone_name, zone_type, created_at) FROM stdin;
\.


--
-- Data for Name: hr_department; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hr_department (pk_department_id, tenant_id, name, code, color) FROM stdin;
1	1	Engineering	MLENG	#3B82F6
2	1	AI/ML	MLAI	#06B6D4
3	1	HR	HR	#3B82F6
4	1	Sales	SAL	#3B82F6
\.


--
-- Data for Name: hr_employee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hr_employee (pk_employee_id, tenant_id, customer_id, site_id, unit_id, fk_department_id, fk_shift_id, employee_code, full_name, email, position_title, location_label, status, join_date, phone_number, created_at, face_enrolled) FROM stdin;
3	1	1	1	\N	3	2	MLI003	Yeshwanth	yeshwanth.23@gmail.com	HR Manager	\N	active	2026-04-07	\N	2026-04-07 08:15:33.096123+00	f
4	1	1	1	\N	4	9	MLI004	Anjali	anjali.24@gmail.com	Executive	\N	active	2026-04-07	\N	2026-04-07 08:22:49.608104+00	f
1	1	1	1	\N	2	1	ML001	vallabhaneni Karthik	karthikvallabhaneni3712@gmail.com	Data Scientist	\N	active	2026-04-07	\N	2026-04-07 06:03:16.378466+00	t
2	1	1	1	\N	2	1	MLI002	Sai Dinesh	dinesh.12@gmail.com	AI/ML Engineer	\N	active	2026-04-07	\N	2026-04-07 07:14:55.042997+00	t
\.


--
-- Data for Name: hr_leave_request; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hr_leave_request (pk_leave_id, tenant_id, fk_employee_id, leave_type, start_date, end_date, days, reason, status, approved_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: hr_shift; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hr_shift (pk_shift_id, tenant_id, name, shift_type, start_time, end_time, grace_period_minutes, is_flexible) FROM stdin;
1	1	General Shift	morning	10:00:00	19:30:00	10	f
2	1	Morning Shift	morning	06:00:00	03:00:00	10	t
9	1	Night Shift	night	11:00:00	06:00:00	10	f
\.


--
-- Data for Name: system_alert; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_alert (pk_alert_id, tenant_id, customer_id, site_id, unit_id, alert_type, severity, title, message, fk_employee_id, fk_device_id, is_read, created_at) FROM stdin;
\.


--
-- Name: attendance_events_pk_attendance_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_events_pk_attendance_event_id_seq', 1, false);


--
-- Name: attendance_record_pk_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_record_pk_attendance_id_seq', 108, true);


--
-- Name: audit_log_pk_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_pk_audit_id_seq', 147, true);


--
-- Name: facility_device_pk_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.facility_device_pk_device_id_seq', 2, true);


--
-- Name: frs_building_pk_building_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_building_pk_building_id_seq', 1, false);


--
-- Name: frs_camera_pk_camera_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_camera_pk_camera_id_seq', 1, false);


--
-- Name: frs_customer_pk_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_customer_pk_customer_id_seq', 1, false);


--
-- Name: frs_floor_pk_floor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_floor_pk_floor_id_seq', 1, false);


--
-- Name: frs_nug_box_pk_nug_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_nug_box_pk_nug_id_seq', 1, false);


--
-- Name: frs_site_pk_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_site_pk_site_id_seq', 1, false);


--
-- Name: frs_telemetry_history_pk_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_telemetry_history_pk_history_id_seq', 1, false);


--
-- Name: frs_tenant_pk_tenant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_tenant_pk_tenant_id_seq', 1, false);


--
-- Name: frs_unit_pk_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_unit_pk_unit_id_seq', 1, false);


--
-- Name: frs_user_membership_pk_membership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_user_membership_pk_membership_id_seq', 4, true);


--
-- Name: frs_user_pk_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_user_pk_user_id_seq', 2, true);


--
-- Name: frs_zone_pk_zone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_zone_pk_zone_id_seq', 1, false);


--
-- Name: hr_department_pk_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hr_department_pk_department_id_seq', 4, true);


--
-- Name: hr_employee_pk_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hr_employee_pk_employee_id_seq', 4, true);


--
-- Name: hr_leave_request_pk_leave_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hr_leave_request_pk_leave_id_seq', 1, false);


--
-- Name: hr_shift_pk_shift_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hr_shift_pk_shift_id_seq', 28, true);


--
-- Name: system_alert_pk_alert_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_alert_pk_alert_id_seq', 1, false);


--
-- Name: attendance_events attendance_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events
    ADD CONSTRAINT attendance_events_pkey PRIMARY KEY (pk_attendance_event_id);


--
-- Name: attendance_record attendance_record_emp_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_emp_date_key UNIQUE (fk_employee_id, attendance_date);


--
-- Name: attendance_record attendance_record_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_pkey PRIMARY KEY (pk_attendance_id);


--
-- Name: attendance_record attendance_record_tenant_id_fk_employee_id_attendance_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_tenant_id_fk_employee_id_attendance_date_key UNIQUE (tenant_id, fk_employee_id, attendance_date);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (pk_audit_id);


--
-- Name: auth_session_token auth_session_token_access_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_token
    ADD CONSTRAINT auth_session_token_access_token_key UNIQUE (access_token);


--
-- Name: auth_session_token auth_session_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_token
    ADD CONSTRAINT auth_session_token_pkey PRIMARY KEY (token_id);


--
-- Name: auth_session_token auth_session_token_refresh_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_token
    ADD CONSTRAINT auth_session_token_refresh_token_key UNIQUE (refresh_token);


--
-- Name: device_events device_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_pkey PRIMARY KEY (pk_event_id);


--
-- Name: devices devices_device_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_device_code_key UNIQUE (device_code);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (pk_device_id);


--
-- Name: employee_face_embeddings employee_face_embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_face_embeddings
    ADD CONSTRAINT employee_face_embeddings_pkey PRIMARY KEY (id);


--
-- Name: facility_device facility_device_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_pkey PRIMARY KEY (pk_device_id);


--
-- Name: facility_device facility_device_tenant_id_external_device_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_tenant_id_external_device_id_key UNIQUE (tenant_id, external_device_id);


--
-- Name: frs_building frs_building_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_building
    ADD CONSTRAINT frs_building_pkey PRIMARY KEY (pk_building_id);


--
-- Name: frs_camera frs_camera_cam_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_cam_id_key UNIQUE (cam_id);


--
-- Name: frs_camera frs_camera_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_pkey PRIMARY KEY (pk_camera_id);


--
-- Name: frs_customer frs_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer
    ADD CONSTRAINT frs_customer_pkey PRIMARY KEY (pk_customer_id);


--
-- Name: frs_customer_user_map frs_customer_user_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer_user_map
    ADD CONSTRAINT frs_customer_user_map_pkey PRIMARY KEY (fk_user_id, fk_customer_id);


--
-- Name: frs_floor frs_floor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_floor
    ADD CONSTRAINT frs_floor_pkey PRIMARY KEY (pk_floor_id);


--
-- Name: frs_nug_box frs_nug_box_device_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_device_code_key UNIQUE (device_code);


--
-- Name: frs_nug_box frs_nug_box_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_pkey PRIMARY KEY (pk_nug_id);


--
-- Name: frs_site frs_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_site
    ADD CONSTRAINT frs_site_pkey PRIMARY KEY (pk_site_id);


--
-- Name: frs_telemetry_history frs_telemetry_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_telemetry_history
    ADD CONSTRAINT frs_telemetry_history_pkey PRIMARY KEY (pk_history_id);


--
-- Name: frs_tenant frs_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant
    ADD CONSTRAINT frs_tenant_pkey PRIMARY KEY (pk_tenant_id);


--
-- Name: frs_tenant_user_map frs_tenant_user_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant_user_map
    ADD CONSTRAINT frs_tenant_user_map_pkey PRIMARY KEY (fk_user_id, fk_tenant_id);


--
-- Name: frs_unit frs_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_unit
    ADD CONSTRAINT frs_unit_pkey PRIMARY KEY (pk_unit_id);


--
-- Name: frs_user frs_user_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user
    ADD CONSTRAINT frs_user_email_key UNIQUE (email);


--
-- Name: frs_user frs_user_keycloak_sub_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user
    ADD CONSTRAINT frs_user_keycloak_sub_key UNIQUE (keycloak_sub);


--
-- Name: frs_user_membership frs_user_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_pkey PRIMARY KEY (pk_membership_id);


--
-- Name: frs_user frs_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user
    ADD CONSTRAINT frs_user_pkey PRIMARY KEY (pk_user_id);


--
-- Name: frs_zone frs_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_zone
    ADD CONSTRAINT frs_zone_pkey PRIMARY KEY (pk_zone_id);


--
-- Name: hr_department hr_department_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_department
    ADD CONSTRAINT hr_department_pkey PRIMARY KEY (pk_department_id);


--
-- Name: hr_department hr_department_tenant_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_department
    ADD CONSTRAINT hr_department_tenant_id_code_key UNIQUE (tenant_id, code);


--
-- Name: hr_employee hr_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_pkey PRIMARY KEY (pk_employee_id);


--
-- Name: hr_employee hr_employee_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: hr_employee hr_employee_tenant_id_employee_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_tenant_id_employee_code_key UNIQUE (tenant_id, employee_code);


--
-- Name: hr_leave_request hr_leave_request_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request
    ADD CONSTRAINT hr_leave_request_pkey PRIMARY KEY (pk_leave_id);


--
-- Name: hr_shift hr_shift_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_shift
    ADD CONSTRAINT hr_shift_pkey PRIMARY KEY (pk_shift_id);


--
-- Name: system_alert system_alert_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_pkey PRIMARY KEY (pk_alert_id);


--
-- Name: idx_alert_scope_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_scope_created ON public.system_alert USING btree (tenant_id, site_id, created_at DESC);


--
-- Name: idx_attendance_employee_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_employee_date ON public.attendance_record USING btree (fk_employee_id, attendance_date DESC);


--
-- Name: idx_attendance_scope_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_scope_date ON public.attendance_record USING btree (tenant_id, site_id, attendance_date DESC);


--
-- Name: idx_audit_scope_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_scope_created ON public.audit_log USING btree (tenant_id, created_at DESC);


--
-- Name: idx_auth_session_token_access; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_session_token_access ON public.auth_session_token USING btree (access_token);


--
-- Name: idx_auth_session_token_refresh; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_session_token_refresh ON public.auth_session_token USING btree (refresh_token);


--
-- Name: idx_device_events_device_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_events_device_time ON public.device_events USING btree (fk_device_id, occurred_at DESC);


--
-- Name: idx_device_events_type_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_events_type_time ON public.device_events USING btree (event_type, occurred_at DESC);


--
-- Name: idx_device_events_unprocessed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_events_unprocessed ON public.device_events USING btree (processing_status);


--
-- Name: idx_device_scope_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_scope_status ON public.facility_device USING btree (tenant_id, site_id, status);


--
-- Name: idx_devices_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_code ON public.devices USING btree (device_code);


--
-- Name: idx_devices_heartbeat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_heartbeat ON public.devices USING btree (last_heartbeat_at);


--
-- Name: idx_devices_site; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_site ON public.devices USING btree (fk_site_id);


--
-- Name: idx_devices_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_status ON public.devices USING btree (status);


--
-- Name: idx_employee_face_hnsw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_face_hnsw ON public.employee_face_embeddings USING hnsw (embedding public.vector_cosine_ops) WITH (m='16', ef_construction='64');


--
-- Name: idx_employee_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_scope ON public.hr_employee USING btree (tenant_id, customer_id, site_id, unit_id);


--
-- Name: idx_frs_building_site; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_building_site ON public.frs_building USING btree (fk_site_id);


--
-- Name: idx_frs_camera_cam_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_camera_cam_id ON public.frs_camera USING btree (cam_id);


--
-- Name: idx_frs_camera_nug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_camera_nug ON public.frs_camera USING btree (fk_nug_id);


--
-- Name: idx_frs_floor_building; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_floor_building ON public.frs_floor USING btree (fk_building_id);


--
-- Name: idx_frs_nug_device_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_nug_device_code ON public.frs_nug_box USING btree (device_code);


--
-- Name: idx_frs_nug_site; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_nug_site ON public.frs_nug_box USING btree (fk_site_id);


--
-- Name: idx_frs_nug_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_nug_status ON public.frs_nug_box USING btree (status);


--
-- Name: idx_frs_user_keycloak_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_user_keycloak_sub ON public.frs_user USING btree (keycloak_sub);


--
-- Name: idx_frs_zone_floor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_zone_floor ON public.frs_zone USING btree (fk_floor_id);


--
-- Name: idx_membership_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_membership_scope ON public.frs_user_membership USING btree (tenant_id, customer_id, site_id, unit_id);


--
-- Name: idx_membership_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_membership_user ON public.frs_user_membership USING btree (fk_user_id);


--
-- Name: idx_shift_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shift_tenant ON public.hr_shift USING btree (tenant_id);


--
-- Name: idx_telemetry_nug_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_telemetry_nug_time ON public.frs_telemetry_history USING btree (fk_nug_id, "timestamp" DESC);


--
-- Name: uq_membership_user_scope_role; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_membership_user_scope_role ON public.frs_user_membership USING btree (fk_user_id, role, tenant_id, customer_id, site_id, unit_id);


--
-- Name: employee_face_embeddings trg_sync_face_enrolled; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_face_enrolled AFTER INSERT OR DELETE ON public.employee_face_embeddings FOR EACH ROW EXECUTE FUNCTION public.sync_face_enrolled();


--
-- Name: devices update_devices_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_devices_updated_at BEFORE UPDATE ON public.devices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: attendance_events attendance_events_fk_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events
    ADD CONSTRAINT attendance_events_fk_employee_id_fkey FOREIGN KEY (fk_employee_id) REFERENCES public.hr_employee(pk_employee_id);


--
-- Name: attendance_events attendance_events_fk_original_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events
    ADD CONSTRAINT attendance_events_fk_original_event_id_fkey FOREIGN KEY (fk_original_event_id) REFERENCES public.device_events(pk_event_id);


--
-- Name: attendance_events attendance_events_fk_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events
    ADD CONSTRAINT attendance_events_fk_shift_id_fkey FOREIGN KEY (fk_shift_id) REFERENCES public.hr_shift(pk_shift_id);


--
-- Name: attendance_record attendance_record_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: attendance_record attendance_record_fk_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_fk_employee_id_fkey FOREIGN KEY (fk_employee_id) REFERENCES public.hr_employee(pk_employee_id);


--
-- Name: attendance_record attendance_record_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: attendance_record attendance_record_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: attendance_record attendance_record_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: audit_log audit_log_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: audit_log audit_log_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: audit_log audit_log_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: audit_log audit_log_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: auth_session_token auth_session_token_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_token
    ADD CONSTRAINT auth_session_token_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: employee_face_embeddings employee_face_embeddings_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_face_embeddings
    ADD CONSTRAINT employee_face_embeddings_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.hr_employee(pk_employee_id) ON DELETE CASCADE;


--
-- Name: employee_face_embeddings employee_face_embeddings_enrolled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_face_embeddings
    ADD CONSTRAINT employee_face_embeddings_enrolled_by_fkey FOREIGN KEY (enrolled_by) REFERENCES public.frs_user(pk_user_id);


--
-- Name: facility_device facility_device_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: facility_device facility_device_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: facility_device facility_device_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: facility_device facility_device_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: frs_camera frs_camera_fk_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_fk_floor_id_fkey FOREIGN KEY (fk_floor_id) REFERENCES public.frs_floor(pk_floor_id) ON DELETE SET NULL;


--
-- Name: frs_camera frs_camera_fk_nug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_fk_nug_id_fkey FOREIGN KEY (fk_nug_id) REFERENCES public.frs_nug_box(pk_nug_id) ON DELETE SET NULL;


--
-- Name: frs_camera frs_camera_fk_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_fk_zone_id_fkey FOREIGN KEY (fk_zone_id) REFERENCES public.frs_zone(pk_zone_id) ON DELETE SET NULL;


--
-- Name: frs_customer frs_customer_fk_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer
    ADD CONSTRAINT frs_customer_fk_tenant_id_fkey FOREIGN KEY (fk_tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: frs_customer_user_map frs_customer_user_map_fk_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer_user_map
    ADD CONSTRAINT frs_customer_user_map_fk_customer_id_fkey FOREIGN KEY (fk_customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: frs_customer_user_map frs_customer_user_map_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer_user_map
    ADD CONSTRAINT frs_customer_user_map_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: frs_floor frs_floor_fk_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_floor
    ADD CONSTRAINT frs_floor_fk_building_id_fkey FOREIGN KEY (fk_building_id) REFERENCES public.frs_building(pk_building_id) ON DELETE CASCADE;


--
-- Name: frs_nug_box frs_nug_box_fk_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_fk_building_id_fkey FOREIGN KEY (fk_building_id) REFERENCES public.frs_building(pk_building_id) ON DELETE SET NULL;


--
-- Name: frs_nug_box frs_nug_box_fk_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_fk_floor_id_fkey FOREIGN KEY (fk_floor_id) REFERENCES public.frs_floor(pk_floor_id) ON DELETE SET NULL;


--
-- Name: frs_nug_box frs_nug_box_fk_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_fk_zone_id_fkey FOREIGN KEY (fk_zone_id) REFERENCES public.frs_zone(pk_zone_id) ON DELETE SET NULL;


--
-- Name: frs_site frs_site_fk_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_site
    ADD CONSTRAINT frs_site_fk_customer_id_fkey FOREIGN KEY (fk_customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: frs_telemetry_history frs_telemetry_history_fk_nug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_telemetry_history
    ADD CONSTRAINT frs_telemetry_history_fk_nug_id_fkey FOREIGN KEY (fk_nug_id) REFERENCES public.frs_nug_box(pk_nug_id) ON DELETE CASCADE;


--
-- Name: frs_tenant_user_map frs_tenant_user_map_fk_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant_user_map
    ADD CONSTRAINT frs_tenant_user_map_fk_tenant_id_fkey FOREIGN KEY (fk_tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: frs_tenant_user_map frs_tenant_user_map_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant_user_map
    ADD CONSTRAINT frs_tenant_user_map_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: frs_unit frs_unit_fk_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_unit
    ADD CONSTRAINT frs_unit_fk_site_id_fkey FOREIGN KEY (fk_site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: frs_user_membership frs_user_membership_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: frs_user_membership frs_user_membership_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: frs_user_membership frs_user_membership_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: frs_user_membership frs_user_membership_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: frs_user_membership frs_user_membership_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: frs_zone frs_zone_fk_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_zone
    ADD CONSTRAINT frs_zone_fk_floor_id_fkey FOREIGN KEY (fk_floor_id) REFERENCES public.frs_floor(pk_floor_id) ON DELETE CASCADE;


--
-- Name: hr_department hr_department_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_department
    ADD CONSTRAINT hr_department_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: hr_employee hr_employee_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: hr_employee hr_employee_fk_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_fk_department_id_fkey FOREIGN KEY (fk_department_id) REFERENCES public.hr_department(pk_department_id);


--
-- Name: hr_employee hr_employee_fk_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_fk_shift_id_fkey FOREIGN KEY (fk_shift_id) REFERENCES public.hr_shift(pk_shift_id);


--
-- Name: hr_employee hr_employee_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: hr_employee hr_employee_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: hr_employee hr_employee_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: hr_leave_request hr_leave_request_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request
    ADD CONSTRAINT hr_leave_request_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.frs_user(pk_user_id);


--
-- Name: hr_leave_request hr_leave_request_fk_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request
    ADD CONSTRAINT hr_leave_request_fk_employee_id_fkey FOREIGN KEY (fk_employee_id) REFERENCES public.hr_employee(pk_employee_id);


--
-- Name: hr_leave_request hr_leave_request_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request
    ADD CONSTRAINT hr_leave_request_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: hr_shift hr_shift_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_shift
    ADD CONSTRAINT hr_shift_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: system_alert system_alert_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: system_alert system_alert_fk_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_fk_device_id_fkey FOREIGN KEY (fk_device_id) REFERENCES public.facility_device(pk_device_id);


--
-- Name: system_alert system_alert_fk_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_fk_employee_id_fkey FOREIGN KEY (fk_employee_id) REFERENCES public.hr_employee(pk_employee_id);


--
-- Name: system_alert system_alert_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: system_alert system_alert_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: system_alert system_alert_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- PostgreSQL database dump complete
--

