--
-- PostgreSQL database dump
--

\restrict TUrSJ1qZ5HHC7DTGVQXrLQlglIx1jwvNiH5oJXOabSnGt7ysrxIjLufCwSEtxDo

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64)
);


--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


--
-- Name: client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


--
-- Name: client_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session (
    id character varying(36) NOT NULL,
    client_id character varying(36),
    redirect_uri character varying(255),
    state character varying(255),
    "timestamp" integer,
    session_id character varying(36),
    auth_method character varying(255),
    realm_id character varying(255),
    auth_user_id character varying(36),
    current_action character varying(36)
);


--
-- Name: client_session_auth_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session_auth_status (
    authenticator character varying(36) NOT NULL,
    status integer,
    client_session character varying(36) NOT NULL
);


--
-- Name: client_session_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session_note (
    name character varying(255) NOT NULL,
    value character varying(255),
    client_session character varying(36) NOT NULL
);


--
-- Name: client_session_prot_mapper; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session_prot_mapper (
    protocol_mapper_id character varying(36) NOT NULL,
    client_session character varying(36) NOT NULL
);


--
-- Name: client_session_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session_role (
    role_id character varying(255) NOT NULL,
    client_session character varying(36) NOT NULL
);


--
-- Name: client_user_session_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_user_session_note (
    name character varying(255) NOT NULL,
    value character varying(2048),
    client_session character varying(36) NOT NULL
);


--
-- Name: component; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


--
-- Name: component_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


--
-- Name: credential; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255),
    details_json_long_value text
);


--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024),
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL
);


--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36)
);


--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL
);


--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL
);


--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: realm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


--
-- Name: user_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_session (
    id character varying(36) NOT NULL,
    auth_method character varying(255),
    ip_address character varying(255),
    last_session_refresh integer,
    login_username character varying(255),
    realm_id character varying(255),
    remember_me boolean DEFAULT false NOT NULL,
    started integer,
    user_id character varying(255),
    user_session_state integer,
    broker_session_id character varying(255),
    broker_user_id character varying(255)
);


--
-- Name: user_session_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_session_note (
    user_session character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(2048)
);


--
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
8e91a706-8fff-4e05-8a48-a3bc52bed1fd	\N	auth-cookie	64915411-5e90-4f94-9757-8cf984b78491	c2867d2a-3a58-4b2b-8b65-9200b8ebe6bf	2	10	f	\N	\N
691383d0-3ff1-460b-8f9a-2aa85312f0e7	\N	auth-spnego	64915411-5e90-4f94-9757-8cf984b78491	c2867d2a-3a58-4b2b-8b65-9200b8ebe6bf	3	20	f	\N	\N
349a9ac1-2564-45b7-8d2c-a19a3f0fe2da	\N	identity-provider-redirector	64915411-5e90-4f94-9757-8cf984b78491	c2867d2a-3a58-4b2b-8b65-9200b8ebe6bf	2	25	f	\N	\N
df776919-b6ae-4c30-af57-a1cddb00e3db	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	c2867d2a-3a58-4b2b-8b65-9200b8ebe6bf	2	30	t	179cc8cf-c49c-4589-8032-1cb1a79fe1f5	\N
67f2c0f5-75a9-484a-8967-b0be298d272e	\N	auth-username-password-form	64915411-5e90-4f94-9757-8cf984b78491	179cc8cf-c49c-4589-8032-1cb1a79fe1f5	0	10	f	\N	\N
81eeca23-85cf-4a79-9e0f-479797c475f5	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	179cc8cf-c49c-4589-8032-1cb1a79fe1f5	1	20	t	062fb7c2-ba08-4282-9695-252b6c6b7ba9	\N
c7d5b74c-adbc-47df-8b34-c92844b8be47	\N	conditional-user-configured	64915411-5e90-4f94-9757-8cf984b78491	062fb7c2-ba08-4282-9695-252b6c6b7ba9	0	10	f	\N	\N
254014c5-f369-4657-925f-464b8db80c73	\N	auth-otp-form	64915411-5e90-4f94-9757-8cf984b78491	062fb7c2-ba08-4282-9695-252b6c6b7ba9	0	20	f	\N	\N
0eb1a78b-362c-4ee2-b3e9-4a69c6f66b9e	\N	direct-grant-validate-username	64915411-5e90-4f94-9757-8cf984b78491	30625a34-a12b-4114-a677-2020a5f36323	0	10	f	\N	\N
2b7f8868-d13a-4821-8b1a-4659601ec139	\N	direct-grant-validate-password	64915411-5e90-4f94-9757-8cf984b78491	30625a34-a12b-4114-a677-2020a5f36323	0	20	f	\N	\N
70dfa2b2-0531-4415-968b-2ef70fd67881	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	30625a34-a12b-4114-a677-2020a5f36323	1	30	t	3086c4c3-4336-4348-8b76-85ca50f1b131	\N
7b20e383-b970-46d7-84e0-79252519dd7a	\N	conditional-user-configured	64915411-5e90-4f94-9757-8cf984b78491	3086c4c3-4336-4348-8b76-85ca50f1b131	0	10	f	\N	\N
755dd6bb-c83f-4f98-9034-4b403e5559eb	\N	direct-grant-validate-otp	64915411-5e90-4f94-9757-8cf984b78491	3086c4c3-4336-4348-8b76-85ca50f1b131	0	20	f	\N	\N
6dae1bde-f393-4ea4-88f1-00d1f0bc9452	\N	registration-page-form	64915411-5e90-4f94-9757-8cf984b78491	b4e9c621-5666-4986-bcc3-2e6d3e11371a	0	10	t	633fde36-c35e-4a8c-8611-659f472311b0	\N
de4b2bfe-9984-4fb4-b0de-8cabbeda3c47	\N	registration-user-creation	64915411-5e90-4f94-9757-8cf984b78491	633fde36-c35e-4a8c-8611-659f472311b0	0	20	f	\N	\N
b32dd1cf-309e-4052-a669-1e09137bd9a6	\N	registration-password-action	64915411-5e90-4f94-9757-8cf984b78491	633fde36-c35e-4a8c-8611-659f472311b0	0	50	f	\N	\N
da1c712d-2ef6-4732-b6ee-f60432c54aaf	\N	registration-recaptcha-action	64915411-5e90-4f94-9757-8cf984b78491	633fde36-c35e-4a8c-8611-659f472311b0	3	60	f	\N	\N
54ba6a18-dd34-438f-99ab-ae480b03619d	\N	registration-terms-and-conditions	64915411-5e90-4f94-9757-8cf984b78491	633fde36-c35e-4a8c-8611-659f472311b0	3	70	f	\N	\N
47bb88be-2beb-4182-b953-367e32b2d747	\N	reset-credentials-choose-user	64915411-5e90-4f94-9757-8cf984b78491	3ada9946-6171-42fe-8608-2950a5abd71d	0	10	f	\N	\N
86fe40bd-2b05-46e0-9e8b-9aa77bd9c869	\N	reset-credential-email	64915411-5e90-4f94-9757-8cf984b78491	3ada9946-6171-42fe-8608-2950a5abd71d	0	20	f	\N	\N
6f5a819f-5a4c-4ea9-80ad-08d41cc4bce9	\N	reset-password	64915411-5e90-4f94-9757-8cf984b78491	3ada9946-6171-42fe-8608-2950a5abd71d	0	30	f	\N	\N
0251839d-b626-4bbe-9336-877c57056ac6	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	3ada9946-6171-42fe-8608-2950a5abd71d	1	40	t	5e383819-65dd-4ca2-a898-890ca1d98051	\N
54220250-b7bb-47e4-97bb-7dd116855405	\N	conditional-user-configured	64915411-5e90-4f94-9757-8cf984b78491	5e383819-65dd-4ca2-a898-890ca1d98051	0	10	f	\N	\N
f31b11d4-ee7a-4b1a-92d3-8f9130bed9c2	\N	reset-otp	64915411-5e90-4f94-9757-8cf984b78491	5e383819-65dd-4ca2-a898-890ca1d98051	0	20	f	\N	\N
2731503f-77ea-441e-a370-dd4c25168abc	\N	client-secret	64915411-5e90-4f94-9757-8cf984b78491	773b5b67-7ac7-459a-843c-fd6b6185090b	2	10	f	\N	\N
83aaf726-a350-4b67-8217-fe8a9dc9404a	\N	client-jwt	64915411-5e90-4f94-9757-8cf984b78491	773b5b67-7ac7-459a-843c-fd6b6185090b	2	20	f	\N	\N
2994c5fd-7d40-4c42-a03a-5657bfe62086	\N	client-secret-jwt	64915411-5e90-4f94-9757-8cf984b78491	773b5b67-7ac7-459a-843c-fd6b6185090b	2	30	f	\N	\N
fa8cd0be-b835-4d4f-a94a-ebe849e6bf2a	\N	client-x509	64915411-5e90-4f94-9757-8cf984b78491	773b5b67-7ac7-459a-843c-fd6b6185090b	2	40	f	\N	\N
736e1369-18fc-4d14-8300-41b15a9ebfd6	\N	idp-review-profile	64915411-5e90-4f94-9757-8cf984b78491	88351c9e-f7f7-4bee-beaf-be9160830dde	0	10	f	\N	ead4ba4e-b42f-4de0-a23f-4cb0b4e7d214
1d0b7c85-3410-42ed-9e07-a745b5f0d589	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	88351c9e-f7f7-4bee-beaf-be9160830dde	0	20	t	8735ed8c-4f0d-4cfc-b64e-a0536de60199	\N
bf4d9eff-8369-4d71-ad25-1a785d4fe879	\N	idp-create-user-if-unique	64915411-5e90-4f94-9757-8cf984b78491	8735ed8c-4f0d-4cfc-b64e-a0536de60199	2	10	f	\N	e9176ca7-cd3b-4a71-b6f9-e6cd5655d61f
e5fd80bc-1fe8-4418-a4df-2b48e53d2e17	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	8735ed8c-4f0d-4cfc-b64e-a0536de60199	2	20	t	8a2d8fee-5a21-40f4-979b-7aea8a8cf4d5	\N
73eb4551-a2b3-4e18-a5c1-33ae91ef3246	\N	idp-confirm-link	64915411-5e90-4f94-9757-8cf984b78491	8a2d8fee-5a21-40f4-979b-7aea8a8cf4d5	0	10	f	\N	\N
cea788a8-b39b-40da-a053-949d28c9e324	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	8a2d8fee-5a21-40f4-979b-7aea8a8cf4d5	0	20	t	36272fa3-a110-44fb-b17a-964a7bec362c	\N
75952e3f-9ec1-4a65-8910-6c3b6a309d56	\N	idp-email-verification	64915411-5e90-4f94-9757-8cf984b78491	36272fa3-a110-44fb-b17a-964a7bec362c	2	10	f	\N	\N
84492806-b265-4bb9-942f-4cf9a803b822	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	36272fa3-a110-44fb-b17a-964a7bec362c	2	20	t	5c15cca7-e8b1-438f-bf9f-b3ae9af41c35	\N
f29d1266-2128-47b2-a929-952ce77e25a6	\N	idp-username-password-form	64915411-5e90-4f94-9757-8cf984b78491	5c15cca7-e8b1-438f-bf9f-b3ae9af41c35	0	10	f	\N	\N
cdb62a9b-dea7-4e17-96db-69796a2ceb44	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	5c15cca7-e8b1-438f-bf9f-b3ae9af41c35	1	20	t	e9fe4b72-8850-4dec-9731-bcf10c71d12f	\N
1724be75-7dd0-4436-8d77-bd4cf39d8804	\N	conditional-user-configured	64915411-5e90-4f94-9757-8cf984b78491	e9fe4b72-8850-4dec-9731-bcf10c71d12f	0	10	f	\N	\N
c6f34a89-9b62-43e3-994c-6b3c8be9d882	\N	auth-otp-form	64915411-5e90-4f94-9757-8cf984b78491	e9fe4b72-8850-4dec-9731-bcf10c71d12f	0	20	f	\N	\N
26af178c-8dbe-499c-9087-0b52644b8f37	\N	http-basic-authenticator	64915411-5e90-4f94-9757-8cf984b78491	0d35a2f1-a545-4c6b-9b5a-cb87c8dcb4de	0	10	f	\N	\N
51e46621-d6c5-4b22-b5db-7233f7bb4c02	\N	docker-http-basic-authenticator	64915411-5e90-4f94-9757-8cf984b78491	e7d69ef2-f44d-4f7a-b105-77461191ef0a	0	10	f	\N	\N
9e07a5a5-59cf-45fd-852a-68b2aee311dd	\N	auth-cookie	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	975699e5-159f-45f2-aed5-b3f9db69d3f1	2	10	f	\N	\N
0971996a-b153-415a-91ba-fdecbf92b1b8	\N	auth-spnego	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	975699e5-159f-45f2-aed5-b3f9db69d3f1	3	20	f	\N	\N
450528ef-d1f8-48f2-b6cb-3c2a51186624	\N	identity-provider-redirector	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	975699e5-159f-45f2-aed5-b3f9db69d3f1	2	25	f	\N	\N
f35fbf78-b491-4599-b90b-45d58143c01a	\N	\N	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	975699e5-159f-45f2-aed5-b3f9db69d3f1	2	30	t	efb856ec-32e1-4378-a13c-b09b6568ce41	\N
a98ae6b3-2ca6-42d6-a106-9b2eea6ec504	\N	auth-username-password-form	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	efb856ec-32e1-4378-a13c-b09b6568ce41	0	10	f	\N	\N
42913567-ce99-4172-9734-ee93d2fc32ff	\N	\N	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	efb856ec-32e1-4378-a13c-b09b6568ce41	1	20	t	2426dce6-0217-4612-9027-660b30958798	\N
779d09e0-ded3-4bba-a6f1-6c4fcc4818c5	\N	conditional-user-configured	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	2426dce6-0217-4612-9027-660b30958798	0	10	f	\N	\N
03a502c5-1b49-4b6b-9a16-6966c711e56a	\N	auth-otp-form	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	2426dce6-0217-4612-9027-660b30958798	0	20	f	\N	\N
fcf91074-f458-4933-8e1b-dcce3885d7cf	\N	direct-grant-validate-username	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	278cd772-8dbc-40a7-9a2e-9b574bc3b18b	0	10	f	\N	\N
6b8e9c31-c2cd-46ce-a84c-9f5ec40dabe4	\N	direct-grant-validate-password	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	278cd772-8dbc-40a7-9a2e-9b574bc3b18b	0	20	f	\N	\N
5be20361-9f36-47c2-95b4-fad362504977	\N	\N	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	278cd772-8dbc-40a7-9a2e-9b574bc3b18b	1	30	t	6863d827-0f7c-4d77-a4d6-3380edb5d2db	\N
45a0a92b-f9dc-4c75-85fb-9a786282cacd	\N	conditional-user-configured	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6863d827-0f7c-4d77-a4d6-3380edb5d2db	0	10	f	\N	\N
0fce9ff3-aa95-493d-be0a-586a5fce25f8	\N	direct-grant-validate-otp	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6863d827-0f7c-4d77-a4d6-3380edb5d2db	0	20	f	\N	\N
c3f72a04-b8be-478c-bf7b-f5fdcad4c7c0	\N	registration-page-form	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f1450d8a-6aff-4e40-b8fb-5fb0c39d37ec	0	10	t	2ea145da-993a-44b1-9ffc-86fef18eb77d	\N
7e859522-7fc0-46e0-8a61-e42dc099c799	\N	registration-user-creation	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	2ea145da-993a-44b1-9ffc-86fef18eb77d	0	20	f	\N	\N
0de05b75-f1df-4fd0-8a33-fbcaeafe7470	\N	registration-password-action	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	2ea145da-993a-44b1-9ffc-86fef18eb77d	0	50	f	\N	\N
565e37b1-67bd-4fcd-9b39-cd2be7527e49	\N	registration-recaptcha-action	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	2ea145da-993a-44b1-9ffc-86fef18eb77d	3	60	f	\N	\N
a88c13d5-3a86-4b8c-a5c8-8b6c29596912	\N	registration-terms-and-conditions	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	2ea145da-993a-44b1-9ffc-86fef18eb77d	3	70	f	\N	\N
8e65a29c-e9fb-4ef9-9461-531747070902	\N	reset-credentials-choose-user	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	95523d95-55ba-484d-8548-eb0f7c7b0f65	0	10	f	\N	\N
463810a5-e640-4b40-be15-da05003ed931	\N	reset-credential-email	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	95523d95-55ba-484d-8548-eb0f7c7b0f65	0	20	f	\N	\N
d36390d3-7ad4-4e6d-a2ff-b5eb67d8c0ac	\N	reset-password	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	95523d95-55ba-484d-8548-eb0f7c7b0f65	0	30	f	\N	\N
4343bbaf-12c1-46e5-ac40-2f862f99e5a6	\N	\N	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	95523d95-55ba-484d-8548-eb0f7c7b0f65	1	40	t	739858df-f30a-41f5-90f7-22796b330565	\N
c88a2950-3ffc-4afa-82ed-e6fc5d0042ff	\N	conditional-user-configured	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	739858df-f30a-41f5-90f7-22796b330565	0	10	f	\N	\N
1496ea4a-ef2d-42f0-8782-d8fbc535ed7e	\N	reset-otp	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	739858df-f30a-41f5-90f7-22796b330565	0	20	f	\N	\N
8fbc1fb7-8f90-4a3c-a310-e186939dd57c	\N	client-secret	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	39e38511-b2de-4f79-8eeb-1a16dfcfb8c4	2	10	f	\N	\N
557c6ca6-fc0d-4137-b04c-0aeece7a6af7	\N	client-jwt	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	39e38511-b2de-4f79-8eeb-1a16dfcfb8c4	2	20	f	\N	\N
a85cc191-b4b2-48a0-8b45-e7969c86eab8	\N	client-secret-jwt	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	39e38511-b2de-4f79-8eeb-1a16dfcfb8c4	2	30	f	\N	\N
e14972a7-5037-496d-b5ca-a2547b6927a2	\N	client-x509	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	39e38511-b2de-4f79-8eeb-1a16dfcfb8c4	2	40	f	\N	\N
1bac7057-28fe-45d0-8f65-71e71d876752	\N	idp-review-profile	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	d32aedd8-c838-4fe2-94b9-e6755da08287	0	10	f	\N	e5d621bc-5e84-4578-afde-d955191f2d94
e2be7d4e-618f-41ad-815c-60f6ea7a5893	\N	\N	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	d32aedd8-c838-4fe2-94b9-e6755da08287	0	20	t	26531e0a-7ea6-4961-825d-c56e2427c5db	\N
946afe3d-28c6-43b2-a143-43da6d0a2239	\N	idp-create-user-if-unique	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	26531e0a-7ea6-4961-825d-c56e2427c5db	2	10	f	\N	af3d3883-5765-49b8-8942-c3db3c2bb7f2
bf931fc3-3c38-4aac-9e2c-3f30a3e85514	\N	\N	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	26531e0a-7ea6-4961-825d-c56e2427c5db	2	20	t	e85c7e4a-442b-4906-acca-1a57c3bbf7a3	\N
11ac8fa4-96eb-4023-9025-6d104bfda894	\N	idp-confirm-link	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	e85c7e4a-442b-4906-acca-1a57c3bbf7a3	0	10	f	\N	\N
4f5b9788-6de0-44ae-8241-ccc36a352e0a	\N	\N	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	e85c7e4a-442b-4906-acca-1a57c3bbf7a3	0	20	t	57164663-ad23-4e49-99c3-2e5f677cf6d2	\N
18980cda-751b-4471-b3ac-cd9ec60a1981	\N	idp-email-verification	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	57164663-ad23-4e49-99c3-2e5f677cf6d2	2	10	f	\N	\N
af2004bb-e750-48ec-a41a-8bb2967fd987	\N	\N	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	57164663-ad23-4e49-99c3-2e5f677cf6d2	2	20	t	f5266dcb-9bbb-4bd5-aa80-9d72cb9e5b37	\N
42d1db52-d009-46df-a204-5c48900a0ee2	\N	idp-username-password-form	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f5266dcb-9bbb-4bd5-aa80-9d72cb9e5b37	0	10	f	\N	\N
b17896a4-a0dd-4f40-9a49-78e662461478	\N	\N	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f5266dcb-9bbb-4bd5-aa80-9d72cb9e5b37	1	20	t	009b357c-e34d-4609-a71f-3db7d0b57615	\N
938dbdba-e55d-4b94-ac30-affd91f84635	\N	conditional-user-configured	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	009b357c-e34d-4609-a71f-3db7d0b57615	0	10	f	\N	\N
03fe87a6-cf13-4fa6-97fc-ddc8d03cc5ef	\N	auth-otp-form	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	009b357c-e34d-4609-a71f-3db7d0b57615	0	20	f	\N	\N
8854112a-0a3b-4392-892e-f7250df413f6	\N	http-basic-authenticator	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	e8d16719-7c80-4052-9d48-708c4beb2374	0	10	f	\N	\N
e3bba987-00be-44b7-8ec0-de76f73ebf3b	\N	docker-http-basic-authenticator	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	574aaaf7-b80d-457f-b68a-ee04fc12ba34	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
c2867d2a-3a58-4b2b-8b65-9200b8ebe6bf	browser	browser based authentication	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	t	t
179cc8cf-c49c-4589-8032-1cb1a79fe1f5	forms	Username, password, otp and other auth forms.	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	f	t
062fb7c2-ba08-4282-9695-252b6c6b7ba9	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	f	t
30625a34-a12b-4114-a677-2020a5f36323	direct grant	OpenID Connect Resource Owner Grant	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	t	t
3086c4c3-4336-4348-8b76-85ca50f1b131	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	f	t
b4e9c621-5666-4986-bcc3-2e6d3e11371a	registration	registration flow	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	t	t
633fde36-c35e-4a8c-8611-659f472311b0	registration form	registration form	64915411-5e90-4f94-9757-8cf984b78491	form-flow	f	t
3ada9946-6171-42fe-8608-2950a5abd71d	reset credentials	Reset credentials for a user if they forgot their password or something	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	t	t
5e383819-65dd-4ca2-a898-890ca1d98051	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	f	t
773b5b67-7ac7-459a-843c-fd6b6185090b	clients	Base authentication for clients	64915411-5e90-4f94-9757-8cf984b78491	client-flow	t	t
88351c9e-f7f7-4bee-beaf-be9160830dde	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	t	t
8735ed8c-4f0d-4cfc-b64e-a0536de60199	User creation or linking	Flow for the existing/non-existing user alternatives	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	f	t
8a2d8fee-5a21-40f4-979b-7aea8a8cf4d5	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	f	t
36272fa3-a110-44fb-b17a-964a7bec362c	Account verification options	Method with which to verity the existing account	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	f	t
5c15cca7-e8b1-438f-bf9f-b3ae9af41c35	Verify Existing Account by Re-authentication	Reauthentication of existing account	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	f	t
e9fe4b72-8850-4dec-9731-bcf10c71d12f	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	f	t
0d35a2f1-a545-4c6b-9b5a-cb87c8dcb4de	saml ecp	SAML ECP Profile Authentication Flow	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	t	t
e7d69ef2-f44d-4f7a-b105-77461191ef0a	docker auth	Used by Docker clients to authenticate against the IDP	64915411-5e90-4f94-9757-8cf984b78491	basic-flow	t	t
975699e5-159f-45f2-aed5-b3f9db69d3f1	browser	browser based authentication	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	t	t
efb856ec-32e1-4378-a13c-b09b6568ce41	forms	Username, password, otp and other auth forms.	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	f	t
2426dce6-0217-4612-9027-660b30958798	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	f	t
278cd772-8dbc-40a7-9a2e-9b574bc3b18b	direct grant	OpenID Connect Resource Owner Grant	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	t	t
6863d827-0f7c-4d77-a4d6-3380edb5d2db	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	f	t
f1450d8a-6aff-4e40-b8fb-5fb0c39d37ec	registration	registration flow	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	t	t
2ea145da-993a-44b1-9ffc-86fef18eb77d	registration form	registration form	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	form-flow	f	t
95523d95-55ba-484d-8548-eb0f7c7b0f65	reset credentials	Reset credentials for a user if they forgot their password or something	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	t	t
739858df-f30a-41f5-90f7-22796b330565	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	f	t
39e38511-b2de-4f79-8eeb-1a16dfcfb8c4	clients	Base authentication for clients	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	client-flow	t	t
d32aedd8-c838-4fe2-94b9-e6755da08287	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	t	t
26531e0a-7ea6-4961-825d-c56e2427c5db	User creation or linking	Flow for the existing/non-existing user alternatives	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	f	t
e85c7e4a-442b-4906-acca-1a57c3bbf7a3	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	f	t
57164663-ad23-4e49-99c3-2e5f677cf6d2	Account verification options	Method with which to verity the existing account	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	f	t
f5266dcb-9bbb-4bd5-aa80-9d72cb9e5b37	Verify Existing Account by Re-authentication	Reauthentication of existing account	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	f	t
009b357c-e34d-4609-a71f-3db7d0b57615	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	f	t
e8d16719-7c80-4052-9d48-708c4beb2374	saml ecp	SAML ECP Profile Authentication Flow	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	t	t
574aaaf7-b80d-457f-b68a-ee04fc12ba34	docker auth	Used by Docker clients to authenticate against the IDP	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
ead4ba4e-b42f-4de0-a23f-4cb0b4e7d214	review profile config	64915411-5e90-4f94-9757-8cf984b78491
e9176ca7-cd3b-4a71-b6f9-e6cd5655d61f	create unique user config	64915411-5e90-4f94-9757-8cf984b78491
e5d621bc-5e84-4578-afde-d955191f2d94	review profile config	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3
af3d3883-5765-49b8-8942-c3db3c2bb7f2	create unique user config	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
e9176ca7-cd3b-4a71-b6f9-e6cd5655d61f	false	require.password.update.after.registration
ead4ba4e-b42f-4de0-a23f-4cb0b4e7d214	missing	update.profile.on.first.login
af3d3883-5765-49b8-8942-c3db3c2bb7f2	false	require.password.update.after.registration
e5d621bc-5e84-4578-afde-d955191f2d94	missing	update.profile.on.first.login
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	f	master-realm	0	f	\N	\N	t	\N	f	64915411-5e90-4f94-9757-8cf984b78491	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
1654150e-ab4c-4dea-84d8-b28406d51365	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	64915411-5e90-4f94-9757-8cf984b78491	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
f4b24e22-286b-4d5d-8546-a6c6562f24d4	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	64915411-5e90-4f94-9757-8cf984b78491	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
35f7f7cb-19b2-4585-b900-46943570c11b	t	f	broker	0	f	\N	\N	t	\N	f	64915411-5e90-4f94-9757-8cf984b78491	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
0a734152-c8df-44f7-b13f-f1b1a1658688	t	f	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	64915411-5e90-4f94-9757-8cf984b78491	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	t	f	admin-cli	0	t	\N	\N	f	\N	f	64915411-5e90-4f94-9757-8cf984b78491	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
8d0b8899-7f49-405a-9006-ad43b706ce5e	t	f	attendance-realm	0	f	\N	\N	t	\N	f	64915411-5e90-4f94-9757-8cf984b78491	\N	0	f	f	attendance Realm	f	client-secret	\N	\N	\N	t	f	f	f
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	f	realm-management	0	f	\N	\N	t	\N	f	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	t	f	account	0	t	\N	/realms/attendance/account/	f	\N	f	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	t	f	account-console	0	t	\N	/realms/attendance/account/	f	\N	f	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	t	f	broker	0	f	\N	\N	t	\N	f	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
daf50007-c534-4574-8205-2d83e93e5d0b	t	f	security-admin-console	0	t	\N	/admin/attendance/console/	f	\N	f	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
6fb4aba0-9188-4767-9e04-ed11b5c924bf	t	f	admin-cli	0	t	\N	\N	f	\N	f	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
05de3fa6-f271-4655-97ed-d8f344c7dcdb	t	t	attendance-frontend	0	t	\N	\N	f	\N	f	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	openid-connect	-1	f	f	Attendance Frontend	f	client-secret	\N	React SPA — public client with PKCE	\N	t	f	t	f
d516c226-1b0e-4f23-a38b-55b96c683433	t	t	attendance-api	0	f	\N	\N	t	\N	f	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	openid-connect	-1	f	f	Attendance API	f	client-secret	\N	Backend resource server — bearer-only	\N	f	f	f	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
1654150e-ab4c-4dea-84d8-b28406d51365	post.logout.redirect.uris	+
f4b24e22-286b-4d5d-8546-a6c6562f24d4	post.logout.redirect.uris	+
f4b24e22-286b-4d5d-8546-a6c6562f24d4	pkce.code.challenge.method	S256
0a734152-c8df-44f7-b13f-f1b1a1658688	post.logout.redirect.uris	+
0a734152-c8df-44f7-b13f-f1b1a1658688	pkce.code.challenge.method	S256
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	post.logout.redirect.uris	+
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	post.logout.redirect.uris	+
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	pkce.code.challenge.method	S256
daf50007-c534-4574-8205-2d83e93e5d0b	post.logout.redirect.uris	+
daf50007-c534-4574-8205-2d83e93e5d0b	pkce.code.challenge.method	S256
05de3fa6-f271-4655-97ed-d8f344c7dcdb	pkce.code.challenge.method	S256
05de3fa6-f271-4655-97ed-d8f344c7dcdb	post.logout.redirect.uris	http://172.20.100.222:5173/*##http://localhost:5173/*
d516c226-1b0e-4f23-a38b-55b96c683433	post.logout.redirect.uris	+
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
af2ec664-5f07-4770-8560-fa698c9c2249	offline_access	64915411-5e90-4f94-9757-8cf984b78491	OpenID Connect built-in scope: offline_access	openid-connect
19c34380-1212-46df-ba82-dfa8f542208b	role_list	64915411-5e90-4f94-9757-8cf984b78491	SAML role list	saml
2599e439-19bf-4393-8e00-b89b23175080	profile	64915411-5e90-4f94-9757-8cf984b78491	OpenID Connect built-in scope: profile	openid-connect
5fc668a7-9705-41c4-9688-adc3a4e7e4a6	email	64915411-5e90-4f94-9757-8cf984b78491	OpenID Connect built-in scope: email	openid-connect
7f861043-fc8d-41f7-aefa-2e8e30c29ca1	address	64915411-5e90-4f94-9757-8cf984b78491	OpenID Connect built-in scope: address	openid-connect
91ce5feb-3e61-4039-984c-d4737e75c93b	phone	64915411-5e90-4f94-9757-8cf984b78491	OpenID Connect built-in scope: phone	openid-connect
f7910512-88d0-4d20-871d-73c7f8ac788c	roles	64915411-5e90-4f94-9757-8cf984b78491	OpenID Connect scope for add user roles to the access token	openid-connect
68608df3-c419-4a14-8125-e224ce1c51d9	web-origins	64915411-5e90-4f94-9757-8cf984b78491	OpenID Connect scope for add allowed web origins to the access token	openid-connect
f3c64caf-7fd4-4fba-b358-43acc35491d6	microprofile-jwt	64915411-5e90-4f94-9757-8cf984b78491	Microprofile - JWT built-in scope	openid-connect
3d873f68-1ffb-4473-a09e-89b5f92bb581	acr	64915411-5e90-4f94-9757-8cf984b78491	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
0cdf50f8-c3c5-4da3-81dc-52d4d2331318	offline_access	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	OpenID Connect built-in scope: offline_access	openid-connect
10885cd1-f981-4c42-ab82-63bbf6ecda32	role_list	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	SAML role list	saml
f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	profile	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	OpenID Connect built-in scope: profile	openid-connect
c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	email	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	OpenID Connect built-in scope: email	openid-connect
444249d7-811e-4d75-a117-62fbd3f66701	address	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	OpenID Connect built-in scope: address	openid-connect
d6f61ad8-c6d9-45d1-851b-9b42ca971970	phone	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	OpenID Connect built-in scope: phone	openid-connect
90baaf31-30e9-4227-82d8-fa5aee3a15d5	roles	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	OpenID Connect scope for add user roles to the access token	openid-connect
9cef4577-9656-408d-911a-7ad0a5926b07	web-origins	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	OpenID Connect scope for add allowed web origins to the access token	openid-connect
4885a6e1-9812-469a-b7f3-873a5d1250ce	microprofile-jwt	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	Microprofile - JWT built-in scope	openid-connect
85bdde81-aca1-4a54-bf17-b00dd68883c7	acr	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
af2ec664-5f07-4770-8560-fa698c9c2249	true	display.on.consent.screen
af2ec664-5f07-4770-8560-fa698c9c2249	${offlineAccessScopeConsentText}	consent.screen.text
19c34380-1212-46df-ba82-dfa8f542208b	true	display.on.consent.screen
19c34380-1212-46df-ba82-dfa8f542208b	${samlRoleListScopeConsentText}	consent.screen.text
2599e439-19bf-4393-8e00-b89b23175080	true	display.on.consent.screen
2599e439-19bf-4393-8e00-b89b23175080	${profileScopeConsentText}	consent.screen.text
2599e439-19bf-4393-8e00-b89b23175080	true	include.in.token.scope
5fc668a7-9705-41c4-9688-adc3a4e7e4a6	true	display.on.consent.screen
5fc668a7-9705-41c4-9688-adc3a4e7e4a6	${emailScopeConsentText}	consent.screen.text
5fc668a7-9705-41c4-9688-adc3a4e7e4a6	true	include.in.token.scope
7f861043-fc8d-41f7-aefa-2e8e30c29ca1	true	display.on.consent.screen
7f861043-fc8d-41f7-aefa-2e8e30c29ca1	${addressScopeConsentText}	consent.screen.text
7f861043-fc8d-41f7-aefa-2e8e30c29ca1	true	include.in.token.scope
91ce5feb-3e61-4039-984c-d4737e75c93b	true	display.on.consent.screen
91ce5feb-3e61-4039-984c-d4737e75c93b	${phoneScopeConsentText}	consent.screen.text
91ce5feb-3e61-4039-984c-d4737e75c93b	true	include.in.token.scope
f7910512-88d0-4d20-871d-73c7f8ac788c	true	display.on.consent.screen
f7910512-88d0-4d20-871d-73c7f8ac788c	${rolesScopeConsentText}	consent.screen.text
f7910512-88d0-4d20-871d-73c7f8ac788c	false	include.in.token.scope
68608df3-c419-4a14-8125-e224ce1c51d9	false	display.on.consent.screen
68608df3-c419-4a14-8125-e224ce1c51d9		consent.screen.text
68608df3-c419-4a14-8125-e224ce1c51d9	false	include.in.token.scope
f3c64caf-7fd4-4fba-b358-43acc35491d6	false	display.on.consent.screen
f3c64caf-7fd4-4fba-b358-43acc35491d6	true	include.in.token.scope
3d873f68-1ffb-4473-a09e-89b5f92bb581	false	display.on.consent.screen
3d873f68-1ffb-4473-a09e-89b5f92bb581	false	include.in.token.scope
0cdf50f8-c3c5-4da3-81dc-52d4d2331318	true	display.on.consent.screen
0cdf50f8-c3c5-4da3-81dc-52d4d2331318	${offlineAccessScopeConsentText}	consent.screen.text
10885cd1-f981-4c42-ab82-63bbf6ecda32	true	display.on.consent.screen
10885cd1-f981-4c42-ab82-63bbf6ecda32	${samlRoleListScopeConsentText}	consent.screen.text
f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	true	display.on.consent.screen
f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	${profileScopeConsentText}	consent.screen.text
f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	true	include.in.token.scope
c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	true	display.on.consent.screen
c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	${emailScopeConsentText}	consent.screen.text
c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	true	include.in.token.scope
444249d7-811e-4d75-a117-62fbd3f66701	true	display.on.consent.screen
444249d7-811e-4d75-a117-62fbd3f66701	${addressScopeConsentText}	consent.screen.text
444249d7-811e-4d75-a117-62fbd3f66701	true	include.in.token.scope
d6f61ad8-c6d9-45d1-851b-9b42ca971970	true	display.on.consent.screen
d6f61ad8-c6d9-45d1-851b-9b42ca971970	${phoneScopeConsentText}	consent.screen.text
d6f61ad8-c6d9-45d1-851b-9b42ca971970	true	include.in.token.scope
90baaf31-30e9-4227-82d8-fa5aee3a15d5	true	display.on.consent.screen
90baaf31-30e9-4227-82d8-fa5aee3a15d5	${rolesScopeConsentText}	consent.screen.text
90baaf31-30e9-4227-82d8-fa5aee3a15d5	false	include.in.token.scope
9cef4577-9656-408d-911a-7ad0a5926b07	false	display.on.consent.screen
9cef4577-9656-408d-911a-7ad0a5926b07		consent.screen.text
9cef4577-9656-408d-911a-7ad0a5926b07	false	include.in.token.scope
4885a6e1-9812-469a-b7f3-873a5d1250ce	false	display.on.consent.screen
4885a6e1-9812-469a-b7f3-873a5d1250ce	true	include.in.token.scope
85bdde81-aca1-4a54-bf17-b00dd68883c7	false	display.on.consent.screen
85bdde81-aca1-4a54-bf17-b00dd68883c7	false	include.in.token.scope
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
1654150e-ab4c-4dea-84d8-b28406d51365	f7910512-88d0-4d20-871d-73c7f8ac788c	t
1654150e-ab4c-4dea-84d8-b28406d51365	3d873f68-1ffb-4473-a09e-89b5f92bb581	t
1654150e-ab4c-4dea-84d8-b28406d51365	2599e439-19bf-4393-8e00-b89b23175080	t
1654150e-ab4c-4dea-84d8-b28406d51365	5fc668a7-9705-41c4-9688-adc3a4e7e4a6	t
1654150e-ab4c-4dea-84d8-b28406d51365	68608df3-c419-4a14-8125-e224ce1c51d9	t
1654150e-ab4c-4dea-84d8-b28406d51365	af2ec664-5f07-4770-8560-fa698c9c2249	f
1654150e-ab4c-4dea-84d8-b28406d51365	91ce5feb-3e61-4039-984c-d4737e75c93b	f
1654150e-ab4c-4dea-84d8-b28406d51365	7f861043-fc8d-41f7-aefa-2e8e30c29ca1	f
1654150e-ab4c-4dea-84d8-b28406d51365	f3c64caf-7fd4-4fba-b358-43acc35491d6	f
f4b24e22-286b-4d5d-8546-a6c6562f24d4	f7910512-88d0-4d20-871d-73c7f8ac788c	t
f4b24e22-286b-4d5d-8546-a6c6562f24d4	3d873f68-1ffb-4473-a09e-89b5f92bb581	t
f4b24e22-286b-4d5d-8546-a6c6562f24d4	2599e439-19bf-4393-8e00-b89b23175080	t
f4b24e22-286b-4d5d-8546-a6c6562f24d4	5fc668a7-9705-41c4-9688-adc3a4e7e4a6	t
f4b24e22-286b-4d5d-8546-a6c6562f24d4	68608df3-c419-4a14-8125-e224ce1c51d9	t
f4b24e22-286b-4d5d-8546-a6c6562f24d4	af2ec664-5f07-4770-8560-fa698c9c2249	f
f4b24e22-286b-4d5d-8546-a6c6562f24d4	91ce5feb-3e61-4039-984c-d4737e75c93b	f
f4b24e22-286b-4d5d-8546-a6c6562f24d4	7f861043-fc8d-41f7-aefa-2e8e30c29ca1	f
f4b24e22-286b-4d5d-8546-a6c6562f24d4	f3c64caf-7fd4-4fba-b358-43acc35491d6	f
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	f7910512-88d0-4d20-871d-73c7f8ac788c	t
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	3d873f68-1ffb-4473-a09e-89b5f92bb581	t
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	2599e439-19bf-4393-8e00-b89b23175080	t
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	5fc668a7-9705-41c4-9688-adc3a4e7e4a6	t
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	68608df3-c419-4a14-8125-e224ce1c51d9	t
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	af2ec664-5f07-4770-8560-fa698c9c2249	f
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	91ce5feb-3e61-4039-984c-d4737e75c93b	f
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	7f861043-fc8d-41f7-aefa-2e8e30c29ca1	f
e33f3009-1cc6-49c8-bbfe-fd7af214e7ce	f3c64caf-7fd4-4fba-b358-43acc35491d6	f
35f7f7cb-19b2-4585-b900-46943570c11b	f7910512-88d0-4d20-871d-73c7f8ac788c	t
35f7f7cb-19b2-4585-b900-46943570c11b	3d873f68-1ffb-4473-a09e-89b5f92bb581	t
35f7f7cb-19b2-4585-b900-46943570c11b	2599e439-19bf-4393-8e00-b89b23175080	t
35f7f7cb-19b2-4585-b900-46943570c11b	5fc668a7-9705-41c4-9688-adc3a4e7e4a6	t
35f7f7cb-19b2-4585-b900-46943570c11b	68608df3-c419-4a14-8125-e224ce1c51d9	t
35f7f7cb-19b2-4585-b900-46943570c11b	af2ec664-5f07-4770-8560-fa698c9c2249	f
35f7f7cb-19b2-4585-b900-46943570c11b	91ce5feb-3e61-4039-984c-d4737e75c93b	f
35f7f7cb-19b2-4585-b900-46943570c11b	7f861043-fc8d-41f7-aefa-2e8e30c29ca1	f
35f7f7cb-19b2-4585-b900-46943570c11b	f3c64caf-7fd4-4fba-b358-43acc35491d6	f
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	f7910512-88d0-4d20-871d-73c7f8ac788c	t
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	3d873f68-1ffb-4473-a09e-89b5f92bb581	t
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	2599e439-19bf-4393-8e00-b89b23175080	t
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	5fc668a7-9705-41c4-9688-adc3a4e7e4a6	t
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	68608df3-c419-4a14-8125-e224ce1c51d9	t
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	af2ec664-5f07-4770-8560-fa698c9c2249	f
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	91ce5feb-3e61-4039-984c-d4737e75c93b	f
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	7f861043-fc8d-41f7-aefa-2e8e30c29ca1	f
9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	f3c64caf-7fd4-4fba-b358-43acc35491d6	f
0a734152-c8df-44f7-b13f-f1b1a1658688	f7910512-88d0-4d20-871d-73c7f8ac788c	t
0a734152-c8df-44f7-b13f-f1b1a1658688	3d873f68-1ffb-4473-a09e-89b5f92bb581	t
0a734152-c8df-44f7-b13f-f1b1a1658688	2599e439-19bf-4393-8e00-b89b23175080	t
0a734152-c8df-44f7-b13f-f1b1a1658688	5fc668a7-9705-41c4-9688-adc3a4e7e4a6	t
0a734152-c8df-44f7-b13f-f1b1a1658688	68608df3-c419-4a14-8125-e224ce1c51d9	t
0a734152-c8df-44f7-b13f-f1b1a1658688	af2ec664-5f07-4770-8560-fa698c9c2249	f
0a734152-c8df-44f7-b13f-f1b1a1658688	91ce5feb-3e61-4039-984c-d4737e75c93b	f
0a734152-c8df-44f7-b13f-f1b1a1658688	7f861043-fc8d-41f7-aefa-2e8e30c29ca1	f
0a734152-c8df-44f7-b13f-f1b1a1658688	f3c64caf-7fd4-4fba-b358-43acc35491d6	f
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	t
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	9cef4577-9656-408d-911a-7ad0a5926b07	t
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	t
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	90baaf31-30e9-4227-82d8-fa5aee3a15d5	t
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	85bdde81-aca1-4a54-bf17-b00dd68883c7	t
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	444249d7-811e-4d75-a117-62fbd3f66701	f
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	0cdf50f8-c3c5-4da3-81dc-52d4d2331318	f
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	4885a6e1-9812-469a-b7f3-873a5d1250ce	f
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	d6f61ad8-c6d9-45d1-851b-9b42ca971970	f
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	t
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	9cef4577-9656-408d-911a-7ad0a5926b07	t
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	t
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	90baaf31-30e9-4227-82d8-fa5aee3a15d5	t
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	85bdde81-aca1-4a54-bf17-b00dd68883c7	t
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	444249d7-811e-4d75-a117-62fbd3f66701	f
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	0cdf50f8-c3c5-4da3-81dc-52d4d2331318	f
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	4885a6e1-9812-469a-b7f3-873a5d1250ce	f
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	d6f61ad8-c6d9-45d1-851b-9b42ca971970	f
6fb4aba0-9188-4767-9e04-ed11b5c924bf	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	t
6fb4aba0-9188-4767-9e04-ed11b5c924bf	9cef4577-9656-408d-911a-7ad0a5926b07	t
6fb4aba0-9188-4767-9e04-ed11b5c924bf	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	t
6fb4aba0-9188-4767-9e04-ed11b5c924bf	90baaf31-30e9-4227-82d8-fa5aee3a15d5	t
6fb4aba0-9188-4767-9e04-ed11b5c924bf	85bdde81-aca1-4a54-bf17-b00dd68883c7	t
6fb4aba0-9188-4767-9e04-ed11b5c924bf	444249d7-811e-4d75-a117-62fbd3f66701	f
6fb4aba0-9188-4767-9e04-ed11b5c924bf	0cdf50f8-c3c5-4da3-81dc-52d4d2331318	f
6fb4aba0-9188-4767-9e04-ed11b5c924bf	4885a6e1-9812-469a-b7f3-873a5d1250ce	f
6fb4aba0-9188-4767-9e04-ed11b5c924bf	d6f61ad8-c6d9-45d1-851b-9b42ca971970	f
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	t
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	9cef4577-9656-408d-911a-7ad0a5926b07	t
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	t
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	90baaf31-30e9-4227-82d8-fa5aee3a15d5	t
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	85bdde81-aca1-4a54-bf17-b00dd68883c7	t
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	444249d7-811e-4d75-a117-62fbd3f66701	f
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	0cdf50f8-c3c5-4da3-81dc-52d4d2331318	f
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	4885a6e1-9812-469a-b7f3-873a5d1250ce	f
eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	d6f61ad8-c6d9-45d1-851b-9b42ca971970	f
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	t
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	9cef4577-9656-408d-911a-7ad0a5926b07	t
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	t
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	90baaf31-30e9-4227-82d8-fa5aee3a15d5	t
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	85bdde81-aca1-4a54-bf17-b00dd68883c7	t
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	444249d7-811e-4d75-a117-62fbd3f66701	f
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	0cdf50f8-c3c5-4da3-81dc-52d4d2331318	f
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	4885a6e1-9812-469a-b7f3-873a5d1250ce	f
6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	d6f61ad8-c6d9-45d1-851b-9b42ca971970	f
daf50007-c534-4574-8205-2d83e93e5d0b	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	t
daf50007-c534-4574-8205-2d83e93e5d0b	9cef4577-9656-408d-911a-7ad0a5926b07	t
daf50007-c534-4574-8205-2d83e93e5d0b	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	t
daf50007-c534-4574-8205-2d83e93e5d0b	90baaf31-30e9-4227-82d8-fa5aee3a15d5	t
daf50007-c534-4574-8205-2d83e93e5d0b	85bdde81-aca1-4a54-bf17-b00dd68883c7	t
daf50007-c534-4574-8205-2d83e93e5d0b	444249d7-811e-4d75-a117-62fbd3f66701	f
daf50007-c534-4574-8205-2d83e93e5d0b	0cdf50f8-c3c5-4da3-81dc-52d4d2331318	f
daf50007-c534-4574-8205-2d83e93e5d0b	4885a6e1-9812-469a-b7f3-873a5d1250ce	f
daf50007-c534-4574-8205-2d83e93e5d0b	d6f61ad8-c6d9-45d1-851b-9b42ca971970	f
05de3fa6-f271-4655-97ed-d8f344c7dcdb	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	t
05de3fa6-f271-4655-97ed-d8f344c7dcdb	9cef4577-9656-408d-911a-7ad0a5926b07	t
05de3fa6-f271-4655-97ed-d8f344c7dcdb	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	t
05de3fa6-f271-4655-97ed-d8f344c7dcdb	90baaf31-30e9-4227-82d8-fa5aee3a15d5	t
05de3fa6-f271-4655-97ed-d8f344c7dcdb	85bdde81-aca1-4a54-bf17-b00dd68883c7	t
05de3fa6-f271-4655-97ed-d8f344c7dcdb	444249d7-811e-4d75-a117-62fbd3f66701	f
05de3fa6-f271-4655-97ed-d8f344c7dcdb	0cdf50f8-c3c5-4da3-81dc-52d4d2331318	f
05de3fa6-f271-4655-97ed-d8f344c7dcdb	4885a6e1-9812-469a-b7f3-873a5d1250ce	f
05de3fa6-f271-4655-97ed-d8f344c7dcdb	d6f61ad8-c6d9-45d1-851b-9b42ca971970	f
d516c226-1b0e-4f23-a38b-55b96c683433	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	t
d516c226-1b0e-4f23-a38b-55b96c683433	9cef4577-9656-408d-911a-7ad0a5926b07	t
d516c226-1b0e-4f23-a38b-55b96c683433	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	t
d516c226-1b0e-4f23-a38b-55b96c683433	90baaf31-30e9-4227-82d8-fa5aee3a15d5	t
d516c226-1b0e-4f23-a38b-55b96c683433	85bdde81-aca1-4a54-bf17-b00dd68883c7	t
d516c226-1b0e-4f23-a38b-55b96c683433	444249d7-811e-4d75-a117-62fbd3f66701	f
d516c226-1b0e-4f23-a38b-55b96c683433	0cdf50f8-c3c5-4da3-81dc-52d4d2331318	f
d516c226-1b0e-4f23-a38b-55b96c683433	4885a6e1-9812-469a-b7f3-873a5d1250ce	f
d516c226-1b0e-4f23-a38b-55b96c683433	d6f61ad8-c6d9-45d1-851b-9b42ca971970	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
af2ec664-5f07-4770-8560-fa698c9c2249	cf66b3ec-736b-480a-981b-158ec7bdd59b
0cdf50f8-c3c5-4da3-81dc-52d4d2331318	66f81d47-9dc0-4756-a025-8a91e19390dc
\.


--
-- Data for Name: client_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session (id, client_id, redirect_uri, state, "timestamp", session_id, auth_method, realm_id, auth_user_id, current_action) FROM stdin;
\.


--
-- Data for Name: client_session_auth_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session_auth_status (authenticator, status, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_prot_mapper; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session_prot_mapper (protocol_mapper_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session_role (role_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_user_session_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_user_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
706f1451-3906-4d90-a0c9-79abc55dd4e1	Trusted Hosts	64915411-5e90-4f94-9757-8cf984b78491	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	64915411-5e90-4f94-9757-8cf984b78491	anonymous
cb1aec99-e647-4e50-acf3-202ec49b5448	Consent Required	64915411-5e90-4f94-9757-8cf984b78491	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	64915411-5e90-4f94-9757-8cf984b78491	anonymous
1149098d-274c-4fb7-bdd0-20ccfc36a6ff	Full Scope Disabled	64915411-5e90-4f94-9757-8cf984b78491	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	64915411-5e90-4f94-9757-8cf984b78491	anonymous
b662a109-d8d7-4401-ad9b-9003ef38c02e	Max Clients Limit	64915411-5e90-4f94-9757-8cf984b78491	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	64915411-5e90-4f94-9757-8cf984b78491	anonymous
3c330d0a-132b-4f40-bf4b-ba5aea54f6d7	Allowed Protocol Mapper Types	64915411-5e90-4f94-9757-8cf984b78491	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	64915411-5e90-4f94-9757-8cf984b78491	anonymous
2655428a-b358-4f0e-9dae-bd47cbd16ecd	Allowed Client Scopes	64915411-5e90-4f94-9757-8cf984b78491	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	64915411-5e90-4f94-9757-8cf984b78491	anonymous
753b1b2a-b08d-4e33-859c-74e8d2571fc3	Allowed Protocol Mapper Types	64915411-5e90-4f94-9757-8cf984b78491	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	64915411-5e90-4f94-9757-8cf984b78491	authenticated
970da44e-588c-4986-baa0-eec5df746d16	Allowed Client Scopes	64915411-5e90-4f94-9757-8cf984b78491	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	64915411-5e90-4f94-9757-8cf984b78491	authenticated
20249857-10c8-4cd8-ada0-2bb24cd0e81a	rsa-generated	64915411-5e90-4f94-9757-8cf984b78491	rsa-generated	org.keycloak.keys.KeyProvider	64915411-5e90-4f94-9757-8cf984b78491	\N
735f432c-b6e9-4ec6-afb5-aa631660a70c	rsa-enc-generated	64915411-5e90-4f94-9757-8cf984b78491	rsa-enc-generated	org.keycloak.keys.KeyProvider	64915411-5e90-4f94-9757-8cf984b78491	\N
aeefde68-8925-435d-af5f-9cb8b7679430	hmac-generated-hs512	64915411-5e90-4f94-9757-8cf984b78491	hmac-generated	org.keycloak.keys.KeyProvider	64915411-5e90-4f94-9757-8cf984b78491	\N
73fd4852-9c7d-41ee-ab22-e5940aa42f88	aes-generated	64915411-5e90-4f94-9757-8cf984b78491	aes-generated	org.keycloak.keys.KeyProvider	64915411-5e90-4f94-9757-8cf984b78491	\N
8b4bc8b7-2ac5-4644-a097-d970e8e107ed	\N	64915411-5e90-4f94-9757-8cf984b78491	declarative-user-profile	org.keycloak.userprofile.UserProfileProvider	64915411-5e90-4f94-9757-8cf984b78491	\N
804c48f9-2fce-46eb-9146-ef78d5f5654c	rsa-generated	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	rsa-generated	org.keycloak.keys.KeyProvider	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N
acedbc54-b07b-4ee7-918b-97084616db4e	rsa-enc-generated	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	rsa-enc-generated	org.keycloak.keys.KeyProvider	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N
a291876b-6342-4db3-963c-fc67cf85a7ae	hmac-generated-hs512	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	hmac-generated	org.keycloak.keys.KeyProvider	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N
b092f2fe-962b-45a3-a58d-de784589b4de	aes-generated	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	aes-generated	org.keycloak.keys.KeyProvider	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N
61332d25-2304-454b-bd65-b90fb7ff64ed	Trusted Hosts	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	anonymous
ec47ea02-86fd-4aee-a022-f5892f29328c	Consent Required	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	anonymous
d37305ac-f0d9-480f-8db1-5b5ab1103205	Full Scope Disabled	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	anonymous
5353d886-a822-42ed-8890-a7a746ef493d	Max Clients Limit	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	anonymous
944d78d3-1058-4f5a-ada7-9459bff0ef8e	Allowed Protocol Mapper Types	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	anonymous
13c0b66a-6aa1-43e2-a885-ebdc1bd8f8de	Allowed Client Scopes	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	anonymous
20d22e64-d5a7-4c2c-83db-038f29e0eb3d	Allowed Protocol Mapper Types	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	authenticated
d291742c-b69c-47cb-bb17-d51455d3f4ca	Allowed Client Scopes	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	authenticated
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
f376cd19-cf7e-4948-a1ed-a6cc3d7b0637	3c330d0a-132b-4f40-bf4b-ba5aea54f6d7	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
af6fa5aa-091f-4d70-9d24-23f74d681a30	3c330d0a-132b-4f40-bf4b-ba5aea54f6d7	allowed-protocol-mapper-types	oidc-full-name-mapper
eb8eab5d-7cc2-4f20-a37f-b8d51f5946ca	3c330d0a-132b-4f40-bf4b-ba5aea54f6d7	allowed-protocol-mapper-types	saml-user-property-mapper
b7f52742-5cb3-4512-a885-ff3a8dfb9da5	3c330d0a-132b-4f40-bf4b-ba5aea54f6d7	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
f376152f-76ed-40ad-91f4-6632e8897311	3c330d0a-132b-4f40-bf4b-ba5aea54f6d7	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
3f09d291-e6ff-4c6f-a25c-270fe72b3b89	3c330d0a-132b-4f40-bf4b-ba5aea54f6d7	allowed-protocol-mapper-types	oidc-address-mapper
702cbda3-bac1-4246-9f1f-0fa3b5b53bcc	3c330d0a-132b-4f40-bf4b-ba5aea54f6d7	allowed-protocol-mapper-types	saml-role-list-mapper
c88dd34a-a660-4e44-81de-969caf6f71c7	3c330d0a-132b-4f40-bf4b-ba5aea54f6d7	allowed-protocol-mapper-types	saml-user-attribute-mapper
82956d67-c9cd-486c-b96e-1865df9aedbc	970da44e-588c-4986-baa0-eec5df746d16	allow-default-scopes	true
fe109500-9f73-498f-9a96-ae304bf793bc	2655428a-b358-4f0e-9dae-bd47cbd16ecd	allow-default-scopes	true
8a9ecc78-312e-4889-9241-1e9684f47d71	753b1b2a-b08d-4e33-859c-74e8d2571fc3	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
08869b38-f1f3-4844-be0a-c97684a7a976	753b1b2a-b08d-4e33-859c-74e8d2571fc3	allowed-protocol-mapper-types	saml-user-property-mapper
d2133cb8-2bca-4c1e-87e6-2f3875cc8d53	753b1b2a-b08d-4e33-859c-74e8d2571fc3	allowed-protocol-mapper-types	saml-user-attribute-mapper
0cae37ec-c575-453e-b8ba-1da4e4c4630c	753b1b2a-b08d-4e33-859c-74e8d2571fc3	allowed-protocol-mapper-types	saml-role-list-mapper
ab787caa-5cde-4b05-9935-a6df9a3702a8	753b1b2a-b08d-4e33-859c-74e8d2571fc3	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
2726e550-fd8e-48d4-991b-310053780fd1	753b1b2a-b08d-4e33-859c-74e8d2571fc3	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
5cc44565-1a65-4173-b43b-d4e022635955	753b1b2a-b08d-4e33-859c-74e8d2571fc3	allowed-protocol-mapper-types	oidc-full-name-mapper
3f5e454f-9473-446b-bd6f-30dd1adb78e0	753b1b2a-b08d-4e33-859c-74e8d2571fc3	allowed-protocol-mapper-types	oidc-address-mapper
4c5bf85c-17a9-4af2-87d8-c85c67fef49d	b662a109-d8d7-4401-ad9b-9003ef38c02e	max-clients	200
5ce94e60-72a4-4ca1-9b05-1f6460978cf6	706f1451-3906-4d90-a0c9-79abc55dd4e1	host-sending-registration-request-must-match	true
362e9508-35d5-4c24-944f-36a1123c63e7	706f1451-3906-4d90-a0c9-79abc55dd4e1	client-uris-must-match	true
692b6b5a-5e2f-4c0d-ae8a-91f68e0c8e2e	aeefde68-8925-435d-af5f-9cb8b7679430	kid	11dfb462-cba4-41dc-81d8-8adbc773998c
398a4ea0-967a-4368-8118-2cd6f043faea	aeefde68-8925-435d-af5f-9cb8b7679430	secret	uQb-V7fBEAbTaEC8cuPNvBR2msROpciyzjQ-97w9_qS7Z9pAOFk-TyyefRgUuBBtHw5bIp-qcA7xwDCt4G_fWxtXMir18AKoISvyfBczqnvMF33kmBbwDCh8QkrTKdEZ4kedewStY8VcPQB3C5eqBf-zsKMIglQunwMXPrFF2_E
98b218c1-dcf6-48c9-b302-98bcaff3446e	aeefde68-8925-435d-af5f-9cb8b7679430	priority	100
ba3df303-9133-4815-94ab-76df85de70d8	aeefde68-8925-435d-af5f-9cb8b7679430	algorithm	HS512
49f0e7fc-2b24-40cc-9a66-6e185a903d37	20249857-10c8-4cd8-ada0-2bb24cd0e81a	privateKey	MIIEogIBAAKCAQEArrNJQcXuzLGwcFZgLJLlRZLrndrcmO/5jgTbuqAmOxTOcBRJymDwnDnNOTVWXDT8vUrcKndVuzQNAzw03Uo0VwhW8SGw/mDHDolQn+ft4hKAKiwZ7jr5mhVIkoPUN57isaguHYvGAyaYaFMSqTnhxDyIfVzOQ3uWfjahYFoEvNE6TLR2GE3oGihEJOUdVuvoECjMjTgbixyUTQ/Mg5wXv00rjb97AzW32KyqXKztAdoKD0auuV2PNqCVbaaifUjw43cFzg9dZ4DCjmq70X/mifLcZgrYbYWMaiimA4ZX1vJauyHD0olN4cJYuAPAJfGkW7J5Tw5fm+L4zTPON4xeYwIDAQABAoIBAFKRDah2YdyAhoExcZbffliZjZ43mFb35BxJE4hqtGbr+H1kOVPa6R0M/H9zQ/OkX2cfgFrZt70YZqYGyH1l2sLfgCfK4pn3J10pbN+GgBl+4PANk9vSJ7G5KWmFwMDg6QdKEzGHo/hNP27fBEzSvG9ApMmLGTkvqfrQ2whswxxxhX0LvQkj1YgNJ94EruTUSbFDk7eMnV1PfF//PqByh1y6NchId1UoLfEoowAcUbPFTDGZ4tKSLSTtGH9jnIi1oeVRoh3w8pEyMKRI3fmcsG2FTHK8JvjDZvlo02f32LGnQABiusJ2CQc6VlsRGoVv++0cNwfj/3yQklXrJ83xRHECgYEA6rrnv4o9jITqbfUFsKZDEvYxZ096td9WS2ckNkt6pDROgjUWS+16/xm6hshw6g/i9ztJqkhJr1aQLTB4t//qeJdISKvkRa1CCT8Fu6q/ZCg/vD+Qejn2/vYqEX0AzJOrGHNjuuxSBJFeIRJtNxikeeYDouAVgp/6hOo7Gc7Uoh0CgYEAvofa4O46a8iHR7SN8NF+rTfgDAk4p1yfNeBaUOlbD1gisVOEmzGzwOJU7/uV5zUE4FrF89NGKT4mnJocLg/KUreQt3vVsc1p3lVZcaisGCy5LQKnDQxPwdztskGhfaEzxdyr6I6IyJFowAH2TAkIUt3SHIlLv++op+99KW6tGn8CgYB6KLlRMqWjisziWsESVQTVSnEdnfxzyH6FkXEEHLX/3QT6uJwY+ceoGYC8gnZZKdlp514IE8TdToSMMAyzXaluBvVkdKjBJlEWtMjMCSm/+z5oPwB2y9HikMQGA/M1hKhnei3t6u0oWWsOdSOHp/h5RB6iVlJ7f7yGDcyiOsTodQKBgExfbK9JDwXxZbiqeVMUxrBse1SXxavghrkz60APqj6mV5G5JqiG7cTddKqVsGrzZ7b+6+Zmw/L4RMX1SGJ2VeV+S3YhH3GcI1nJ4Iac1A8Erl2KeKfUTYwqIOWZRUB0g6pGYGph6BZtow2EO9QSstF0tSpXJpQTXwmiCAu5n43FAoGARpC3zW753/VPeBfu99Kf5T7iF25QhG2+o6frF4j6R+tRUXDTTueNhQSxBwsePkq1S1wtJpWYjF1/YN6g7A9adxbbWREC+mMRWlIXD4T6TPk6ZA4EE8jfHRlE6/7yzWqNrQ/eVd7UuSQKHsuh4CqNipF4vxmonPzFQ4+MOPdAR0o=
734d3975-ddd8-4fe9-82cc-fcbf020ea820	20249857-10c8-4cd8-ada0-2bb24cd0e81a	certificate	MIICmzCCAYMCBgGdYXiZMDANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwNDA2MDYyNDQ2WhcNMzYwNDA2MDYyNjI2WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCus0lBxe7MsbBwVmAskuVFkuud2tyY7/mOBNu6oCY7FM5wFEnKYPCcOc05NVZcNPy9Stwqd1W7NA0DPDTdSjRXCFbxIbD+YMcOiVCf5+3iEoAqLBnuOvmaFUiSg9Q3nuKxqC4di8YDJphoUxKpOeHEPIh9XM5De5Z+NqFgWgS80TpMtHYYTegaKEQk5R1W6+gQKMyNOBuLHJRND8yDnBe/TSuNv3sDNbfYrKpcrO0B2goPRq65XY82oJVtpqJ9SPDjdwXOD11ngMKOarvRf+aJ8txmCththYxqKKYDhlfW8lq7IcPSiU3hwli4A8Al8aRbsnlPDl+b4vjNM843jF5jAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAGLv3TT45uONrchmcrqpTeFy/JY+6EhNrxLcqkhH3Ix16TFp1d3DXT1AvoGcT/sQRYO/b6kuRCp3Sk3qLV4I1OBS99+yfNlwQkPatsAFTYow7vo17bVsq9M/IYDegP8q9F9d+JRTaOXwtTNl/1BxCqJ9wqU2VvhmMAQi6Yq1IKKBDX8U014psSivl34nygbOcgH+3wSkMHrkhTPhoBn8tqGoMF0YMzFoHdvhp67ShYoABAYExYqPZPIczrfOfTcMCvhIAlMxRC1LJOa60JbXuHqmz4H0knBd2k8VqF8lu3Rj2TBLn38I55xjapIfK/GeqcOe6z+/krr+/eOp101LxkM=
ed5db23f-71dd-4803-9f0f-629154f8326a	20249857-10c8-4cd8-ada0-2bb24cd0e81a	keyUse	SIG
b0c1099c-8a71-4f02-9f02-6c488a95c09d	20249857-10c8-4cd8-ada0-2bb24cd0e81a	priority	100
9f1ef8c0-887b-48c2-88c4-c51eda2dde90	8b4bc8b7-2ac5-4644-a097-d970e8e107ed	kc.user.profile.config	{"attributes":[{"name":"username","displayName":"${username}","validations":{"length":{"min":3,"max":255},"username-prohibited-characters":{},"up-username-not-idn-homograph":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"email","displayName":"${email}","validations":{"email":{},"length":{"max":255}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"firstName","displayName":"${firstName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"lastName","displayName":"${lastName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false}],"groups":[{"name":"user-metadata","displayHeader":"User metadata","displayDescription":"Attributes, which refer to user metadata"}]}
b22e4410-902b-457e-b2f7-4c1d692eef7a	735f432c-b6e9-4ec6-afb5-aa631660a70c	keyUse	ENC
53de3410-07ea-4ee1-b0bc-590f630274e3	735f432c-b6e9-4ec6-afb5-aa631660a70c	certificate	MIICmzCCAYMCBgGdYXiZ3DANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwNDA2MDYyNDQ2WhcNMzYwNDA2MDYyNjI2WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC+dsqelbVSAptbCZ0pIjB1wfp8nXcacxehF6CMtlrFqlNJoVgFZiKg+EUNNXWxjAdvVdraVNheGCyUzYg947yetqWEkxuNyq+QXlEh33gzCykjG9P9V2a1H38+AzhaBQPiCszr8mLo8BH0Ur+B7bFs0f5VrV9tJQO76EpStKPvWv598WMSq/tPOhcRXWj/7tG5VSmm28DX5XUMU+jHCrbIzeIQ3/tHLGbVM3edVn/maFWSCmsnPfyjPWo+khSCH0sVOElJXhI4xgpMldfzYlSVlqAv7608wojjXspvbn2F3vXZFCqvuwMcM3yhDhywCKw7JCSGa18nmpGqaY9b/9NxAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAHPdV5G+BT6opJcKR3/f45iShN8u86/fR29qCQkOTumiz/8jIibwI9Vx1Jrotae6Bj9ySDxqPjt4cTkDkeORSMnfHqkfIJiKjSB6zmljBr8qw2g1G4g95kqL6IWyet1ikR6u6hyw0tDOVizdKF8tKpUrV5eEvzFJChMCnXzmh627nwWTaFolgAP9OQHnYY98PEx/VdrEh3JWVDwv/1QEjJO/T5Tvm0bfdNaT8qdAN85sPgoxqV9K6UBOYgHzO7emFH1/+/lQ7ziRHl+0AEIJLXZk8pxpVcfKGAHF25eP9oh/HCP8Dn/grUu1G3aSKBJiic14WzgOqTpELOT/nfwxp3Q=
93a15251-41bc-4ada-b481-58b50e4ba728	735f432c-b6e9-4ec6-afb5-aa631660a70c	priority	100
dfa9c7ab-2766-48d5-998b-fcf8b3c48865	735f432c-b6e9-4ec6-afb5-aa631660a70c	privateKey	MIIEpAIBAAKCAQEAvnbKnpW1UgKbWwmdKSIwdcH6fJ13GnMXoRegjLZaxapTSaFYBWYioPhFDTV1sYwHb1Xa2lTYXhgslM2IPeO8nralhJMbjcqvkF5RId94MwspIxvT/VdmtR9/PgM4WgUD4grM6/Ji6PAR9FK/ge2xbNH+Va1fbSUDu+hKUrSj71r+ffFjEqv7TzoXEV1o/+7RuVUpptvA1+V1DFPoxwq2yM3iEN/7Ryxm1TN3nVZ/5mhVkgprJz38oz1qPpIUgh9LFThJSV4SOMYKTJXX82JUlZagL++tPMKI417Kb259hd712RQqr7sDHDN8oQ4csAisOyQkhmtfJ5qRqmmPW//TcQIDAQABAoIBACFV7E/GVyaD80oDTEELTV0G9v8BlnuIIl4dIwoNzqRjE9HCzgOf5Ta0TW2q6i8JmbGIXtYw3G/XnlHrCUn/xp8my6CBGOT/0Suc/mlF0iVo8inFcJyaRA02dpBVgvLqhsv05Pn1Ag/QGOxg4Ujt38xykqfPQPD69gTY+s0v9bNqNc1pgyOzyvXWr4LAcHcZweguNPksjAcZYF9AU2qDuwZkDmeCrmB8PJUb0v/k7yRxeYLkFKSUpExHyiW0lhz0oo6AzzYzbnaeMpiY5Sydtj9CSSFRAItc4dJDFyoda1Kv7XlTmBaBggbnK3AUAd5pTjZpOBqLy7DpMSCIxBT0LesCgYEA6dOT3ndgOSZ7GtPTtxxLxl9n3CYtCVAeMheX8UuMe7W0o6+2mSnOvDSpX71VXfkQ48CEJwqKnNaQcgBC9aykfJHB5IoIzjAUr5tglmVKAmRFaIFmD5qNNAbg4nNd4T2Rh9IEmGDIWVvrN6xCAE2N9h2mrg2HmXPKjmCpmBSVXq8CgYEA0IaJpqMQbA2MU5hLrdwiDn0FCN2ugBmeRmPfwuHUXd2n80cPBy/ddWQDx8gUtGdXShWDu3GJYqhws4PNbxPou/yE2dP5YN4sVV+5immNNxw51KG2fUw1A9Ir8czN7OHHUQ2Qpnh39+73qOy7BDGTki2d0ASMMNBILDnC5e7Rd98CgYEAqjjq5wOEu1Y2PHuFH0KsL0f5Nh1cn/EBanoelPzo0o6faKJcjfgPlpfHzfjpkrXlA8h87GcSLcdN9JAYLv116XG684NBkckS5hx5HkOyszcICGJbSHS84uk3AeP2rijCL1xHGB8s+1CdVjRDADF1bXx8gS08UAwpo6jfDeW+L+UCgYB/NvTXUnf8U6+eeDUDVl74k9D0fbmtsPNcYiXq0LcspMOHqXxDmDH1IhUkVq46+SjJq6J4QmXcaIKJIgm8kFrWBNJPygBD1ocZdpLNHGPokTG+xQF+I3XcZOYmWBnxQDTHAA2VYb1e5sz0o6fcgRpUfbvfYkbcqNS/FmYOvMnR5QKBgQDBfaXmzxiUo93Ij96n6iyxYfhO4vbJCbnTgU4/aoNnByzCdUuTCc4I+sAvKsbuMxMGdEMQo2QNP4MIPxDyDFoRJZ3xJn9sv9BdaOI0gWhN7Ff/1oiQNzuqQnJs5C7g/LB5nX7O9HQ13vYSbDaSoffwhUCw4I8Wc9ccGsOP+tBQXw==
8bbc6c61-16eb-4c37-9f31-c3b1586192d5	735f432c-b6e9-4ec6-afb5-aa631660a70c	algorithm	RSA-OAEP
506e27c5-d152-4685-8220-051241132fe8	73fd4852-9c7d-41ee-ab22-e5940aa42f88	secret	OcQ9gDTrQLG_olutkMwctg
110044dd-5275-45b5-b3d6-da540908d5ae	73fd4852-9c7d-41ee-ab22-e5940aa42f88	kid	4ac809e4-28a5-47a7-b5bb-f91fc77e2976
e231c250-28cf-4cd2-84d0-22768181646b	73fd4852-9c7d-41ee-ab22-e5940aa42f88	priority	100
0194acc9-0665-46d3-9478-df7533dbde56	b092f2fe-962b-45a3-a58d-de784589b4de	kid	1d42fbe8-ed9d-4ecd-b09a-80b17df7ac0f
3cec50a1-1804-4345-a892-a6af601ab289	b092f2fe-962b-45a3-a58d-de784589b4de	priority	100
5423b30c-d8e4-4cd8-b387-edb394624f94	b092f2fe-962b-45a3-a58d-de784589b4de	secret	GM8Sfx87EZIdPw3uVG02nA
f21f239a-b7ba-4bf2-a2c7-7049d9ff54c1	a291876b-6342-4db3-963c-fc67cf85a7ae	secret	4NzzzWgauPC08yE6N640OFInHbMnTmcF2HUDkY0X8Wbi-l7aAZUFtSXxgJZpl9D9wOxKRBzjvx2DLzkMStGy640Naywjb5jVs9nYy4v-ZDVQAUGAhjGK9T38UZFfEP9zy5UxD111MnvQXU91GBr98p6FMvqhKtgQSfwKE6eosrc
73735dd2-bffd-432a-b8db-30f6f0ee2837	a291876b-6342-4db3-963c-fc67cf85a7ae	kid	5df08620-840a-4288-a739-4d5ca1fa6278
7aa2f81a-5b87-41be-a388-1ffdeb62ac29	a291876b-6342-4db3-963c-fc67cf85a7ae	priority	100
cfdc15fc-8cd3-4598-ad1b-dccc0596a7ad	a291876b-6342-4db3-963c-fc67cf85a7ae	algorithm	HS512
5aa04bd8-4cd8-465a-8181-942b8ac9af67	acedbc54-b07b-4ee7-918b-97084616db4e	privateKey	MIIEpAIBAAKCAQEAqTfKKmeBque+uXHpzB+HFO/F90OmuuuTIlNtmlRixnGGFzbqzUjb7TOwWsdeCa4nJNnqrqu84Igykku3NOpfUCnVwnA861kzi+cPZZmW1Jr2O75EHxGf6jcV9KEbxg80dAFIedycRQA0pzgGRH23sJDClAXS+8u7185OEZQKE3GN1WOMF+90q3pZjy29jDgYiCuAk7NIt50sneeesV90YTILNjJbofvS9qTYlCNezPqzgkyCMxHOqTIxyOaiQg0uZH4DOUWQ2fvZ31bg2ao5ZYoZ6Y+q3rrPqfZeZ2htdAo6qDK8ZXGD02Cu6HEMTV106WwRA25Xo7rnfy1dJAxwHQIDAQABAoIBAB2wUFu2u8kKrkt2eTTLPkW12LeMasMGRFMELKlkT00uSz6k77azJwTbqgAPVQghQjRkuFhLgNCrDKZeuubBjRXxNRQPYZzQEmtkD289rnkgM/3g4K5LxxEOd59rKcaK0eLde8QHqPIxOkuxWGYpYXJMv5q9V9o+ETeodkl+vfLRks/xRwyVaAwrvh/eeceNdD2ppX5ICE9c0hTTov3SU1hgcubgeG6TR3A8AeNg5Pmrl2NeDjnOPKXRxYb6XfdqDHm+oL0WhVv4qG6uUG3qOrVIAry4AUxyXiPtJh8sh7qoUX2JsrR1u2M4XYRG0Ah3VYubmbwMGHcujkaglJIE9oECgYEA5iNUPwMlzH5OfSKBji7+a7OWPoYNOfwtbedFAM7zdgO3UDLjIaUKFmper/dQwCbupllb/4WvAZpi26FOln6ivNU++I3LM9luswyYY3ASQEAdelAIJgZ9lBGuvFYHoRML/RnviWGPBqzIFvw6lbfCmeeBNRJobdQOTwQ8WKjKfJ0CgYEAvDvlUnBYS6lCoXujNCI22Loz0KV30uNgLCC5oYJHGRguUaa1r3Ev1MsdusZADq+93oGO3OgCMR4kAV9UTAuNOQpwCkUUMZv6T1TAMM6kWt/6KwTaucMoJBrl1Kf+EGig8y35/S6n4ERJD2xGZcTHvtx3N27kbXb5EZf+dITAqYECgYBlF1fGZieQcFsh9KpcPqBbxwNUa6Ybtn5uLIzPEhk32eIIRJIpEUohFpCJU2YRQgjK4a3bzGlXlu2d9HmE+hOaR0HmBMMh/3z1Aa9e3rflqURJmiY6Ldez1yCeclvfkXJOt7nU6xncoMEz94/0fEfrOxoyqedddyzh4MZxW5O2sQKBgQCLSUr9ALLlcd8jPSjcGAE7yDU1TGvpOmVc4e5ay9suf40u0EybAQdiz9Y08iROec7myjnbzzZoACSme1MWXmnm7olPoCQ8PW4wq8b3lsFZmWk10gbD9NxMMzckcBb5L2MB72CP76k7s2vYpMdG4SDpY5w4Aa+4LJRLZ4xbziv+gQKBgQC/Nhe8pT1xOlfx4mQhc0rwvkL4xNz3PxyL46I5KRhF2NYgV03oUxpW0u8jc2KMIM/Pv1wbArBgHpq8LlJb1bSni8MmDH5CHwgFGqpNiZr0dgFhqtoNKYWhsR85mgPDxGHomqEZUBZ/1ZVCiGPnehmShn//lNvrenMA1Ecte4m6mw==
4175a69f-95e3-4c86-9044-1dce1ea07352	acedbc54-b07b-4ee7-918b-97084616db4e	keyUse	ENC
4c69e775-ef87-43ad-852e-4722e3d14184	acedbc54-b07b-4ee7-918b-97084616db4e	priority	100
74bc77fe-599c-4ac1-8a35-19d65a108e86	acedbc54-b07b-4ee7-918b-97084616db4e	certificate	MIICozCCAYsCBgGdYXijbjANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDDAphdHRlbmRhbmNlMB4XDTI2MDQwNjA2MjQ0OVoXDTM2MDQwNjA2MjYyOVowFTETMBEGA1UEAwwKYXR0ZW5kYW5jZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKk3yipngarnvrlx6cwfhxTvxfdDprrrkyJTbZpUYsZxhhc26s1I2+0zsFrHXgmuJyTZ6q6rvOCIMpJLtzTqX1Ap1cJwPOtZM4vnD2WZltSa9ju+RB8Rn+o3FfShG8YPNHQBSHncnEUANKc4BkR9t7CQwpQF0vvLu9fOThGUChNxjdVjjBfvdKt6WY8tvYw4GIgrgJOzSLedLJ3nnrFfdGEyCzYyW6H70vak2JQjXsz6s4JMgjMRzqkyMcjmokINLmR+AzlFkNn72d9W4NmqOWWKGemPqt66z6n2XmdobXQKOqgyvGVxg9NgruhxDE1ddOlsEQNuV6O6538tXSQMcB0CAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAoVwsUJFgKtqh8gDcXjh1MJ85FSkDP8W/KGTuhJdKOSR9Du7/OvvWzl2utm6s7Cq7iOzge9SQWKNZbTJSHqk1B4Ce8T4xixzKjXFdJ0s1m6MUsCfSXNn06QTHSKis5HZ1pNF/GUq2kyLJRd1iH5CKKo/ltHmZDYr+/hVwFmdYNBUH6+eWwl3sTdvwKgx56OhCTndrLzquoKzCNoPMiqk96qzHljmyKcJc+gds1rAztEctO/unSAKOuTGhamQIXVrP8EghLHMlADGtV5zoopEdSdVONKpX1wIzoWcu8papOrJN6/hb7yvbLNRvzII9LV+SXyCZJJ+vMrJu+gTvZ/V25g==
d69dd2d4-4e2f-421d-a635-2c0ca2c3d09d	acedbc54-b07b-4ee7-918b-97084616db4e	algorithm	RSA-OAEP
719a0322-0f07-4a86-b59d-e6170656563e	804c48f9-2fce-46eb-9146-ef78d5f5654c	certificate	MIICozCCAYsCBgGdYXijETANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDDAphdHRlbmRhbmNlMB4XDTI2MDQwNjA2MjQ0OVoXDTM2MDQwNjA2MjYyOVowFTETMBEGA1UEAwwKYXR0ZW5kYW5jZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALfsEby3tdgciN7U0XBGxYZg+uy3Xdc/1haTsLeoVmFn3jD2SrJGIseEtaxwQKPILHGJeJhj3akLxl3edsDnp+NjeVpqOO9PVIiy73DRkQQtiqLsxjAJv48GX3yC54QFibNfLEA7G0kYCHZGoDlZIdPWqfGRLcXlGdlBBXX1HDkNkjW9p1U6Uh5Fb4+RpZ3scn7MclMf9YTdSHSHSPfCxB9wZEprb7uAnjFIlG0lyFQq57fCm7/gv+cVpRWja+tjGP1QHQ7CjCA/qT3rXO9L5/hT4BAHBAxofJ4pb1+s6UklUFdeJGjtXqGi3LoRFewmVunEAufT/MigE8u3vRjjpT0CAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAgiTLh5cUJ3LoaukExWGpSP2Q8Jwx3cePsNxQOTCEVrnE/+xKrMmF+v+Bpjl0v23Yxl4fuo20z/fhA9k2XzAzqGs1W6spH4wl3d6nWnDOd0TvJuJnB/Qu26fFhhjI70OZjcG6naSW2BUiWxBlhAAdkktzVa1fmlC66auFCbwCeUuHcmrjf6jKQx3MhxNAPX5K7vitji0oeR/Gq3cw/xdQGjA+F94ccia5vqa6P51Hv4JyuwMPhS/aqlxxBwRafFE6lEEBDg1svLxMEl7Y/vu8p3neSLdXEd4NgJmf40Rkbuff6mhuiQROaDDqMfPZDcU45/Uv8byuphM3GCHIpeaOzA==
415457d9-5e68-42d5-a8fc-d7e512ceded5	804c48f9-2fce-46eb-9146-ef78d5f5654c	priority	100
cee7b663-ddd8-4226-bd88-488986b5431d	804c48f9-2fce-46eb-9146-ef78d5f5654c	keyUse	SIG
15ea3a3e-ecd8-4212-a002-ed25a5727cfa	804c48f9-2fce-46eb-9146-ef78d5f5654c	privateKey	MIIEogIBAAKCAQEAt+wRvLe12ByI3tTRcEbFhmD67Ldd1z/WFpOwt6hWYWfeMPZKskYix4S1rHBAo8gscYl4mGPdqQvGXd52wOen42N5Wmo4709UiLLvcNGRBC2KouzGMAm/jwZffILnhAWJs18sQDsbSRgIdkagOVkh09ap8ZEtxeUZ2UEFdfUcOQ2SNb2nVTpSHkVvj5GlnexyfsxyUx/1hN1IdIdI98LEH3BkSmtvu4CeMUiUbSXIVCrnt8Kbv+C/5xWlFaNr62MY/VAdDsKMID+pPetc70vn+FPgEAcEDGh8nilvX6zpSSVQV14kaO1eoaLcuhEV7CZW6cQC59P8yKATy7e9GOOlPQIDAQABAoIBAAycpYK5XkDZhBEzqsD2OWlDkTFWSZsPB5E4w290nafERZo56VlcMdpYoVSXxfb1LQcEFD7u6i5DXnDlZmNH/106XwHyMsFGQVe2XXDxDe6paM5PSi/VG0uldjrFhzaoYo7oQdKNuwtCGKJzqV0FXap3F+Q2vlrJoQIi0UsLacoHpGNGJGizH6k+ZPZFgKsqDGyWZAW7kPDFkAeAN4sL7XIyJz6jYaVkrKHcmo1GJ9dhBa/o8fV1w6S6mOG+5xq/sewri3REZ0dRcFUvedPKkxhSi0EVADVY9hEP/pJac+SFQV49Tl/c7JF8GmHODwsPq0NoqcqrrkoEEmTXKGb4LEECgYEA5z1d+vXSpZ+nbOikim10A+ukHOGw/mIdPtwnlsX//cM+j+yWgGIBGavEuys305KtLEcSurL39uKZJtM5ISnh0pHegra64YJuyTRQZM9mo/6BW6VQxgNJ4LAKlFaJGJaKcvVhEZHrcJrsRxn9QGqmM0UPtLMo7xHrDniX6bdzb2UCgYEAy52nzxLBxYnHeBNcXKkx7tLMPmwaKdCxLlV7qc43aSibeWfSaY1RX+tpZLblHrVdixS1sm4ba8uB++eC92ETLkY4Fv5gGg45QS8ZX51PK24NGen08a7SFOwQ+h5i6xLsjwcl8Hr+CBfDsahBW4mMigE4KuzsKqtLKCKdpbAEXPkCgYBE8ASelr6v5cLyMwEqy6q0qIGKorYzgGibnuKmjmzc6GI0YiIUMCOH1a+W5TGFf8rk0mOBCW3nSnLCImJ7wpKyRg6CBZv9Mvd4QIJfK328ElnaSpSkE8Lom1LsGkhQ7kBkOUcxB8GbFnSuVc8sbx8RVdty0Z64dy0OaWFQqgJeCQKBgAPq86ijVsEjRohD7xoFU2Wh/rYQxGwbjN00Xd3FjwFh+6PZYI4RXwh2ch+y+TOfD762Vkypm7N2Rfj/2mBCKOlSBpBCsrytm2JqspVJZJWUV4IxIzpnP7mRVT5KyWJ2icCyxYMcCrlDI8vOTfuh6Oda4KbKyjyD8T1DdT8T5PGZAoGAcJNauYMh4KfMCNqFxm+q2g6y+GfyK0P9khMU2hTXzLGsl8JRXzQIYJSK2DzjD2VJoQGs4B5T4vKPqsz6i82Yi9UMW87f70Gy+0s7gjO56moTpmIkE4SLFuJnnVe0p2VfNCthmr5sgM9DBsFRvKhnkvYiUMqabe7x3hSuvqyef7Q=
d4bef14e-e58c-41ce-ad3b-21652cd352ff	5353d886-a822-42ed-8890-a7a746ef493d	max-clients	200
8535310b-15fe-4695-89fd-2935984cdf01	d291742c-b69c-47cb-bb17-d51455d3f4ca	allow-default-scopes	true
8b351aa8-95a6-47d9-8e3f-4d853be8ec39	61332d25-2304-454b-bd65-b90fb7ff64ed	client-uris-must-match	true
a7c64010-ba99-4888-9a1d-e502e958ebb6	61332d25-2304-454b-bd65-b90fb7ff64ed	host-sending-registration-request-must-match	true
e3325442-3287-4daa-bafa-181e49243ef4	944d78d3-1058-4f5a-ada7-9459bff0ef8e	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
5a983a1f-b7d8-46b2-844d-5e335b357b9c	944d78d3-1058-4f5a-ada7-9459bff0ef8e	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
a234f9a9-b9ea-4129-a83e-a25e52977077	944d78d3-1058-4f5a-ada7-9459bff0ef8e	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
f30a126e-459d-4c51-a8d7-e6e0fc398e0d	944d78d3-1058-4f5a-ada7-9459bff0ef8e	allowed-protocol-mapper-types	saml-role-list-mapper
3ad4ed27-b458-435d-bd71-cd97dfc5472a	944d78d3-1058-4f5a-ada7-9459bff0ef8e	allowed-protocol-mapper-types	oidc-address-mapper
9096c88e-dfa8-4988-9989-502c29552b39	944d78d3-1058-4f5a-ada7-9459bff0ef8e	allowed-protocol-mapper-types	saml-user-property-mapper
4678451b-bd41-4a08-9d11-93bba8b5bd67	944d78d3-1058-4f5a-ada7-9459bff0ef8e	allowed-protocol-mapper-types	oidc-full-name-mapper
6ff5875d-c2d2-4127-aa26-d4675dacf465	944d78d3-1058-4f5a-ada7-9459bff0ef8e	allowed-protocol-mapper-types	saml-user-attribute-mapper
1a223d0e-1c4e-4d5e-83f6-f4b08c82fe0d	13c0b66a-6aa1-43e2-a885-ebdc1bd8f8de	allow-default-scopes	true
1caa251f-c387-48e8-969f-78385debc36b	20d22e64-d5a7-4c2c-83db-038f29e0eb3d	allowed-protocol-mapper-types	saml-user-property-mapper
e92046b3-1973-4f63-96e8-c79cb923e52e	20d22e64-d5a7-4c2c-83db-038f29e0eb3d	allowed-protocol-mapper-types	oidc-address-mapper
678d3a8a-abcc-4da4-85d3-eb8d94f9766b	20d22e64-d5a7-4c2c-83db-038f29e0eb3d	allowed-protocol-mapper-types	oidc-full-name-mapper
0ff2e01e-4e22-4f49-b334-9bd6e350d2f8	20d22e64-d5a7-4c2c-83db-038f29e0eb3d	allowed-protocol-mapper-types	saml-user-attribute-mapper
dbcdbd15-8e2d-4b84-87a3-92564e386f91	20d22e64-d5a7-4c2c-83db-038f29e0eb3d	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
0ea153c9-20b0-4aab-89f9-a5677690c6e5	20d22e64-d5a7-4c2c-83db-038f29e0eb3d	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
c9ef2341-3ed5-47da-bece-69f2881ec700	20d22e64-d5a7-4c2c-83db-038f29e0eb3d	allowed-protocol-mapper-types	saml-role-list-mapper
4a954479-1836-4705-b51c-a4e38f255dd3	20d22e64-d5a7-4c2c-83db-038f29e0eb3d	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.composite_role (composite, child_role) FROM stdin;
c0b118a6-f841-40cd-9920-959c8348c27d	6881929d-64c0-4085-a09e-b1b3c376d9bc
c0b118a6-f841-40cd-9920-959c8348c27d	0ff92e06-b425-4fa3-96f0-8acc35494939
c0b118a6-f841-40cd-9920-959c8348c27d	590094f6-cb75-4c76-92fe-21ccedd20e8c
c0b118a6-f841-40cd-9920-959c8348c27d	a46d8dd0-65ca-4507-b85d-0f2a65a79ece
c0b118a6-f841-40cd-9920-959c8348c27d	ea24d58b-940f-407e-95fb-a7bffacc1f3b
c0b118a6-f841-40cd-9920-959c8348c27d	05883aa6-d3f7-4e06-90ce-72c9f585c411
c0b118a6-f841-40cd-9920-959c8348c27d	ffa85f4a-b37f-469c-a6ce-089e31a96f86
c0b118a6-f841-40cd-9920-959c8348c27d	410d66a2-f54b-43e4-ac53-0473ca1e74cc
c0b118a6-f841-40cd-9920-959c8348c27d	950b58fd-6c03-425f-8a51-b9415e8e984b
c0b118a6-f841-40cd-9920-959c8348c27d	16398aa3-7dcc-4c3a-a7e5-75949d59b2ca
c0b118a6-f841-40cd-9920-959c8348c27d	bacb2d7c-45da-40c0-accc-0c719bba90a8
c0b118a6-f841-40cd-9920-959c8348c27d	d2f0ea13-1023-4efa-a0bf-94abf9cc4cb7
c0b118a6-f841-40cd-9920-959c8348c27d	9da24ab6-84e5-4893-9361-1a2fd8ae1c19
c0b118a6-f841-40cd-9920-959c8348c27d	d9ae64db-c329-4cdf-838a-2932f60af3d1
c0b118a6-f841-40cd-9920-959c8348c27d	d699412b-a94a-48c9-aade-d0f0b89ae8b9
c0b118a6-f841-40cd-9920-959c8348c27d	dbc8348c-9390-42b4-adbe-c98107611ab2
c0b118a6-f841-40cd-9920-959c8348c27d	8669f0a9-9919-4e90-b4c6-555a2a27e4f9
c0b118a6-f841-40cd-9920-959c8348c27d	3d548f53-6ea0-4e2e-a547-fb37e93e69e7
8778f523-44ba-407e-b916-448a8abb627e	0202805a-06a3-4e03-b07f-d5d86d2e5390
a46d8dd0-65ca-4507-b85d-0f2a65a79ece	3d548f53-6ea0-4e2e-a547-fb37e93e69e7
a46d8dd0-65ca-4507-b85d-0f2a65a79ece	d699412b-a94a-48c9-aade-d0f0b89ae8b9
ea24d58b-940f-407e-95fb-a7bffacc1f3b	dbc8348c-9390-42b4-adbe-c98107611ab2
8778f523-44ba-407e-b916-448a8abb627e	e3f7ac08-4d00-4d9b-b115-b90ffff14991
e3f7ac08-4d00-4d9b-b115-b90ffff14991	851ea4e3-e5ef-4bc2-9044-eb876d438c58
3f224db5-c4ee-44ea-ab80-acfbc226027a	b07f7afb-cbc5-467d-a04d-a47367b616da
c0b118a6-f841-40cd-9920-959c8348c27d	bdea0882-31e3-443a-b9ca-4d2a72823540
8778f523-44ba-407e-b916-448a8abb627e	cf66b3ec-736b-480a-981b-158ec7bdd59b
8778f523-44ba-407e-b916-448a8abb627e	c0203baf-a813-4225-9691-6dfa07aaaee0
c0b118a6-f841-40cd-9920-959c8348c27d	e356f341-a880-4ea5-96b7-1ba3c926643f
c0b118a6-f841-40cd-9920-959c8348c27d	35c032f5-2cfe-4433-b17d-434e861003c2
c0b118a6-f841-40cd-9920-959c8348c27d	e45ff466-9416-4e25-a5dc-be4898b4099b
c0b118a6-f841-40cd-9920-959c8348c27d	1d774291-905b-4da6-aa33-1763da175257
c0b118a6-f841-40cd-9920-959c8348c27d	44ddc149-c453-4d30-99c4-5ce22b8df60d
c0b118a6-f841-40cd-9920-959c8348c27d	d2f8056d-d455-4846-b9f1-2f7769527b5c
c0b118a6-f841-40cd-9920-959c8348c27d	6b244bae-7b4c-41d3-99da-8c38bcfda0f2
c0b118a6-f841-40cd-9920-959c8348c27d	28cf0a34-1b29-4411-bb3a-b5107fea8c5f
c0b118a6-f841-40cd-9920-959c8348c27d	1fd1e003-638e-473d-a159-41056146d380
c0b118a6-f841-40cd-9920-959c8348c27d	8f3cbc2b-6879-433d-8400-b877b7f824e2
c0b118a6-f841-40cd-9920-959c8348c27d	c81382a3-e67c-4993-beb4-b99ba98dc1ba
c0b118a6-f841-40cd-9920-959c8348c27d	f7e1e58d-57f4-4038-b8bc-e5a2f46b30e4
c0b118a6-f841-40cd-9920-959c8348c27d	b6d715db-cc52-4d8d-a591-4cdb99d6d825
c0b118a6-f841-40cd-9920-959c8348c27d	2271d4d6-726a-47de-b7a6-ec32784fa314
c0b118a6-f841-40cd-9920-959c8348c27d	c8e83a31-ccea-43c1-ae82-95600f2dd3dd
c0b118a6-f841-40cd-9920-959c8348c27d	671fe844-f528-4f3f-9dab-91ca564e7c20
c0b118a6-f841-40cd-9920-959c8348c27d	04d928b6-c6de-493a-a5ea-6810c3d4d89f
1d774291-905b-4da6-aa33-1763da175257	c8e83a31-ccea-43c1-ae82-95600f2dd3dd
e45ff466-9416-4e25-a5dc-be4898b4099b	04d928b6-c6de-493a-a5ea-6810c3d4d89f
e45ff466-9416-4e25-a5dc-be4898b4099b	2271d4d6-726a-47de-b7a6-ec32784fa314
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	1a06a98b-dc92-4de9-8b15-02eb2d690b02
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	d1aad90b-b89c-4cd4-aad4-acc238dff291
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	6efc5390-c27f-41ca-a9a6-24d08906a79d
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	bb424e12-eaff-4370-8c4d-4d66614b32f8
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	43740508-5dce-4be7-a440-b58385ee6328
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	2a694b04-af3d-4a57-a6f6-1d4e3c682377
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	2449c263-7fb6-437d-ae80-23ec869272ce
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	08541775-d27e-436a-9333-802bf6bc1030
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	dcdcf8d1-0c79-4c9e-b32d-96869c40f319
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	532c3885-8401-4137-8e3b-ea745d89f638
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	b8a5e1b2-912f-440c-aa09-00a785565957
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	f4947995-6f46-4cea-ada3-74dfb1ef1e8c
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	71f01cd3-cee7-45b8-92f5-cba47db71c46
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	8d5c3b0e-3df3-493d-beb0-c7c2a0d406fe
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	34abc210-d3e6-4ab0-9d9a-e27aebaeb7ce
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	7d482a68-46b2-49bd-84fd-2ce118c6426b
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	f61a4cc3-c1c3-4875-b45d-f9c8e3640ae6
6efc5390-c27f-41ca-a9a6-24d08906a79d	8d5c3b0e-3df3-493d-beb0-c7c2a0d406fe
6efc5390-c27f-41ca-a9a6-24d08906a79d	f61a4cc3-c1c3-4875-b45d-f9c8e3640ae6
bb424e12-eaff-4370-8c4d-4d66614b32f8	34abc210-d3e6-4ab0-9d9a-e27aebaeb7ce
e738529c-5b78-43dd-8148-0d414035c693	6314a3e1-b618-46f1-b6a7-864027f8eee0
e738529c-5b78-43dd-8148-0d414035c693	1a5ffc3c-a9e2-437e-9f60-f8560394d8f4
1a5ffc3c-a9e2-437e-9f60-f8560394d8f4	aa9d797d-bad3-4cce-b905-404db7a65422
10e34432-92db-489e-8519-080c0e01b3a8	806fa12a-6579-439f-b83b-06933c17bca4
c0b118a6-f841-40cd-9920-959c8348c27d	7f3cd843-eae8-482e-aacd-40ce8426d926
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	c0b94b8f-531c-43d4-883d-1bc840db95b5
e738529c-5b78-43dd-8148-0d414035c693	66f81d47-9dc0-4756-a025-8a91e19390dc
e738529c-5b78-43dd-8148-0d414035c693	5df2338a-217d-4510-923a-4072a6b3ab44
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
6e08c187-8a94-4c14-b054-f4dccf5c09ef	\N	password	91e0a27b-7d07-4dcb-b0bf-9bfcec0167cd	1775456788759	\N	{"value":"GRtbDbP6lxJWNy1f39kqqoH5OI1+aBZ8kGQK6R0WJmeUSLLWyEiim76pspAU0s32B/KVfCtPEeWLJcOr3T8VPA==","salt":"cDW0UbmJLN2kdIERhOYyLQ==","additionalParameters":{}}	{"hashIterations":210000,"algorithm":"pbkdf2-sha512","additionalParameters":{}}	10
582182b6-71d5-484f-aa16-761305da0013	\N	password	f74294d7-388f-4bfc-9c8a-d96805bbd208	1775456789161	\N	{"value":"17Bjh0dI4WyM6euNMSlHlAoU9J26RTn8IADZ7DzUEd3gCDR853nOAqcgffpE+oqrRd6pZbhJ97lMclTEX8ChuQ==","salt":"4//d6dsuh7rk8Wlc6A/XGA==","additionalParameters":{}}	{"hashIterations":210000,"algorithm":"pbkdf2-sha512","additionalParameters":{}}	10
bd7ca7ea-5e66-42a4-8200-d1f8f637b3d9	\N	password	673bec66-cfe8-4354-baa3-2a4bdcc1fe15	1775456790035	\N	{"value":"dHBizUZBlH2iyeH750Zh+zYgrbvvZ3DHJcBAro/jrFSV4zbo+/3jJehDS/g3+35ycyXALKOweyPXEt6f9Xj/eQ==","salt":"M0QlMNQkP84xmdh5oXm6cA==","additionalParameters":{}}	{"hashIterations":210000,"algorithm":"pbkdf2-sha512","additionalParameters":{}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2026-04-06 06:26:22.831367	1	EXECUTED	9:6f1016664e21e16d26517a4418f5e3df	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.25.1	\N	\N	5456782243
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2026-04-06 06:26:22.847592	2	MARK_RAN	9:828775b1596a07d1200ba1d49e5e3941	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.25.1	\N	\N	5456782243
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2026-04-06 06:26:22.908916	3	EXECUTED	9:5f090e44a7d595883c1fb61f4b41fd38	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.25.1	\N	\N	5456782243
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2026-04-06 06:26:22.912782	4	EXECUTED	9:c07e577387a3d2c04d1adc9aaad8730e	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.25.1	\N	\N	5456782243
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2026-04-06 06:26:23.057506	5	EXECUTED	9:b68ce996c655922dbcd2fe6b6ae72686	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.25.1	\N	\N	5456782243
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2026-04-06 06:26:23.063124	6	MARK_RAN	9:543b5c9989f024fe35c6f6c5a97de88e	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.25.1	\N	\N	5456782243
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2026-04-06 06:26:23.188443	7	EXECUTED	9:765afebbe21cf5bbca048e632df38336	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.25.1	\N	\N	5456782243
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2026-04-06 06:26:23.194046	8	MARK_RAN	9:db4a145ba11a6fdaefb397f6dbf829a1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.25.1	\N	\N	5456782243
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2026-04-06 06:26:23.199939	9	EXECUTED	9:9d05c7be10cdb873f8bcb41bc3a8ab23	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.25.1	\N	\N	5456782243
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2026-04-06 06:26:23.34079	10	EXECUTED	9:18593702353128d53111f9b1ff0b82b8	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.25.1	\N	\N	5456782243
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2026-04-06 06:26:23.406593	11	EXECUTED	9:6122efe5f090e41a85c0f1c9e52cbb62	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.25.1	\N	\N	5456782243
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2026-04-06 06:26:23.410144	12	MARK_RAN	9:e1ff28bf7568451453f844c5d54bb0b5	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.25.1	\N	\N	5456782243
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2026-04-06 06:26:23.438227	13	EXECUTED	9:7af32cd8957fbc069f796b61217483fd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.25.1	\N	\N	5456782243
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-04-06 06:26:23.46254	14	EXECUTED	9:6005e15e84714cd83226bf7879f54190	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.25.1	\N	\N	5456782243
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-04-06 06:26:23.463872	15	MARK_RAN	9:bf656f5a2b055d07f314431cae76f06c	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.25.1	\N	\N	5456782243
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-04-06 06:26:23.466141	16	MARK_RAN	9:f8dadc9284440469dcf71e25ca6ab99b	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.25.1	\N	\N	5456782243
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-04-06 06:26:23.468633	17	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.25.1	\N	\N	5456782243
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2026-04-06 06:26:23.535675	18	EXECUTED	9:3368ff0be4c2855ee2dd9ca813b38d8e	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.25.1	\N	\N	5456782243
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2026-04-06 06:26:23.595148	19	EXECUTED	9:8ac2fb5dd030b24c0570a763ed75ed20	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.25.1	\N	\N	5456782243
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2026-04-06 06:26:23.599536	20	EXECUTED	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.25.1	\N	\N	5456782243
24.0.0-9758-2	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-04-06 06:26:25.067841	119	EXECUTED	9:bf0fdee10afdf597a987adbf291db7b2	customChange		\N	4.25.1	\N	\N	5456782243
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2026-04-06 06:26:23.602015	21	MARK_RAN	9:831e82914316dc8a57dc09d755f23c51	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.25.1	\N	\N	5456782243
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2026-04-06 06:26:23.604345	22	MARK_RAN	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.25.1	\N	\N	5456782243
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2026-04-06 06:26:23.647266	23	EXECUTED	9:bc3d0f9e823a69dc21e23e94c7a94bb1	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.25.1	\N	\N	5456782243
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2026-04-06 06:26:23.653125	24	EXECUTED	9:c9999da42f543575ab790e76439a2679	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.25.1	\N	\N	5456782243
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2026-04-06 06:26:23.654617	25	MARK_RAN	9:0d6c65c6f58732d81569e77b10ba301d	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.25.1	\N	\N	5456782243
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2026-04-06 06:26:23.690322	26	EXECUTED	9:fc576660fc016ae53d2d4778d84d86d0	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.25.1	\N	\N	5456782243
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2026-04-06 06:26:23.785859	27	EXECUTED	9:43ed6b0da89ff77206289e87eaa9c024	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.25.1	\N	\N	5456782243
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2026-04-06 06:26:23.789422	28	EXECUTED	9:44bae577f551b3738740281eceb4ea70	update tableName=RESOURCE_SERVER_POLICY		\N	4.25.1	\N	\N	5456782243
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2026-04-06 06:26:23.867766	29	EXECUTED	9:bd88e1f833df0420b01e114533aee5e8	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.25.1	\N	\N	5456782243
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2026-04-06 06:26:23.885739	30	EXECUTED	9:a7022af5267f019d020edfe316ef4371	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.25.1	\N	\N	5456782243
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2026-04-06 06:26:23.912964	31	EXECUTED	9:fc155c394040654d6a79227e56f5e25a	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.25.1	\N	\N	5456782243
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2026-04-06 06:26:23.920297	32	EXECUTED	9:eac4ffb2a14795e5dc7b426063e54d88	customChange		\N	4.25.1	\N	\N	5456782243
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-04-06 06:26:23.928268	33	EXECUTED	9:54937c05672568c4c64fc9524c1e9462	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.25.1	\N	\N	5456782243
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-04-06 06:26:23.930085	34	MARK_RAN	9:3a32bace77c84d7678d035a7f5a8084e	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.25.1	\N	\N	5456782243
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-04-06 06:26:23.96575	35	EXECUTED	9:33d72168746f81f98ae3a1e8e0ca3554	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.25.1	\N	\N	5456782243
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2026-04-06 06:26:23.971438	36	EXECUTED	9:61b6d3d7a4c0e0024b0c839da283da0c	addColumn tableName=REALM		\N	4.25.1	\N	\N	5456782243
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-04-06 06:26:23.976764	37	EXECUTED	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.25.1	\N	\N	5456782243
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2026-04-06 06:26:23.980212	38	EXECUTED	9:a2b870802540cb3faa72098db5388af3	addColumn tableName=FED_USER_CONSENT		\N	4.25.1	\N	\N	5456782243
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2026-04-06 06:26:23.983626	39	EXECUTED	9:132a67499ba24bcc54fb5cbdcfe7e4c0	addColumn tableName=IDENTITY_PROVIDER		\N	4.25.1	\N	\N	5456782243
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-04-06 06:26:23.984838	40	MARK_RAN	9:938f894c032f5430f2b0fafb1a243462	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.25.1	\N	\N	5456782243
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-04-06 06:26:23.986577	41	MARK_RAN	9:845c332ff1874dc5d35974b0babf3006	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.25.1	\N	\N	5456782243
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2026-04-06 06:26:23.995211	42	EXECUTED	9:fc86359c079781adc577c5a217e4d04c	customChange		\N	4.25.1	\N	\N	5456782243
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-04-06 06:26:24.152432	43	EXECUTED	9:59a64800e3c0d09b825f8a3b444fa8f4	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.25.1	\N	\N	5456782243
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2026-04-06 06:26:24.1567	44	EXECUTED	9:d48d6da5c6ccf667807f633fe489ce88	addColumn tableName=USER_ENTITY		\N	4.25.1	\N	\N	5456782243
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-06 06:26:24.162529	45	EXECUTED	9:dde36f7973e80d71fceee683bc5d2951	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.25.1	\N	\N	5456782243
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-06 06:26:24.170341	46	EXECUTED	9:b855e9b0a406b34fa323235a0cf4f640	customChange		\N	4.25.1	\N	\N	5456782243
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-06 06:26:24.171936	47	MARK_RAN	9:51abbacd7b416c50c4421a8cabf7927e	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.25.1	\N	\N	5456782243
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-06 06:26:24.228206	48	EXECUTED	9:bdc99e567b3398bac83263d375aad143	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.25.1	\N	\N	5456782243
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-06 06:26:24.232204	49	EXECUTED	9:d198654156881c46bfba39abd7769e69	addColumn tableName=REALM		\N	4.25.1	\N	\N	5456782243
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2026-04-06 06:26:24.282231	50	EXECUTED	9:cfdd8736332ccdd72c5256ccb42335db	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.25.1	\N	\N	5456782243
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2026-04-06 06:26:24.318196	51	EXECUTED	9:7c84de3d9bd84d7f077607c1a4dcb714	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.25.1	\N	\N	5456782243
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2026-04-06 06:26:24.322472	52	EXECUTED	9:5a6bb36cbefb6a9d6928452c0852af2d	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2026-04-06 06:26:24.325215	53	EXECUTED	9:8f23e334dbc59f82e0a328373ca6ced0	update tableName=REALM		\N	4.25.1	\N	\N	5456782243
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2026-04-06 06:26:24.327892	54	EXECUTED	9:9156214268f09d970cdf0e1564d866af	update tableName=CLIENT		\N	4.25.1	\N	\N	5456782243
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-04-06 06:26:24.334939	55	EXECUTED	9:db806613b1ed154826c02610b7dbdf74	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.25.1	\N	\N	5456782243
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-04-06 06:26:24.348528	56	EXECUTED	9:229a041fb72d5beac76bb94a5fa709de	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.25.1	\N	\N	5456782243
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-04-06 06:26:24.373409	57	EXECUTED	9:079899dade9c1e683f26b2aa9ca6ff04	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.25.1	\N	\N	5456782243
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-04-06 06:26:24.527581	58	EXECUTED	9:139b79bcbbfe903bb1c2d2a4dbf001d9	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.25.1	\N	\N	5456782243
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2026-04-06 06:26:24.566846	59	EXECUTED	9:b55738ad889860c625ba2bf483495a04	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.25.1	\N	\N	5456782243
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2026-04-06 06:26:24.574946	60	EXECUTED	9:e0057eac39aa8fc8e09ac6cfa4ae15fe	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.25.1	\N	\N	5456782243
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2026-04-06 06:26:24.586866	61	EXECUTED	9:42a33806f3a0443fe0e7feeec821326c	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.25.1	\N	\N	5456782243
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2026-04-06 06:26:24.592171	62	EXECUTED	9:9968206fca46eecc1f51db9c024bfe56	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.25.1	\N	\N	5456782243
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2026-04-06 06:26:24.594863	63	EXECUTED	9:92143a6daea0a3f3b8f598c97ce55c3d	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.25.1	\N	\N	5456782243
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2026-04-06 06:26:24.597683	64	EXECUTED	9:82bab26a27195d889fb0429003b18f40	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.25.1	\N	\N	5456782243
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2026-04-06 06:26:24.600342	65	EXECUTED	9:e590c88ddc0b38b0ae4249bbfcb5abc3	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.25.1	\N	\N	5456782243
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2026-04-06 06:26:24.615128	66	EXECUTED	9:5c1f475536118dbdc38d5d7977950cc0	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.25.1	\N	\N	5456782243
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2026-04-06 06:26:24.629722	67	EXECUTED	9:e7c9f5f9c4d67ccbbcc215440c718a17	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.25.1	\N	\N	5456782243
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2026-04-06 06:26:24.635514	68	EXECUTED	9:88e0bfdda924690d6f4e430c53447dd5	addColumn tableName=REALM		\N	4.25.1	\N	\N	5456782243
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2026-04-06 06:26:24.649667	69	EXECUTED	9:f53177f137e1c46b6a88c59ec1cb5218	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.25.1	\N	\N	5456782243
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2026-04-06 06:26:24.654128	70	EXECUTED	9:a74d33da4dc42a37ec27121580d1459f	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.25.1	\N	\N	5456782243
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2026-04-06 06:26:24.657469	71	EXECUTED	9:fd4ade7b90c3b67fae0bfcfcb42dfb5f	addColumn tableName=RESOURCE_SERVER		\N	4.25.1	\N	\N	5456782243
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-06 06:26:24.664501	72	EXECUTED	9:aa072ad090bbba210d8f18781b8cebf4	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.25.1	\N	\N	5456782243
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-06 06:26:24.671643	73	EXECUTED	9:1ae6be29bab7c2aa376f6983b932be37	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.25.1	\N	\N	5456782243
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-06 06:26:24.67314	74	MARK_RAN	9:14706f286953fc9a25286dbd8fb30d97	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.25.1	\N	\N	5456782243
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-06 06:26:24.713721	75	EXECUTED	9:2b9cc12779be32c5b40e2e67711a218b	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.25.1	\N	\N	5456782243
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-06 06:26:24.721422	76	EXECUTED	9:91fa186ce7a5af127a2d7a91ee083cc5	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.25.1	\N	\N	5456782243
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-04-06 06:26:24.724994	77	EXECUTED	9:6335e5c94e83a2639ccd68dd24e2e5ad	addColumn tableName=CLIENT		\N	4.25.1	\N	\N	5456782243
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-04-06 06:26:24.726102	78	MARK_RAN	9:6bdb5658951e028bfe16fa0a8228b530	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.25.1	\N	\N	5456782243
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-04-06 06:26:24.764897	79	EXECUTED	9:d5bc15a64117ccad481ce8792d4c608f	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.25.1	\N	\N	5456782243
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-04-06 06:26:24.766693	80	MARK_RAN	9:077cba51999515f4d3e7ad5619ab592c	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.25.1	\N	\N	5456782243
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-06 06:26:24.773135	81	EXECUTED	9:be969f08a163bf47c6b9e9ead8ac2afb	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.25.1	\N	\N	5456782243
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-06 06:26:24.774353	82	MARK_RAN	9:6d3bb4408ba5a72f39bd8a0b301ec6e3	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.25.1	\N	\N	5456782243
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-06 06:26:24.778317	83	EXECUTED	9:966bda61e46bebf3cc39518fbed52fa7	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.25.1	\N	\N	5456782243
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-06 06:26:24.779272	84	MARK_RAN	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.25.1	\N	\N	5456782243
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-06 06:26:24.784685	85	EXECUTED	9:7d93d602352a30c0c317e6a609b56599	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.25.1	\N	\N	5456782243
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2026-04-06 06:26:24.792329	86	EXECUTED	9:71c5969e6cdd8d7b6f47cebc86d37627	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.25.1	\N	\N	5456782243
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2026-04-06 06:26:24.808679	87	EXECUTED	9:a9ba7d47f065f041b7da856a81762021	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.25.1	\N	\N	5456782243
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2026-04-06 06:26:24.8173	88	EXECUTED	9:fffabce2bc01e1a8f5110d5278500065	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.25.1	\N	\N	5456782243
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-06 06:26:24.825303	89	EXECUTED	9:fa8a5b5445e3857f4b010bafb5009957	addColumn tableName=REALM; customChange		\N	4.25.1	\N	\N	5456782243
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-06 06:26:24.839306	90	EXECUTED	9:67ac3241df9a8582d591c5ed87125f39	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.25.1	\N	\N	5456782243
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-06 06:26:24.844353	91	EXECUTED	9:ad1194d66c937e3ffc82386c050ba089	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.25.1	\N	\N	5456782243
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-06 06:26:24.86132	92	EXECUTED	9:d9be619d94af5a2f5d07b9f003543b91	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.25.1	\N	\N	5456782243
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-06 06:26:24.862404	93	MARK_RAN	9:544d201116a0fcc5a5da0925fbbc3bde	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.25.1	\N	\N	5456782243
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-06 06:26:24.875981	94	EXECUTED	9:43c0c1055b6761b4b3e89de76d612ccf	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.25.1	\N	\N	5456782243
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-06 06:26:24.877207	95	MARK_RAN	9:8bd711fd0330f4fe980494ca43ab1139	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.25.1	\N	\N	5456782243
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-06 06:26:24.884727	96	EXECUTED	9:e07d2bc0970c348bb06fb63b1f82ddbf	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.25.1	\N	\N	5456782243
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-06 06:26:24.896071	97	EXECUTED	9:24fb8611e97f29989bea412aa38d12b7	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.25.1	\N	\N	5456782243
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-06 06:26:24.897298	98	MARK_RAN	9:259f89014ce2506ee84740cbf7163aa7	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-06 06:26:24.911121	99	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-06 06:26:24.917749	100	EXECUTED	9:60ca84a0f8c94ec8c3504a5a3bc88ee8	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-06 06:26:24.919263	101	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-06 06:26:24.925177	102	EXECUTED	9:0b305d8d1277f3a89a0a53a659ad274c	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.25.1	\N	\N	5456782243
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-06 06:26:24.932602	103	EXECUTED	9:2c374ad2cdfe20e2905a84c8fac48460	customChange		\N	4.25.1	\N	\N	5456782243
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2026-04-06 06:26:24.93882	104	EXECUTED	9:47a760639ac597360a8219f5b768b4de	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.25.1	\N	\N	5456782243
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2026-04-06 06:26:24.943477	105	EXECUTED	9:a6272f0576727dd8cad2522335f5d99e	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.25.1	\N	\N	5456782243
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2026-04-06 06:26:24.947915	106	EXECUTED	9:015479dbd691d9cc8669282f4828c41d	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.25.1	\N	\N	5456782243
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2026-04-06 06:26:24.954754	107	EXECUTED	9:9518e495fdd22f78ad6425cc30630221	customChange		\N	4.25.1	\N	\N	5456782243
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-04-06 06:26:24.959955	108	EXECUTED	9:e5f243877199fd96bcc842f27a1656ac	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.25.1	\N	\N	5456782243
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-04-06 06:26:24.96109	109	MARK_RAN	9:1a6fcaa85e20bdeae0a9ce49b41946a5	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.25.1	\N	\N	5456782243
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-04-06 06:26:24.967929	110	EXECUTED	9:3f332e13e90739ed0c35b0b25b7822ca	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2026-04-06 06:26:24.974583	111	EXECUTED	9:7ee1f7a3fb8f5588f171fb9a6ab623c0	customChange		\N	4.25.1	\N	\N	5456782243
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2026-04-06 06:26:25.022206	112	EXECUTED	9:3d7e830b52f33676b9d64f7f2b2ea634	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.25.1	\N	\N	5456782243
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2026-04-06 06:26:25.024253	113	MARK_RAN	9:627d032e3ef2c06c0e1f73d2ae25c26c	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.25.1	\N	\N	5456782243
22.0.0-17484-updated	keycloak	META-INF/jpa-changelog-22.0.0.xml	2026-04-06 06:26:25.032187	114	EXECUTED	9:90af0bfd30cafc17b9f4d6eccd92b8b3	customChange		\N	4.25.1	\N	\N	5456782243
22.0.5-24031	keycloak	META-INF/jpa-changelog-22.0.0.xml	2026-04-06 06:26:25.033317	115	MARK_RAN	9:a60d2d7b315ec2d3eba9e2f145f9df28	customChange		\N	4.25.1	\N	\N	5456782243
23.0.0-12062	keycloak	META-INF/jpa-changelog-23.0.0.xml	2026-04-06 06:26:25.039638	116	EXECUTED	9:2168fbe728fec46ae9baf15bf80927b8	addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG		\N	4.25.1	\N	\N	5456782243
23.0.0-17258	keycloak	META-INF/jpa-changelog-23.0.0.xml	2026-04-06 06:26:25.04247	117	EXECUTED	9:36506d679a83bbfda85a27ea1864dca8	addColumn tableName=EVENT_ENTITY		\N	4.25.1	\N	\N	5456782243
24.0.0-9758	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-04-06 06:26:25.060827	118	EXECUTED	9:502c557a5189f600f0f445a9b49ebbce	addColumn tableName=USER_ATTRIBUTE; addColumn tableName=FED_USER_ATTRIBUTE; createIndex indexName=USER_ATTR_LONG_VALUES, tableName=USER_ATTRIBUTE; createIndex indexName=FED_USER_ATTR_LONG_VALUES, tableName=FED_USER_ATTRIBUTE; createIndex indexName...		\N	4.25.1	\N	\N	5456782243
24.0.0-26618-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-04-06 06:26:25.074986	120	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
24.0.0-26618-reindex	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-04-06 06:26:25.080913	121	EXECUTED	9:08707c0f0db1cef6b352db03a60edc7f	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
24.0.2-27228	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-04-06 06:26:25.087945	122	EXECUTED	9:eaee11f6b8aa25d2cc6a84fb86fc6238	customChange		\N	4.25.1	\N	\N	5456782243
24.0.2-27967-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-04-06 06:26:25.089129	123	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
24.0.2-27967-reindex	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-04-06 06:26:25.090826	124	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	5456782243
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
1001	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
64915411-5e90-4f94-9757-8cf984b78491	af2ec664-5f07-4770-8560-fa698c9c2249	f
64915411-5e90-4f94-9757-8cf984b78491	19c34380-1212-46df-ba82-dfa8f542208b	t
64915411-5e90-4f94-9757-8cf984b78491	2599e439-19bf-4393-8e00-b89b23175080	t
64915411-5e90-4f94-9757-8cf984b78491	5fc668a7-9705-41c4-9688-adc3a4e7e4a6	t
64915411-5e90-4f94-9757-8cf984b78491	7f861043-fc8d-41f7-aefa-2e8e30c29ca1	f
64915411-5e90-4f94-9757-8cf984b78491	91ce5feb-3e61-4039-984c-d4737e75c93b	f
64915411-5e90-4f94-9757-8cf984b78491	f7910512-88d0-4d20-871d-73c7f8ac788c	t
64915411-5e90-4f94-9757-8cf984b78491	68608df3-c419-4a14-8125-e224ce1c51d9	t
64915411-5e90-4f94-9757-8cf984b78491	f3c64caf-7fd4-4fba-b358-43acc35491d6	f
64915411-5e90-4f94-9757-8cf984b78491	3d873f68-1ffb-4473-a09e-89b5f92bb581	t
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0cdf50f8-c3c5-4da3-81dc-52d4d2331318	f
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	10885cd1-f981-4c42-ab82-63bbf6ecda32	t
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb	t
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6	t
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	444249d7-811e-4d75-a117-62fbd3f66701	f
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	d6f61ad8-c6d9-45d1-851b-9b42ca971970	f
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	90baaf31-30e9-4227-82d8-fa5aee3a15d5	t
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	9cef4577-9656-408d-911a-7ad0a5926b07	t
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	4885a6e1-9812-469a-b7f3-873a5d1250ce	f
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	85bdde81-aca1-4a54-bf17-b00dd68883c7	t
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id, details_json_long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keycloak_group (id, name, parent_group, realm_id) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
8778f523-44ba-407e-b916-448a8abb627e	64915411-5e90-4f94-9757-8cf984b78491	f	${role_default-roles}	default-roles-master	64915411-5e90-4f94-9757-8cf984b78491	\N	\N
6881929d-64c0-4085-a09e-b1b3c376d9bc	64915411-5e90-4f94-9757-8cf984b78491	f	${role_create-realm}	create-realm	64915411-5e90-4f94-9757-8cf984b78491	\N	\N
c0b118a6-f841-40cd-9920-959c8348c27d	64915411-5e90-4f94-9757-8cf984b78491	f	${role_admin}	admin	64915411-5e90-4f94-9757-8cf984b78491	\N	\N
0ff92e06-b425-4fa3-96f0-8acc35494939	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_create-client}	create-client	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
590094f6-cb75-4c76-92fe-21ccedd20e8c	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_view-realm}	view-realm	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
a46d8dd0-65ca-4507-b85d-0f2a65a79ece	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_view-users}	view-users	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
ea24d58b-940f-407e-95fb-a7bffacc1f3b	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_view-clients}	view-clients	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
05883aa6-d3f7-4e06-90ce-72c9f585c411	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_view-events}	view-events	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
ffa85f4a-b37f-469c-a6ce-089e31a96f86	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_view-identity-providers}	view-identity-providers	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
410d66a2-f54b-43e4-ac53-0473ca1e74cc	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_view-authorization}	view-authorization	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
950b58fd-6c03-425f-8a51-b9415e8e984b	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_manage-realm}	manage-realm	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
16398aa3-7dcc-4c3a-a7e5-75949d59b2ca	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_manage-users}	manage-users	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
bacb2d7c-45da-40c0-accc-0c719bba90a8	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_manage-clients}	manage-clients	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
d2f0ea13-1023-4efa-a0bf-94abf9cc4cb7	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_manage-events}	manage-events	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
9da24ab6-84e5-4893-9361-1a2fd8ae1c19	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_manage-identity-providers}	manage-identity-providers	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
d9ae64db-c329-4cdf-838a-2932f60af3d1	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_manage-authorization}	manage-authorization	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
d699412b-a94a-48c9-aade-d0f0b89ae8b9	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_query-users}	query-users	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
dbc8348c-9390-42b4-adbe-c98107611ab2	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_query-clients}	query-clients	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
8669f0a9-9919-4e90-b4c6-555a2a27e4f9	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_query-realms}	query-realms	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
3d548f53-6ea0-4e2e-a547-fb37e93e69e7	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_query-groups}	query-groups	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
0202805a-06a3-4e03-b07f-d5d86d2e5390	1654150e-ab4c-4dea-84d8-b28406d51365	t	${role_view-profile}	view-profile	64915411-5e90-4f94-9757-8cf984b78491	1654150e-ab4c-4dea-84d8-b28406d51365	\N
e3f7ac08-4d00-4d9b-b115-b90ffff14991	1654150e-ab4c-4dea-84d8-b28406d51365	t	${role_manage-account}	manage-account	64915411-5e90-4f94-9757-8cf984b78491	1654150e-ab4c-4dea-84d8-b28406d51365	\N
851ea4e3-e5ef-4bc2-9044-eb876d438c58	1654150e-ab4c-4dea-84d8-b28406d51365	t	${role_manage-account-links}	manage-account-links	64915411-5e90-4f94-9757-8cf984b78491	1654150e-ab4c-4dea-84d8-b28406d51365	\N
6e7bf454-0c29-4ebc-97b4-ce8378bbecb5	1654150e-ab4c-4dea-84d8-b28406d51365	t	${role_view-applications}	view-applications	64915411-5e90-4f94-9757-8cf984b78491	1654150e-ab4c-4dea-84d8-b28406d51365	\N
b07f7afb-cbc5-467d-a04d-a47367b616da	1654150e-ab4c-4dea-84d8-b28406d51365	t	${role_view-consent}	view-consent	64915411-5e90-4f94-9757-8cf984b78491	1654150e-ab4c-4dea-84d8-b28406d51365	\N
3f224db5-c4ee-44ea-ab80-acfbc226027a	1654150e-ab4c-4dea-84d8-b28406d51365	t	${role_manage-consent}	manage-consent	64915411-5e90-4f94-9757-8cf984b78491	1654150e-ab4c-4dea-84d8-b28406d51365	\N
fa171061-5ad1-4de4-968c-03565263a5b3	1654150e-ab4c-4dea-84d8-b28406d51365	t	${role_view-groups}	view-groups	64915411-5e90-4f94-9757-8cf984b78491	1654150e-ab4c-4dea-84d8-b28406d51365	\N
0655f9c8-f0e1-4bc8-a709-6c2f7729d4b3	1654150e-ab4c-4dea-84d8-b28406d51365	t	${role_delete-account}	delete-account	64915411-5e90-4f94-9757-8cf984b78491	1654150e-ab4c-4dea-84d8-b28406d51365	\N
f2797d1f-4f3d-46de-bdca-db9d7619fa4d	35f7f7cb-19b2-4585-b900-46943570c11b	t	${role_read-token}	read-token	64915411-5e90-4f94-9757-8cf984b78491	35f7f7cb-19b2-4585-b900-46943570c11b	\N
bdea0882-31e3-443a-b9ca-4d2a72823540	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	t	${role_impersonation}	impersonation	64915411-5e90-4f94-9757-8cf984b78491	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	\N
cf66b3ec-736b-480a-981b-158ec7bdd59b	64915411-5e90-4f94-9757-8cf984b78491	f	${role_offline-access}	offline_access	64915411-5e90-4f94-9757-8cf984b78491	\N	\N
c0203baf-a813-4225-9691-6dfa07aaaee0	64915411-5e90-4f94-9757-8cf984b78491	f	${role_uma_authorization}	uma_authorization	64915411-5e90-4f94-9757-8cf984b78491	\N	\N
e738529c-5b78-43dd-8148-0d414035c693	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f	${role_default-roles}	default-roles-attendance	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N	\N
e356f341-a880-4ea5-96b7-1ba3c926643f	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_create-client}	create-client	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
35c032f5-2cfe-4433-b17d-434e861003c2	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_view-realm}	view-realm	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
e45ff466-9416-4e25-a5dc-be4898b4099b	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_view-users}	view-users	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
1d774291-905b-4da6-aa33-1763da175257	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_view-clients}	view-clients	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
44ddc149-c453-4d30-99c4-5ce22b8df60d	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_view-events}	view-events	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
d2f8056d-d455-4846-b9f1-2f7769527b5c	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_view-identity-providers}	view-identity-providers	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
6b244bae-7b4c-41d3-99da-8c38bcfda0f2	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_view-authorization}	view-authorization	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
28cf0a34-1b29-4411-bb3a-b5107fea8c5f	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_manage-realm}	manage-realm	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
1fd1e003-638e-473d-a159-41056146d380	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_manage-users}	manage-users	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
8f3cbc2b-6879-433d-8400-b877b7f824e2	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_manage-clients}	manage-clients	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
c81382a3-e67c-4993-beb4-b99ba98dc1ba	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_manage-events}	manage-events	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
f7e1e58d-57f4-4038-b8bc-e5a2f46b30e4	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_manage-identity-providers}	manage-identity-providers	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
b6d715db-cc52-4d8d-a591-4cdb99d6d825	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_manage-authorization}	manage-authorization	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
2271d4d6-726a-47de-b7a6-ec32784fa314	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_query-users}	query-users	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
c8e83a31-ccea-43c1-ae82-95600f2dd3dd	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_query-clients}	query-clients	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
671fe844-f528-4f3f-9dab-91ca564e7c20	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_query-realms}	query-realms	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
04d928b6-c6de-493a-a5ea-6810c3d4d89f	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_query-groups}	query-groups	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
8a6f70ae-87ec-4a2b-91bc-0f112035bc3a	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_realm-admin}	realm-admin	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
1a06a98b-dc92-4de9-8b15-02eb2d690b02	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_create-client}	create-client	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
d1aad90b-b89c-4cd4-aad4-acc238dff291	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_view-realm}	view-realm	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
6efc5390-c27f-41ca-a9a6-24d08906a79d	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_view-users}	view-users	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
bb424e12-eaff-4370-8c4d-4d66614b32f8	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_view-clients}	view-clients	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
43740508-5dce-4be7-a440-b58385ee6328	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_view-events}	view-events	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
2a694b04-af3d-4a57-a6f6-1d4e3c682377	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_view-identity-providers}	view-identity-providers	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
2449c263-7fb6-437d-ae80-23ec869272ce	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_view-authorization}	view-authorization	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
08541775-d27e-436a-9333-802bf6bc1030	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_manage-realm}	manage-realm	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
dcdcf8d1-0c79-4c9e-b32d-96869c40f319	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_manage-users}	manage-users	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
532c3885-8401-4137-8e3b-ea745d89f638	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_manage-clients}	manage-clients	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
b8a5e1b2-912f-440c-aa09-00a785565957	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_manage-events}	manage-events	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
f4947995-6f46-4cea-ada3-74dfb1ef1e8c	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_manage-identity-providers}	manage-identity-providers	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
71f01cd3-cee7-45b8-92f5-cba47db71c46	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_manage-authorization}	manage-authorization	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
8d5c3b0e-3df3-493d-beb0-c7c2a0d406fe	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_query-users}	query-users	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
34abc210-d3e6-4ab0-9d9a-e27aebaeb7ce	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_query-clients}	query-clients	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
7d482a68-46b2-49bd-84fd-2ce118c6426b	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_query-realms}	query-realms	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
f61a4cc3-c1c3-4875-b45d-f9c8e3640ae6	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_query-groups}	query-groups	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
6314a3e1-b618-46f1-b6a7-864027f8eee0	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	t	${role_view-profile}	view-profile	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	\N
1a5ffc3c-a9e2-437e-9f60-f8560394d8f4	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	t	${role_manage-account}	manage-account	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	\N
aa9d797d-bad3-4cce-b905-404db7a65422	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	t	${role_manage-account-links}	manage-account-links	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	\N
fe412ab1-d646-488a-964d-a7285c44d0cb	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	t	${role_view-applications}	view-applications	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	\N
806fa12a-6579-439f-b83b-06933c17bca4	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	t	${role_view-consent}	view-consent	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	\N
10e34432-92db-489e-8519-080c0e01b3a8	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	t	${role_manage-consent}	manage-consent	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	\N
35429dfb-284e-4581-88c4-f8b72fc7f9dd	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	t	${role_view-groups}	view-groups	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	\N
4f07e1b0-e89a-46b4-b8a6-627d5237e3d0	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	t	${role_delete-account}	delete-account	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	\N
7f3cd843-eae8-482e-aacd-40ce8426d926	8d0b8899-7f49-405a-9006-ad43b706ce5e	t	${role_impersonation}	impersonation	64915411-5e90-4f94-9757-8cf984b78491	8d0b8899-7f49-405a-9006-ad43b706ce5e	\N
c0b94b8f-531c-43d4-883d-1bc840db95b5	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	t	${role_impersonation}	impersonation	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	6f11da95-19da-4e4c-a4b4-4b02a5f34cbb	\N
8765af00-ab0b-49a9-8ee6-ddea412b53d3	eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	t	${role_read-token}	read-token	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	eef3bf37-8ec7-4ce6-8a95-25ab8a1780a1	\N
66f81d47-9dc0-4756-a025-8a91e19390dc	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f	${role_offline-access}	offline_access	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N	\N
e3485049-b90d-4b1f-838a-cfb5b4adba11	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f	System administrator	admin	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N	\N
c291c886-754c-4ddc-b561-ac36f87372ce	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f	HR manager	hr	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N	\N
0179b604-9bdf-4e7b-9b11-230a110f8c32	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f	Read-only access	viewer	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N	\N
5df2338a-217d-4510-923a-4072a6b3ab44	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f	${role_uma_authorization}	uma_authorization	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	\N	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migration_model (id, version, update_time) FROM stdin;
29qud	24.0.2	1775456785
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
bd4f65f9-964b-47c5-be88-147930580966	audience resolve	openid-connect	oidc-audience-resolve-mapper	f4b24e22-286b-4d5d-8546-a6c6562f24d4	\N
c65bdb6d-375d-4017-bcab-c24c71941c69	locale	openid-connect	oidc-usermodel-attribute-mapper	0a734152-c8df-44f7-b13f-f1b1a1658688	\N
f8acbcdc-28a8-4495-89d9-6837716009c8	role list	saml	saml-role-list-mapper	\N	19c34380-1212-46df-ba82-dfa8f542208b
9b0becbe-66e6-4d70-84a7-c435fc4e8da4	full name	openid-connect	oidc-full-name-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
fc04ce7b-20bf-424d-b04c-9b60c992733e	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
1a6aabb3-3aa0-46a5-b0c3-585b6cedd1b4	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
af0be52a-1c5e-4348-b1ce-bed782506467	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
ac6a5ba7-95bd-4976-b5ec-a4ed875416e9	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
28f3ae1b-59da-4f7d-8c0c-e175e9378a58	username	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
767664c5-a150-486a-bd36-31d6a8168e47	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
fac42b0f-b44b-4a5b-a898-3600e0016e42	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
08a3157e-008d-4276-a5d7-93f021f95772	website	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
197006ef-0729-4c63-ad64-9218b633b06d	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
fb2deb9d-e5e5-4a1c-b40e-2bf7ba0a8e82	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
bedd89f5-17ac-4b5d-9457-7dacdbd25c1f	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
b04437a9-6f9f-467e-884f-575b6db37765	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
48c0d07b-291d-42e5-8689-ae2dbd435d7c	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	2599e439-19bf-4393-8e00-b89b23175080
0f8805e9-9ff1-4a30-90a8-95e0d02ecc19	email	openid-connect	oidc-usermodel-attribute-mapper	\N	5fc668a7-9705-41c4-9688-adc3a4e7e4a6
1ab0ef34-5d90-4e77-a39e-0faa677574ba	email verified	openid-connect	oidc-usermodel-property-mapper	\N	5fc668a7-9705-41c4-9688-adc3a4e7e4a6
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	address	openid-connect	oidc-address-mapper	\N	7f861043-fc8d-41f7-aefa-2e8e30c29ca1
24127fcd-cc21-4aed-b8e7-dd60ed8216b7	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	91ce5feb-3e61-4039-984c-d4737e75c93b
ce223180-3c77-46e3-891e-e21b759921d6	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	91ce5feb-3e61-4039-984c-d4737e75c93b
7308f2ed-419f-4020-bc77-a8166e5a130b	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	f7910512-88d0-4d20-871d-73c7f8ac788c
043597a6-4d9d-4d6f-b65f-5c8c2e327e6a	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	f7910512-88d0-4d20-871d-73c7f8ac788c
b7a911bf-18f8-40d0-b87b-388e8ab90837	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	f7910512-88d0-4d20-871d-73c7f8ac788c
5fea8b39-b020-4399-ba98-36060f32395e	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	68608df3-c419-4a14-8125-e224ce1c51d9
dcf2ce4c-b0ff-4f32-ba11-b031fb893d9d	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	f3c64caf-7fd4-4fba-b358-43acc35491d6
7222a367-036e-43f5-b116-d1969dfe7b87	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	f3c64caf-7fd4-4fba-b358-43acc35491d6
8695adda-a857-4476-ba79-75f68a195b04	acr loa level	openid-connect	oidc-acr-mapper	\N	3d873f68-1ffb-4473-a09e-89b5f92bb581
bd591bbe-5d10-4384-8913-6a6d9fe7b329	audience resolve	openid-connect	oidc-audience-resolve-mapper	1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	\N
d01892f6-1353-477b-87bb-cbc89a64eaab	role list	saml	saml-role-list-mapper	\N	10885cd1-f981-4c42-ab82-63bbf6ecda32
c3fa3be2-9d4b-4e3f-84c2-b6bcf2786995	full name	openid-connect	oidc-full-name-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
e1fb103c-6c6b-4605-9254-7fc2fbc4e667	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
cbd9816f-5720-41eb-82aa-4d9bc4eae26f	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
014b902b-bd71-475f-bee5-38858eeff349	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
b7d797aa-d0b0-458e-b5e1-c2db6436dbe0	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
8421a8a3-4e81-4f1f-a0c5-33d6f78175da	username	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
5f1e4925-2593-4da5-af14-e8e1b2a508a4	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
88c6df4d-4484-4e6d-ab42-260b58bf1fa7	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
46777601-77d4-48ef-8ce6-16be641ca22a	website	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
db5656c4-6ee9-4d99-838e-7c7d5e66e8e4	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
335c4232-e09b-4b9c-8c00-cf0ff7fb9ce1	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
ea2a57c3-3751-4c8e-8656-5ab3174b1e95	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
7fb659eb-8c43-452c-ae84-a647a23f4a61	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
d234506f-1aa0-4d0b-85b0-3aa303fc4a31	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	f5ab35cf-4b4a-4a87-996e-8a22d6918ffb
b9998f16-e98e-4844-b526-2aa7a5b64d8e	email	openid-connect	oidc-usermodel-attribute-mapper	\N	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6
1fc611ea-c51e-4253-abdd-21cae10bfa4d	email verified	openid-connect	oidc-usermodel-property-mapper	\N	c094a9f1-ea0a-46dd-8c7c-39e2a21e27b6
485606a5-fb47-487f-ade8-e288963ffcd7	address	openid-connect	oidc-address-mapper	\N	444249d7-811e-4d75-a117-62fbd3f66701
0faf431f-dee3-4617-99e2-0a9f86d80c0b	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	d6f61ad8-c6d9-45d1-851b-9b42ca971970
ff0f3a5b-71c3-47c3-9df0-15d993dcc14a	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	d6f61ad8-c6d9-45d1-851b-9b42ca971970
eb25206a-78d3-4f76-8fde-bed3b2ea2b21	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	90baaf31-30e9-4227-82d8-fa5aee3a15d5
37d506c4-e321-40f0-9172-274f19ae51f7	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	90baaf31-30e9-4227-82d8-fa5aee3a15d5
08e4f73f-9303-4d54-b499-dd8c373593fc	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	90baaf31-30e9-4227-82d8-fa5aee3a15d5
0843e4e9-a2be-4297-8781-dd6cabacb6e1	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	9cef4577-9656-408d-911a-7ad0a5926b07
0ddb02d0-145b-4c2e-9941-cae02f775fdb	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	4885a6e1-9812-469a-b7f3-873a5d1250ce
5ff51eeb-fd26-4bf7-873f-b094814afa08	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	4885a6e1-9812-469a-b7f3-873a5d1250ce
f938e3ea-33e4-4426-8d9f-e4c072108650	acr loa level	openid-connect	oidc-acr-mapper	\N	85bdde81-aca1-4a54-bf17-b00dd68883c7
ae0e9a75-bc19-484b-82b0-b727083853c1	audience-mapper	openid-connect	oidc-audience-mapper	05de3fa6-f271-4655-97ed-d8f344c7dcdb	\N
30355fe9-9bfd-4afa-84ce-101e1cfdbde7	realm-roles-mapper	openid-connect	oidc-usermodel-realm-role-mapper	05de3fa6-f271-4655-97ed-d8f344c7dcdb	\N
f01cce3e-6250-4b33-a0d8-17985680f116	email-mapper	openid-connect	oidc-usermodel-property-mapper	05de3fa6-f271-4655-97ed-d8f344c7dcdb	\N
f1649e5a-26e9-4a42-97fe-38c67c101956	full-name-mapper	openid-connect	oidc-full-name-mapper	05de3fa6-f271-4655-97ed-d8f344c7dcdb	\N
5a34ff4c-2459-4eb7-9e9f-5a8535169413	locale	openid-connect	oidc-usermodel-attribute-mapper	daf50007-c534-4574-8205-2d83e93e5d0b	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
c65bdb6d-375d-4017-bcab-c24c71941c69	true	introspection.token.claim
c65bdb6d-375d-4017-bcab-c24c71941c69	true	userinfo.token.claim
c65bdb6d-375d-4017-bcab-c24c71941c69	locale	user.attribute
c65bdb6d-375d-4017-bcab-c24c71941c69	true	id.token.claim
c65bdb6d-375d-4017-bcab-c24c71941c69	true	access.token.claim
c65bdb6d-375d-4017-bcab-c24c71941c69	locale	claim.name
c65bdb6d-375d-4017-bcab-c24c71941c69	String	jsonType.label
f8acbcdc-28a8-4495-89d9-6837716009c8	false	single
f8acbcdc-28a8-4495-89d9-6837716009c8	Basic	attribute.nameformat
f8acbcdc-28a8-4495-89d9-6837716009c8	Role	attribute.name
08a3157e-008d-4276-a5d7-93f021f95772	true	introspection.token.claim
08a3157e-008d-4276-a5d7-93f021f95772	true	userinfo.token.claim
08a3157e-008d-4276-a5d7-93f021f95772	website	user.attribute
08a3157e-008d-4276-a5d7-93f021f95772	true	id.token.claim
08a3157e-008d-4276-a5d7-93f021f95772	true	access.token.claim
08a3157e-008d-4276-a5d7-93f021f95772	website	claim.name
08a3157e-008d-4276-a5d7-93f021f95772	String	jsonType.label
197006ef-0729-4c63-ad64-9218b633b06d	true	introspection.token.claim
197006ef-0729-4c63-ad64-9218b633b06d	true	userinfo.token.claim
197006ef-0729-4c63-ad64-9218b633b06d	gender	user.attribute
197006ef-0729-4c63-ad64-9218b633b06d	true	id.token.claim
197006ef-0729-4c63-ad64-9218b633b06d	true	access.token.claim
197006ef-0729-4c63-ad64-9218b633b06d	gender	claim.name
197006ef-0729-4c63-ad64-9218b633b06d	String	jsonType.label
1a6aabb3-3aa0-46a5-b0c3-585b6cedd1b4	true	introspection.token.claim
1a6aabb3-3aa0-46a5-b0c3-585b6cedd1b4	true	userinfo.token.claim
1a6aabb3-3aa0-46a5-b0c3-585b6cedd1b4	firstName	user.attribute
1a6aabb3-3aa0-46a5-b0c3-585b6cedd1b4	true	id.token.claim
1a6aabb3-3aa0-46a5-b0c3-585b6cedd1b4	true	access.token.claim
1a6aabb3-3aa0-46a5-b0c3-585b6cedd1b4	given_name	claim.name
1a6aabb3-3aa0-46a5-b0c3-585b6cedd1b4	String	jsonType.label
28f3ae1b-59da-4f7d-8c0c-e175e9378a58	true	introspection.token.claim
28f3ae1b-59da-4f7d-8c0c-e175e9378a58	true	userinfo.token.claim
28f3ae1b-59da-4f7d-8c0c-e175e9378a58	username	user.attribute
28f3ae1b-59da-4f7d-8c0c-e175e9378a58	true	id.token.claim
28f3ae1b-59da-4f7d-8c0c-e175e9378a58	true	access.token.claim
28f3ae1b-59da-4f7d-8c0c-e175e9378a58	preferred_username	claim.name
28f3ae1b-59da-4f7d-8c0c-e175e9378a58	String	jsonType.label
48c0d07b-291d-42e5-8689-ae2dbd435d7c	true	introspection.token.claim
48c0d07b-291d-42e5-8689-ae2dbd435d7c	true	userinfo.token.claim
48c0d07b-291d-42e5-8689-ae2dbd435d7c	updatedAt	user.attribute
48c0d07b-291d-42e5-8689-ae2dbd435d7c	true	id.token.claim
48c0d07b-291d-42e5-8689-ae2dbd435d7c	true	access.token.claim
48c0d07b-291d-42e5-8689-ae2dbd435d7c	updated_at	claim.name
48c0d07b-291d-42e5-8689-ae2dbd435d7c	long	jsonType.label
767664c5-a150-486a-bd36-31d6a8168e47	true	introspection.token.claim
767664c5-a150-486a-bd36-31d6a8168e47	true	userinfo.token.claim
767664c5-a150-486a-bd36-31d6a8168e47	profile	user.attribute
767664c5-a150-486a-bd36-31d6a8168e47	true	id.token.claim
767664c5-a150-486a-bd36-31d6a8168e47	true	access.token.claim
767664c5-a150-486a-bd36-31d6a8168e47	profile	claim.name
767664c5-a150-486a-bd36-31d6a8168e47	String	jsonType.label
9b0becbe-66e6-4d70-84a7-c435fc4e8da4	true	introspection.token.claim
9b0becbe-66e6-4d70-84a7-c435fc4e8da4	true	userinfo.token.claim
9b0becbe-66e6-4d70-84a7-c435fc4e8da4	true	id.token.claim
9b0becbe-66e6-4d70-84a7-c435fc4e8da4	true	access.token.claim
ac6a5ba7-95bd-4976-b5ec-a4ed875416e9	true	introspection.token.claim
ac6a5ba7-95bd-4976-b5ec-a4ed875416e9	true	userinfo.token.claim
ac6a5ba7-95bd-4976-b5ec-a4ed875416e9	nickname	user.attribute
ac6a5ba7-95bd-4976-b5ec-a4ed875416e9	true	id.token.claim
ac6a5ba7-95bd-4976-b5ec-a4ed875416e9	true	access.token.claim
ac6a5ba7-95bd-4976-b5ec-a4ed875416e9	nickname	claim.name
ac6a5ba7-95bd-4976-b5ec-a4ed875416e9	String	jsonType.label
af0be52a-1c5e-4348-b1ce-bed782506467	true	introspection.token.claim
af0be52a-1c5e-4348-b1ce-bed782506467	true	userinfo.token.claim
af0be52a-1c5e-4348-b1ce-bed782506467	middleName	user.attribute
af0be52a-1c5e-4348-b1ce-bed782506467	true	id.token.claim
af0be52a-1c5e-4348-b1ce-bed782506467	true	access.token.claim
af0be52a-1c5e-4348-b1ce-bed782506467	middle_name	claim.name
af0be52a-1c5e-4348-b1ce-bed782506467	String	jsonType.label
b04437a9-6f9f-467e-884f-575b6db37765	true	introspection.token.claim
b04437a9-6f9f-467e-884f-575b6db37765	true	userinfo.token.claim
b04437a9-6f9f-467e-884f-575b6db37765	locale	user.attribute
b04437a9-6f9f-467e-884f-575b6db37765	true	id.token.claim
b04437a9-6f9f-467e-884f-575b6db37765	true	access.token.claim
b04437a9-6f9f-467e-884f-575b6db37765	locale	claim.name
b04437a9-6f9f-467e-884f-575b6db37765	String	jsonType.label
bedd89f5-17ac-4b5d-9457-7dacdbd25c1f	true	introspection.token.claim
bedd89f5-17ac-4b5d-9457-7dacdbd25c1f	true	userinfo.token.claim
bedd89f5-17ac-4b5d-9457-7dacdbd25c1f	zoneinfo	user.attribute
bedd89f5-17ac-4b5d-9457-7dacdbd25c1f	true	id.token.claim
bedd89f5-17ac-4b5d-9457-7dacdbd25c1f	true	access.token.claim
bedd89f5-17ac-4b5d-9457-7dacdbd25c1f	zoneinfo	claim.name
bedd89f5-17ac-4b5d-9457-7dacdbd25c1f	String	jsonType.label
fac42b0f-b44b-4a5b-a898-3600e0016e42	true	introspection.token.claim
fac42b0f-b44b-4a5b-a898-3600e0016e42	true	userinfo.token.claim
fac42b0f-b44b-4a5b-a898-3600e0016e42	picture	user.attribute
fac42b0f-b44b-4a5b-a898-3600e0016e42	true	id.token.claim
fac42b0f-b44b-4a5b-a898-3600e0016e42	true	access.token.claim
fac42b0f-b44b-4a5b-a898-3600e0016e42	picture	claim.name
fac42b0f-b44b-4a5b-a898-3600e0016e42	String	jsonType.label
fb2deb9d-e5e5-4a1c-b40e-2bf7ba0a8e82	true	introspection.token.claim
fb2deb9d-e5e5-4a1c-b40e-2bf7ba0a8e82	true	userinfo.token.claim
fb2deb9d-e5e5-4a1c-b40e-2bf7ba0a8e82	birthdate	user.attribute
fb2deb9d-e5e5-4a1c-b40e-2bf7ba0a8e82	true	id.token.claim
fb2deb9d-e5e5-4a1c-b40e-2bf7ba0a8e82	true	access.token.claim
fb2deb9d-e5e5-4a1c-b40e-2bf7ba0a8e82	birthdate	claim.name
fb2deb9d-e5e5-4a1c-b40e-2bf7ba0a8e82	String	jsonType.label
fc04ce7b-20bf-424d-b04c-9b60c992733e	true	introspection.token.claim
fc04ce7b-20bf-424d-b04c-9b60c992733e	true	userinfo.token.claim
fc04ce7b-20bf-424d-b04c-9b60c992733e	lastName	user.attribute
fc04ce7b-20bf-424d-b04c-9b60c992733e	true	id.token.claim
fc04ce7b-20bf-424d-b04c-9b60c992733e	true	access.token.claim
fc04ce7b-20bf-424d-b04c-9b60c992733e	family_name	claim.name
fc04ce7b-20bf-424d-b04c-9b60c992733e	String	jsonType.label
0f8805e9-9ff1-4a30-90a8-95e0d02ecc19	true	introspection.token.claim
0f8805e9-9ff1-4a30-90a8-95e0d02ecc19	true	userinfo.token.claim
0f8805e9-9ff1-4a30-90a8-95e0d02ecc19	email	user.attribute
0f8805e9-9ff1-4a30-90a8-95e0d02ecc19	true	id.token.claim
0f8805e9-9ff1-4a30-90a8-95e0d02ecc19	true	access.token.claim
0f8805e9-9ff1-4a30-90a8-95e0d02ecc19	email	claim.name
0f8805e9-9ff1-4a30-90a8-95e0d02ecc19	String	jsonType.label
1ab0ef34-5d90-4e77-a39e-0faa677574ba	true	introspection.token.claim
1ab0ef34-5d90-4e77-a39e-0faa677574ba	true	userinfo.token.claim
1ab0ef34-5d90-4e77-a39e-0faa677574ba	emailVerified	user.attribute
1ab0ef34-5d90-4e77-a39e-0faa677574ba	true	id.token.claim
1ab0ef34-5d90-4e77-a39e-0faa677574ba	true	access.token.claim
1ab0ef34-5d90-4e77-a39e-0faa677574ba	email_verified	claim.name
1ab0ef34-5d90-4e77-a39e-0faa677574ba	boolean	jsonType.label
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	formatted	user.attribute.formatted
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	country	user.attribute.country
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	true	introspection.token.claim
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	postal_code	user.attribute.postal_code
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	true	userinfo.token.claim
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	street	user.attribute.street
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	true	id.token.claim
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	region	user.attribute.region
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	true	access.token.claim
f5af6d37-a862-4f6b-ba9e-bc7647aec44b	locality	user.attribute.locality
24127fcd-cc21-4aed-b8e7-dd60ed8216b7	true	introspection.token.claim
24127fcd-cc21-4aed-b8e7-dd60ed8216b7	true	userinfo.token.claim
24127fcd-cc21-4aed-b8e7-dd60ed8216b7	phoneNumber	user.attribute
24127fcd-cc21-4aed-b8e7-dd60ed8216b7	true	id.token.claim
24127fcd-cc21-4aed-b8e7-dd60ed8216b7	true	access.token.claim
24127fcd-cc21-4aed-b8e7-dd60ed8216b7	phone_number	claim.name
24127fcd-cc21-4aed-b8e7-dd60ed8216b7	String	jsonType.label
ce223180-3c77-46e3-891e-e21b759921d6	true	introspection.token.claim
ce223180-3c77-46e3-891e-e21b759921d6	true	userinfo.token.claim
ce223180-3c77-46e3-891e-e21b759921d6	phoneNumberVerified	user.attribute
ce223180-3c77-46e3-891e-e21b759921d6	true	id.token.claim
ce223180-3c77-46e3-891e-e21b759921d6	true	access.token.claim
ce223180-3c77-46e3-891e-e21b759921d6	phone_number_verified	claim.name
ce223180-3c77-46e3-891e-e21b759921d6	boolean	jsonType.label
043597a6-4d9d-4d6f-b65f-5c8c2e327e6a	true	introspection.token.claim
043597a6-4d9d-4d6f-b65f-5c8c2e327e6a	true	multivalued
043597a6-4d9d-4d6f-b65f-5c8c2e327e6a	foo	user.attribute
043597a6-4d9d-4d6f-b65f-5c8c2e327e6a	true	access.token.claim
043597a6-4d9d-4d6f-b65f-5c8c2e327e6a	resource_access.${client_id}.roles	claim.name
043597a6-4d9d-4d6f-b65f-5c8c2e327e6a	String	jsonType.label
7308f2ed-419f-4020-bc77-a8166e5a130b	true	introspection.token.claim
7308f2ed-419f-4020-bc77-a8166e5a130b	true	multivalued
7308f2ed-419f-4020-bc77-a8166e5a130b	foo	user.attribute
7308f2ed-419f-4020-bc77-a8166e5a130b	true	access.token.claim
7308f2ed-419f-4020-bc77-a8166e5a130b	realm_access.roles	claim.name
7308f2ed-419f-4020-bc77-a8166e5a130b	String	jsonType.label
b7a911bf-18f8-40d0-b87b-388e8ab90837	true	introspection.token.claim
b7a911bf-18f8-40d0-b87b-388e8ab90837	true	access.token.claim
5fea8b39-b020-4399-ba98-36060f32395e	true	introspection.token.claim
5fea8b39-b020-4399-ba98-36060f32395e	true	access.token.claim
7222a367-036e-43f5-b116-d1969dfe7b87	true	introspection.token.claim
7222a367-036e-43f5-b116-d1969dfe7b87	true	multivalued
7222a367-036e-43f5-b116-d1969dfe7b87	foo	user.attribute
7222a367-036e-43f5-b116-d1969dfe7b87	true	id.token.claim
7222a367-036e-43f5-b116-d1969dfe7b87	true	access.token.claim
7222a367-036e-43f5-b116-d1969dfe7b87	groups	claim.name
7222a367-036e-43f5-b116-d1969dfe7b87	String	jsonType.label
dcf2ce4c-b0ff-4f32-ba11-b031fb893d9d	true	introspection.token.claim
dcf2ce4c-b0ff-4f32-ba11-b031fb893d9d	true	userinfo.token.claim
dcf2ce4c-b0ff-4f32-ba11-b031fb893d9d	username	user.attribute
dcf2ce4c-b0ff-4f32-ba11-b031fb893d9d	true	id.token.claim
dcf2ce4c-b0ff-4f32-ba11-b031fb893d9d	true	access.token.claim
dcf2ce4c-b0ff-4f32-ba11-b031fb893d9d	upn	claim.name
dcf2ce4c-b0ff-4f32-ba11-b031fb893d9d	String	jsonType.label
8695adda-a857-4476-ba79-75f68a195b04	true	introspection.token.claim
8695adda-a857-4476-ba79-75f68a195b04	true	id.token.claim
8695adda-a857-4476-ba79-75f68a195b04	true	access.token.claim
d01892f6-1353-477b-87bb-cbc89a64eaab	false	single
d01892f6-1353-477b-87bb-cbc89a64eaab	Basic	attribute.nameformat
d01892f6-1353-477b-87bb-cbc89a64eaab	Role	attribute.name
014b902b-bd71-475f-bee5-38858eeff349	true	introspection.token.claim
014b902b-bd71-475f-bee5-38858eeff349	true	userinfo.token.claim
014b902b-bd71-475f-bee5-38858eeff349	middleName	user.attribute
014b902b-bd71-475f-bee5-38858eeff349	true	id.token.claim
014b902b-bd71-475f-bee5-38858eeff349	true	access.token.claim
014b902b-bd71-475f-bee5-38858eeff349	middle_name	claim.name
014b902b-bd71-475f-bee5-38858eeff349	String	jsonType.label
335c4232-e09b-4b9c-8c00-cf0ff7fb9ce1	true	introspection.token.claim
335c4232-e09b-4b9c-8c00-cf0ff7fb9ce1	true	userinfo.token.claim
335c4232-e09b-4b9c-8c00-cf0ff7fb9ce1	birthdate	user.attribute
335c4232-e09b-4b9c-8c00-cf0ff7fb9ce1	true	id.token.claim
335c4232-e09b-4b9c-8c00-cf0ff7fb9ce1	true	access.token.claim
335c4232-e09b-4b9c-8c00-cf0ff7fb9ce1	birthdate	claim.name
335c4232-e09b-4b9c-8c00-cf0ff7fb9ce1	String	jsonType.label
46777601-77d4-48ef-8ce6-16be641ca22a	true	introspection.token.claim
46777601-77d4-48ef-8ce6-16be641ca22a	true	userinfo.token.claim
46777601-77d4-48ef-8ce6-16be641ca22a	website	user.attribute
46777601-77d4-48ef-8ce6-16be641ca22a	true	id.token.claim
46777601-77d4-48ef-8ce6-16be641ca22a	true	access.token.claim
46777601-77d4-48ef-8ce6-16be641ca22a	website	claim.name
46777601-77d4-48ef-8ce6-16be641ca22a	String	jsonType.label
5f1e4925-2593-4da5-af14-e8e1b2a508a4	true	introspection.token.claim
5f1e4925-2593-4da5-af14-e8e1b2a508a4	true	userinfo.token.claim
5f1e4925-2593-4da5-af14-e8e1b2a508a4	profile	user.attribute
5f1e4925-2593-4da5-af14-e8e1b2a508a4	true	id.token.claim
5f1e4925-2593-4da5-af14-e8e1b2a508a4	true	access.token.claim
5f1e4925-2593-4da5-af14-e8e1b2a508a4	profile	claim.name
5f1e4925-2593-4da5-af14-e8e1b2a508a4	String	jsonType.label
7fb659eb-8c43-452c-ae84-a647a23f4a61	true	introspection.token.claim
7fb659eb-8c43-452c-ae84-a647a23f4a61	true	userinfo.token.claim
7fb659eb-8c43-452c-ae84-a647a23f4a61	locale	user.attribute
7fb659eb-8c43-452c-ae84-a647a23f4a61	true	id.token.claim
7fb659eb-8c43-452c-ae84-a647a23f4a61	true	access.token.claim
7fb659eb-8c43-452c-ae84-a647a23f4a61	locale	claim.name
7fb659eb-8c43-452c-ae84-a647a23f4a61	String	jsonType.label
8421a8a3-4e81-4f1f-a0c5-33d6f78175da	true	introspection.token.claim
8421a8a3-4e81-4f1f-a0c5-33d6f78175da	true	userinfo.token.claim
8421a8a3-4e81-4f1f-a0c5-33d6f78175da	username	user.attribute
8421a8a3-4e81-4f1f-a0c5-33d6f78175da	true	id.token.claim
8421a8a3-4e81-4f1f-a0c5-33d6f78175da	true	access.token.claim
8421a8a3-4e81-4f1f-a0c5-33d6f78175da	preferred_username	claim.name
8421a8a3-4e81-4f1f-a0c5-33d6f78175da	String	jsonType.label
88c6df4d-4484-4e6d-ab42-260b58bf1fa7	true	introspection.token.claim
88c6df4d-4484-4e6d-ab42-260b58bf1fa7	true	userinfo.token.claim
88c6df4d-4484-4e6d-ab42-260b58bf1fa7	picture	user.attribute
88c6df4d-4484-4e6d-ab42-260b58bf1fa7	true	id.token.claim
88c6df4d-4484-4e6d-ab42-260b58bf1fa7	true	access.token.claim
88c6df4d-4484-4e6d-ab42-260b58bf1fa7	picture	claim.name
88c6df4d-4484-4e6d-ab42-260b58bf1fa7	String	jsonType.label
b7d797aa-d0b0-458e-b5e1-c2db6436dbe0	true	introspection.token.claim
b7d797aa-d0b0-458e-b5e1-c2db6436dbe0	true	userinfo.token.claim
b7d797aa-d0b0-458e-b5e1-c2db6436dbe0	nickname	user.attribute
b7d797aa-d0b0-458e-b5e1-c2db6436dbe0	true	id.token.claim
b7d797aa-d0b0-458e-b5e1-c2db6436dbe0	true	access.token.claim
b7d797aa-d0b0-458e-b5e1-c2db6436dbe0	nickname	claim.name
b7d797aa-d0b0-458e-b5e1-c2db6436dbe0	String	jsonType.label
c3fa3be2-9d4b-4e3f-84c2-b6bcf2786995	true	introspection.token.claim
c3fa3be2-9d4b-4e3f-84c2-b6bcf2786995	true	userinfo.token.claim
c3fa3be2-9d4b-4e3f-84c2-b6bcf2786995	true	id.token.claim
c3fa3be2-9d4b-4e3f-84c2-b6bcf2786995	true	access.token.claim
cbd9816f-5720-41eb-82aa-4d9bc4eae26f	true	introspection.token.claim
cbd9816f-5720-41eb-82aa-4d9bc4eae26f	true	userinfo.token.claim
cbd9816f-5720-41eb-82aa-4d9bc4eae26f	firstName	user.attribute
cbd9816f-5720-41eb-82aa-4d9bc4eae26f	true	id.token.claim
cbd9816f-5720-41eb-82aa-4d9bc4eae26f	true	access.token.claim
cbd9816f-5720-41eb-82aa-4d9bc4eae26f	given_name	claim.name
cbd9816f-5720-41eb-82aa-4d9bc4eae26f	String	jsonType.label
d234506f-1aa0-4d0b-85b0-3aa303fc4a31	true	introspection.token.claim
d234506f-1aa0-4d0b-85b0-3aa303fc4a31	true	userinfo.token.claim
d234506f-1aa0-4d0b-85b0-3aa303fc4a31	updatedAt	user.attribute
d234506f-1aa0-4d0b-85b0-3aa303fc4a31	true	id.token.claim
d234506f-1aa0-4d0b-85b0-3aa303fc4a31	true	access.token.claim
d234506f-1aa0-4d0b-85b0-3aa303fc4a31	updated_at	claim.name
d234506f-1aa0-4d0b-85b0-3aa303fc4a31	long	jsonType.label
db5656c4-6ee9-4d99-838e-7c7d5e66e8e4	true	introspection.token.claim
db5656c4-6ee9-4d99-838e-7c7d5e66e8e4	true	userinfo.token.claim
db5656c4-6ee9-4d99-838e-7c7d5e66e8e4	gender	user.attribute
db5656c4-6ee9-4d99-838e-7c7d5e66e8e4	true	id.token.claim
db5656c4-6ee9-4d99-838e-7c7d5e66e8e4	true	access.token.claim
db5656c4-6ee9-4d99-838e-7c7d5e66e8e4	gender	claim.name
db5656c4-6ee9-4d99-838e-7c7d5e66e8e4	String	jsonType.label
e1fb103c-6c6b-4605-9254-7fc2fbc4e667	true	introspection.token.claim
e1fb103c-6c6b-4605-9254-7fc2fbc4e667	true	userinfo.token.claim
e1fb103c-6c6b-4605-9254-7fc2fbc4e667	lastName	user.attribute
e1fb103c-6c6b-4605-9254-7fc2fbc4e667	true	id.token.claim
e1fb103c-6c6b-4605-9254-7fc2fbc4e667	true	access.token.claim
e1fb103c-6c6b-4605-9254-7fc2fbc4e667	family_name	claim.name
e1fb103c-6c6b-4605-9254-7fc2fbc4e667	String	jsonType.label
ea2a57c3-3751-4c8e-8656-5ab3174b1e95	true	introspection.token.claim
ea2a57c3-3751-4c8e-8656-5ab3174b1e95	true	userinfo.token.claim
ea2a57c3-3751-4c8e-8656-5ab3174b1e95	zoneinfo	user.attribute
ea2a57c3-3751-4c8e-8656-5ab3174b1e95	true	id.token.claim
ea2a57c3-3751-4c8e-8656-5ab3174b1e95	true	access.token.claim
ea2a57c3-3751-4c8e-8656-5ab3174b1e95	zoneinfo	claim.name
ea2a57c3-3751-4c8e-8656-5ab3174b1e95	String	jsonType.label
1fc611ea-c51e-4253-abdd-21cae10bfa4d	true	introspection.token.claim
1fc611ea-c51e-4253-abdd-21cae10bfa4d	true	userinfo.token.claim
1fc611ea-c51e-4253-abdd-21cae10bfa4d	emailVerified	user.attribute
1fc611ea-c51e-4253-abdd-21cae10bfa4d	true	id.token.claim
1fc611ea-c51e-4253-abdd-21cae10bfa4d	true	access.token.claim
1fc611ea-c51e-4253-abdd-21cae10bfa4d	email_verified	claim.name
1fc611ea-c51e-4253-abdd-21cae10bfa4d	boolean	jsonType.label
b9998f16-e98e-4844-b526-2aa7a5b64d8e	true	introspection.token.claim
b9998f16-e98e-4844-b526-2aa7a5b64d8e	true	userinfo.token.claim
b9998f16-e98e-4844-b526-2aa7a5b64d8e	email	user.attribute
b9998f16-e98e-4844-b526-2aa7a5b64d8e	true	id.token.claim
b9998f16-e98e-4844-b526-2aa7a5b64d8e	true	access.token.claim
b9998f16-e98e-4844-b526-2aa7a5b64d8e	email	claim.name
b9998f16-e98e-4844-b526-2aa7a5b64d8e	String	jsonType.label
485606a5-fb47-487f-ade8-e288963ffcd7	formatted	user.attribute.formatted
485606a5-fb47-487f-ade8-e288963ffcd7	country	user.attribute.country
485606a5-fb47-487f-ade8-e288963ffcd7	true	introspection.token.claim
485606a5-fb47-487f-ade8-e288963ffcd7	postal_code	user.attribute.postal_code
485606a5-fb47-487f-ade8-e288963ffcd7	true	userinfo.token.claim
485606a5-fb47-487f-ade8-e288963ffcd7	street	user.attribute.street
485606a5-fb47-487f-ade8-e288963ffcd7	true	id.token.claim
485606a5-fb47-487f-ade8-e288963ffcd7	region	user.attribute.region
485606a5-fb47-487f-ade8-e288963ffcd7	true	access.token.claim
485606a5-fb47-487f-ade8-e288963ffcd7	locality	user.attribute.locality
0faf431f-dee3-4617-99e2-0a9f86d80c0b	true	introspection.token.claim
0faf431f-dee3-4617-99e2-0a9f86d80c0b	true	userinfo.token.claim
0faf431f-dee3-4617-99e2-0a9f86d80c0b	phoneNumber	user.attribute
0faf431f-dee3-4617-99e2-0a9f86d80c0b	true	id.token.claim
0faf431f-dee3-4617-99e2-0a9f86d80c0b	true	access.token.claim
0faf431f-dee3-4617-99e2-0a9f86d80c0b	phone_number	claim.name
0faf431f-dee3-4617-99e2-0a9f86d80c0b	String	jsonType.label
ff0f3a5b-71c3-47c3-9df0-15d993dcc14a	true	introspection.token.claim
ff0f3a5b-71c3-47c3-9df0-15d993dcc14a	true	userinfo.token.claim
ff0f3a5b-71c3-47c3-9df0-15d993dcc14a	phoneNumberVerified	user.attribute
ff0f3a5b-71c3-47c3-9df0-15d993dcc14a	true	id.token.claim
ff0f3a5b-71c3-47c3-9df0-15d993dcc14a	true	access.token.claim
ff0f3a5b-71c3-47c3-9df0-15d993dcc14a	phone_number_verified	claim.name
ff0f3a5b-71c3-47c3-9df0-15d993dcc14a	boolean	jsonType.label
08e4f73f-9303-4d54-b499-dd8c373593fc	true	introspection.token.claim
08e4f73f-9303-4d54-b499-dd8c373593fc	true	access.token.claim
37d506c4-e321-40f0-9172-274f19ae51f7	true	introspection.token.claim
37d506c4-e321-40f0-9172-274f19ae51f7	true	multivalued
37d506c4-e321-40f0-9172-274f19ae51f7	foo	user.attribute
37d506c4-e321-40f0-9172-274f19ae51f7	true	access.token.claim
37d506c4-e321-40f0-9172-274f19ae51f7	resource_access.${client_id}.roles	claim.name
37d506c4-e321-40f0-9172-274f19ae51f7	String	jsonType.label
eb25206a-78d3-4f76-8fde-bed3b2ea2b21	true	introspection.token.claim
eb25206a-78d3-4f76-8fde-bed3b2ea2b21	true	multivalued
eb25206a-78d3-4f76-8fde-bed3b2ea2b21	foo	user.attribute
eb25206a-78d3-4f76-8fde-bed3b2ea2b21	true	access.token.claim
eb25206a-78d3-4f76-8fde-bed3b2ea2b21	realm_access.roles	claim.name
eb25206a-78d3-4f76-8fde-bed3b2ea2b21	String	jsonType.label
0843e4e9-a2be-4297-8781-dd6cabacb6e1	true	introspection.token.claim
0843e4e9-a2be-4297-8781-dd6cabacb6e1	true	access.token.claim
0ddb02d0-145b-4c2e-9941-cae02f775fdb	true	introspection.token.claim
0ddb02d0-145b-4c2e-9941-cae02f775fdb	true	userinfo.token.claim
0ddb02d0-145b-4c2e-9941-cae02f775fdb	username	user.attribute
0ddb02d0-145b-4c2e-9941-cae02f775fdb	true	id.token.claim
0ddb02d0-145b-4c2e-9941-cae02f775fdb	true	access.token.claim
0ddb02d0-145b-4c2e-9941-cae02f775fdb	upn	claim.name
0ddb02d0-145b-4c2e-9941-cae02f775fdb	String	jsonType.label
5ff51eeb-fd26-4bf7-873f-b094814afa08	true	introspection.token.claim
5ff51eeb-fd26-4bf7-873f-b094814afa08	true	multivalued
5ff51eeb-fd26-4bf7-873f-b094814afa08	foo	user.attribute
5ff51eeb-fd26-4bf7-873f-b094814afa08	true	id.token.claim
5ff51eeb-fd26-4bf7-873f-b094814afa08	true	access.token.claim
5ff51eeb-fd26-4bf7-873f-b094814afa08	groups	claim.name
5ff51eeb-fd26-4bf7-873f-b094814afa08	String	jsonType.label
f938e3ea-33e4-4426-8d9f-e4c072108650	true	introspection.token.claim
f938e3ea-33e4-4426-8d9f-e4c072108650	true	id.token.claim
f938e3ea-33e4-4426-8d9f-e4c072108650	true	access.token.claim
30355fe9-9bfd-4afa-84ce-101e1cfdbde7	true	multivalued
30355fe9-9bfd-4afa-84ce-101e1cfdbde7	true	userinfo.token.claim
30355fe9-9bfd-4afa-84ce-101e1cfdbde7	true	id.token.claim
30355fe9-9bfd-4afa-84ce-101e1cfdbde7	true	access.token.claim
30355fe9-9bfd-4afa-84ce-101e1cfdbde7	realm_access.roles	claim.name
30355fe9-9bfd-4afa-84ce-101e1cfdbde7	String	jsonType.label
ae0e9a75-bc19-484b-82b0-b727083853c1	attendance-frontend	included.client.audience
ae0e9a75-bc19-484b-82b0-b727083853c1	true	id.token.claim
ae0e9a75-bc19-484b-82b0-b727083853c1	true	access.token.claim
ae0e9a75-bc19-484b-82b0-b727083853c1	attendance-frontend	included.custom.audience
ae0e9a75-bc19-484b-82b0-b727083853c1	true	userinfo.token.claim
f01cce3e-6250-4b33-a0d8-17985680f116	true	userinfo.token.claim
f01cce3e-6250-4b33-a0d8-17985680f116	email	user.attribute
f01cce3e-6250-4b33-a0d8-17985680f116	true	id.token.claim
f01cce3e-6250-4b33-a0d8-17985680f116	true	access.token.claim
f01cce3e-6250-4b33-a0d8-17985680f116	email	claim.name
f01cce3e-6250-4b33-a0d8-17985680f116	String	jsonType.label
f1649e5a-26e9-4a42-97fe-38c67c101956	true	id.token.claim
f1649e5a-26e9-4a42-97fe-38c67c101956	true	access.token.claim
f1649e5a-26e9-4a42-97fe-38c67c101956	true	userinfo.token.claim
5a34ff4c-2459-4eb7-9e9f-5a8535169413	true	introspection.token.claim
5a34ff4c-2459-4eb7-9e9f-5a8535169413	true	userinfo.token.claim
5a34ff4c-2459-4eb7-9e9f-5a8535169413	locale	user.attribute
5a34ff4c-2459-4eb7-9e9f-5a8535169413	true	id.token.claim
5a34ff4c-2459-4eb7-9e9f-5a8535169413	true	access.token.claim
5a34ff4c-2459-4eb7-9e9f-5a8535169413	locale	claim.name
5a34ff4c-2459-4eb7-9e9f-5a8535169413	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
64915411-5e90-4f94-9757-8cf984b78491	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	9153c8c5-ffdc-4ffc-9e21-4f2f72bfcaaa	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	c2867d2a-3a58-4b2b-8b65-9200b8ebe6bf	b4e9c621-5666-4986-bcc3-2e6d3e11371a	30625a34-a12b-4114-a677-2020a5f36323	3ada9946-6171-42fe-8608-2950a5abd71d	773b5b67-7ac7-459a-843c-fd6b6185090b	2592000	f	900	t	f	e7d69ef2-f44d-4f7a-b105-77461191ef0a	0	f	0	0	8778f523-44ba-407e-b916-448a8abb627e
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	60	300	1800	\N	\N	\N	t	f	0	\N	attendance	0	\N	f	f	t	f	NONE	1800	36000	f	f	8d0b8899-7f49-405a-9006-ad43b706ce5e	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	975699e5-159f-45f2-aed5-b3f9db69d3f1	f1450d8a-6aff-4e40-b8fb-5fb0c39d37ec	278cd772-8dbc-40a7-9a2e-9b574bc3b18b	95523d95-55ba-484d-8548-eb0f7c7b0f65	39e38511-b2de-4f79-8eeb-1a16dfcfb8c4	2592000	f	900	t	f	574aaaf7-b80d-457f-b68a-ee04fc12ba34	0	f	0	0	e738529c-5b78-43dd-8148-0d414035c693
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	64915411-5e90-4f94-9757-8cf984b78491	
_browser_header.xContentTypeOptions	64915411-5e90-4f94-9757-8cf984b78491	nosniff
_browser_header.referrerPolicy	64915411-5e90-4f94-9757-8cf984b78491	no-referrer
_browser_header.xRobotsTag	64915411-5e90-4f94-9757-8cf984b78491	none
_browser_header.xFrameOptions	64915411-5e90-4f94-9757-8cf984b78491	SAMEORIGIN
_browser_header.contentSecurityPolicy	64915411-5e90-4f94-9757-8cf984b78491	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	64915411-5e90-4f94-9757-8cf984b78491	1; mode=block
_browser_header.strictTransportSecurity	64915411-5e90-4f94-9757-8cf984b78491	max-age=31536000; includeSubDomains
bruteForceProtected	64915411-5e90-4f94-9757-8cf984b78491	false
permanentLockout	64915411-5e90-4f94-9757-8cf984b78491	false
maxTemporaryLockouts	64915411-5e90-4f94-9757-8cf984b78491	0
maxFailureWaitSeconds	64915411-5e90-4f94-9757-8cf984b78491	900
minimumQuickLoginWaitSeconds	64915411-5e90-4f94-9757-8cf984b78491	60
waitIncrementSeconds	64915411-5e90-4f94-9757-8cf984b78491	60
quickLoginCheckMilliSeconds	64915411-5e90-4f94-9757-8cf984b78491	1000
maxDeltaTimeSeconds	64915411-5e90-4f94-9757-8cf984b78491	43200
failureFactor	64915411-5e90-4f94-9757-8cf984b78491	30
realmReusableOtpCode	64915411-5e90-4f94-9757-8cf984b78491	false
firstBrokerLoginFlowId	64915411-5e90-4f94-9757-8cf984b78491	88351c9e-f7f7-4bee-beaf-be9160830dde
displayName	64915411-5e90-4f94-9757-8cf984b78491	Keycloak
displayNameHtml	64915411-5e90-4f94-9757-8cf984b78491	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	64915411-5e90-4f94-9757-8cf984b78491	RS256
offlineSessionMaxLifespanEnabled	64915411-5e90-4f94-9757-8cf984b78491	false
offlineSessionMaxLifespan	64915411-5e90-4f94-9757-8cf984b78491	5184000
_browser_header.contentSecurityPolicyReportOnly	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	
_browser_header.xContentTypeOptions	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	nosniff
_browser_header.referrerPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	no-referrer
_browser_header.xRobotsTag	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	none
_browser_header.xFrameOptions	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	SAMEORIGIN
_browser_header.contentSecurityPolicy	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	1; mode=block
_browser_header.strictTransportSecurity	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	max-age=31536000; includeSubDomains
bruteForceProtected	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	false
permanentLockout	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	false
maxTemporaryLockouts	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0
maxFailureWaitSeconds	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	900
minimumQuickLoginWaitSeconds	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	60
waitIncrementSeconds	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	60
quickLoginCheckMilliSeconds	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	1000
maxDeltaTimeSeconds	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	43200
failureFactor	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	30
realmReusableOtpCode	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	false
displayName	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	Attendance Intelligence
defaultSignatureAlgorithm	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	RS256
offlineSessionMaxLifespanEnabled	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	false
offlineSessionMaxLifespan	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	5184000
actionTokenGeneratedByAdminLifespan	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	43200
actionTokenGeneratedByUserLifespan	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	300
oauth2DeviceCodeLifespan	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	600
oauth2DevicePollingInterval	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	5
webAuthnPolicyRpEntityName	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	keycloak
webAuthnPolicySignatureAlgorithms	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	ES256
webAuthnPolicyRpId	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	
webAuthnPolicyAttestationConveyancePreference	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	not specified
webAuthnPolicyAuthenticatorAttachment	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	not specified
webAuthnPolicyRequireResidentKey	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	not specified
webAuthnPolicyUserVerificationRequirement	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	not specified
webAuthnPolicyCreateTimeout	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0
webAuthnPolicyAvoidSameAuthenticatorRegister	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	false
webAuthnPolicyRpEntityNamePasswordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	ES256
webAuthnPolicyRpIdPasswordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	
webAuthnPolicyAttestationConveyancePreferencePasswordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	not specified
webAuthnPolicyRequireResidentKeyPasswordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	not specified
webAuthnPolicyCreateTimeoutPasswordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	false
cibaBackchannelTokenDeliveryMode	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	poll
cibaExpiresIn	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	120
cibaInterval	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	5
cibaAuthRequestedUserHint	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	login_hint
parRequestUriLifespan	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	60
firstBrokerLoginFlowId	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	d32aedd8-c838-4fe2-94b9-e6755da08287
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
64915411-5e90-4f94-9757-8cf984b78491	jboss-logging
4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	64915411-5e90-4f94-9757-8cf984b78491
password	password	t	t	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.redirect_uris (client_id, value) FROM stdin;
1654150e-ab4c-4dea-84d8-b28406d51365	/realms/master/account/*
f4b24e22-286b-4d5d-8546-a6c6562f24d4	/realms/master/account/*
0a734152-c8df-44f7-b13f-f1b1a1658688	/admin/master/console/*
0ed68a0e-e220-4ea6-a38d-c59f26e8b77d	/realms/attendance/account/*
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	/realms/attendance/account/*
daf50007-c534-4574-8205-2d83e93e5d0b	/admin/attendance/console/*
05de3fa6-f271-4655-97ed-d8f344c7dcdb	http://172.20.100.222:5173/*
05de3fa6-f271-4655-97ed-d8f344c7dcdb	http://172.20.100.222:5173
05de3fa6-f271-4655-97ed-d8f344c7dcdb	http://localhost:5173/*
05de3fa6-f271-4655-97ed-d8f344c7dcdb	http://localhost:5173
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
19371fad-3995-457b-9656-c5aa854ec6a7	VERIFY_EMAIL	Verify Email	64915411-5e90-4f94-9757-8cf984b78491	t	f	VERIFY_EMAIL	50
17b7f7dd-3c52-49f6-8da2-55c67a4688d8	UPDATE_PROFILE	Update Profile	64915411-5e90-4f94-9757-8cf984b78491	t	f	UPDATE_PROFILE	40
2a20861c-05e2-4209-a54f-3fe91b1f4772	CONFIGURE_TOTP	Configure OTP	64915411-5e90-4f94-9757-8cf984b78491	t	f	CONFIGURE_TOTP	10
87610cdc-4147-4680-a91a-c8dfd6930e88	UPDATE_PASSWORD	Update Password	64915411-5e90-4f94-9757-8cf984b78491	t	f	UPDATE_PASSWORD	30
1eb1d290-69f5-49ba-81db-a3d73f875073	TERMS_AND_CONDITIONS	Terms and Conditions	64915411-5e90-4f94-9757-8cf984b78491	f	f	TERMS_AND_CONDITIONS	20
87a0806e-22cd-4529-8a45-c3e9911d4fe4	delete_account	Delete Account	64915411-5e90-4f94-9757-8cf984b78491	f	f	delete_account	60
37e25716-68a5-4e76-a9a7-e4cc158df35a	update_user_locale	Update User Locale	64915411-5e90-4f94-9757-8cf984b78491	t	f	update_user_locale	1000
4e3f731f-1bcf-4523-9d35-1af4cd74b861	webauthn-register	Webauthn Register	64915411-5e90-4f94-9757-8cf984b78491	t	f	webauthn-register	70
c15e87dd-86ab-495e-a367-9cbc3ea383af	webauthn-register-passwordless	Webauthn Register Passwordless	64915411-5e90-4f94-9757-8cf984b78491	t	f	webauthn-register-passwordless	80
8c5072ff-641a-4355-8b70-9cebe6a3ba41	VERIFY_PROFILE	Verify Profile	64915411-5e90-4f94-9757-8cf984b78491	t	f	VERIFY_PROFILE	90
87587bb6-d0d0-4cda-9caf-7c375ce2753f	VERIFY_EMAIL	Verify Email	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	t	f	VERIFY_EMAIL	50
56cc5169-885c-4f88-b5f7-fcaf2add4d60	UPDATE_PROFILE	Update Profile	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	t	f	UPDATE_PROFILE	40
2080f570-d49d-4085-8e3b-f085c32887c6	CONFIGURE_TOTP	Configure OTP	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	t	f	CONFIGURE_TOTP	10
25b1bf56-7a50-43da-ba31-f24f2a6fbefa	UPDATE_PASSWORD	Update Password	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	t	f	UPDATE_PASSWORD	30
2f47aa07-5d7f-4f25-9107-a06a41ffd191	TERMS_AND_CONDITIONS	Terms and Conditions	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f	f	TERMS_AND_CONDITIONS	20
da372c81-0f47-40e0-9dd6-da7e072945a1	delete_account	Delete Account	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	f	f	delete_account	60
f0ea58a7-38d1-486b-867a-a8bc3f3d94f5	update_user_locale	Update User Locale	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	t	f	update_user_locale	1000
78145d20-e049-4c7d-a569-71d49eb8ff81	webauthn-register	Webauthn Register	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	t	f	webauthn-register	70
378f6efd-72d4-47ce-95af-ccd8989d8f81	webauthn-register-passwordless	Webauthn Register Passwordless	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	t	f	webauthn-register-passwordless	80
473c47fa-0836-4c6c-8cf4-dbb97c162722	VERIFY_PROFILE	Verify Profile	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	t	f	VERIFY_PROFILE	90
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
f4b24e22-286b-4d5d-8546-a6c6562f24d4	fa171061-5ad1-4de4-968c-03565263a5b3
f4b24e22-286b-4d5d-8546-a6c6562f24d4	e3f7ac08-4d00-4d9b-b115-b90ffff14991
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	35429dfb-284e-4581-88c4-f8b72fc7f9dd
1ae47cf6-d2f5-4d1f-9ee3-cd45a4fbc2e4	1a5ffc3c-a9e2-437e-9f60-f8560394d8f4
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_attribute (name, value, user_id, id, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
91e0a27b-7d07-4dcb-b0bf-9bfcec0167cd	admin@company.com	admin@company.com	t	t	\N	Admin	User	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	admin@company.com	\N	\N	0
f74294d7-388f-4bfc-9c8a-d96805bbd208	hr@company.com	hr@company.com	t	t	\N	HR	Manager	4ebdd4a5-621e-4ab4-a46c-c66d49a857c3	hr@company.com	\N	\N	0
673bec66-cfe8-4354-baa3-2a4bdcc1fe15	\N	931caf40-c44b-49de-a649-fd7940a579e3	f	t	\N	\N	\N	64915411-5e90-4f94-9757-8cf984b78491	admin	1775456789700	\N	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_group_membership (group_id, user_id) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
e3485049-b90d-4b1f-838a-cfb5b4adba11	91e0a27b-7d07-4dcb-b0bf-9bfcec0167cd
c291c886-754c-4ddc-b561-ac36f87372ce	f74294d7-388f-4bfc-9c8a-d96805bbd208
8778f523-44ba-407e-b916-448a8abb627e	673bec66-cfe8-4354-baa3-2a4bdcc1fe15
c0b118a6-f841-40cd-9920-959c8348c27d	673bec66-cfe8-4354-baa3-2a4bdcc1fe15
\.


--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_session (id, auth_method, ip_address, last_session_refresh, login_username, realm_id, remember_me, started, user_id, user_session_state, broker_session_id, broker_user_id) FROM stdin;
\.


--
-- Data for Name: user_session_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_session_note (user_session, name, value) FROM stdin;
\.


--
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.web_origins (client_id, value) FROM stdin;
0a734152-c8df-44f7-b13f-f1b1a1658688	+
daf50007-c534-4574-8205-2d83e93e5d0b	+
05de3fa6-f271-4655-97ed-d8f344c7dcdb	http://172.20.100.222:5173
05de3fa6-f271-4655-97ed-d8f344c7dcdb	http://localhost:5173
\.


--
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: client_user_session_note constr_cl_usr_ses_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT constr_cl_usr_ses_note PRIMARY KEY (client_session, name);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: client_session_role constraint_5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT constraint_5 PRIMARY KEY (client_session, role_id);


--
-- Name: user_session constraint_57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT constraint_57 PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client_session_note constraint_5e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT constraint_5e PRIMARY KEY (client_session, name);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: client_session constraint_8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT constraint_8 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: client_session_auth_status constraint_auth_status_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT constraint_auth_status_pk PRIMARY KEY (client_session, authenticator);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: client_session_prot_mapper constraint_cs_pmp_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT constraint_cs_pmp_pk PRIMARY KEY (client_session, protocol_mapper_id);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: user_session_note constraint_usn_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT constraint_usn_pk PRIMARY KEY (user_session, name);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_jkuwuvd56ontgsuhogm8uewrt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_jkuwuvd56ontgsuhogm8uewrt UNIQUE (client_id, client_storage_provider, external_client_id, user_id);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: fed_user_attr_long_values; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fed_user_attr_long_values ON public.fed_user_attribute USING btree (long_value_hash, name);


--
-- Name: fed_user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fed_user_attr_long_values_lower_case ON public.fed_user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_att_by_name_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_att_by_name_value ON public.client_attributes USING btree (name, substr(value, 1, 255));


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_client_session_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_session_session ON public.client_session USING btree (session_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_css_preload; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_css_preload ON public.offline_client_session USING btree (client_id, offline_flag);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_offline_uss_by_usersess; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_uss_by_usersess ON public.offline_user_session USING btree (realm_id, offline_flag, user_session_id);


--
-- Name: idx_offline_uss_createdon; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_uss_createdon ON public.offline_user_session USING btree (created_on);


--
-- Name: idx_offline_uss_preload; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_uss_preload ON public.offline_user_session USING btree (offline_flag, created_on, user_session_id);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_us_sess_id_on_cl_sess; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_us_sess_id_on_cl_sess ON public.offline_client_session USING btree (user_session_id);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: user_attr_long_values; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_attr_long_values ON public.user_attribute USING btree (long_value_hash, name);


--
-- Name: user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_attr_long_values_lower_case ON public.user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: client_session_auth_status auth_status_constraint; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT auth_status_constraint FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: client_session_note fk5edfb00ff51c2736; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT fk5edfb00ff51c2736 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: user_session_note fk5edfb00ff51d3472; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT fk5edfb00ff51d3472 FOREIGN KEY (user_session) REFERENCES public.user_session(id);


--
-- Name: client_session_role fk_11b7sgqw18i532811v7o2dv76; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT fk_11b7sgqw18i532811v7o2dv76 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session_prot_mapper fk_33a8sgqw18i532811v7o2dk89; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT fk_33a8sgqw18i532811v7o2dk89 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session fk_b4ao2vcvat6ukau74wbwtfqo1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT fk_b4ao2vcvat6ukau74wbwtfqo1 FOREIGN KEY (session_id) REFERENCES public.user_session(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_user_session_note fk_cl_usr_ses_note; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT fk_cl_usr_ses_note FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

\unrestrict TUrSJ1qZ5HHC7DTGVQXrLQlglIx1jwvNiH5oJXOabSnGt7ysrxIjLufCwSEtxDo

