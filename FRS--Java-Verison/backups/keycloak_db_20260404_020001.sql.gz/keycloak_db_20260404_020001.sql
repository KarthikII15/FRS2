--
-- PostgreSQL database dump
--

\restrict j4ihwSKwoV4KQ1LyBTzrh9OTEgorCNEnEzqdRE04OgFB1eEVTTTRWJwu32Z7PmX

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64)
);


--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


--
-- Name: client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


--
-- Name: client_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session (
    id character varying(36) NOT NULL,
    client_id character varying(36),
    redirect_uri character varying(255),
    state character varying(255),
    "timestamp" integer,
    session_id character varying(36),
    auth_method character varying(255),
    realm_id character varying(255),
    auth_user_id character varying(36),
    current_action character varying(36)
);


--
-- Name: client_session_auth_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session_auth_status (
    authenticator character varying(36) NOT NULL,
    status integer,
    client_session character varying(36) NOT NULL
);


--
-- Name: client_session_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session_note (
    name character varying(255) NOT NULL,
    value character varying(255),
    client_session character varying(36) NOT NULL
);


--
-- Name: client_session_prot_mapper; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session_prot_mapper (
    protocol_mapper_id character varying(36) NOT NULL,
    client_session character varying(36) NOT NULL
);


--
-- Name: client_session_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_session_role (
    role_id character varying(255) NOT NULL,
    client_session character varying(36) NOT NULL
);


--
-- Name: client_user_session_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_user_session_note (
    name character varying(255) NOT NULL,
    value character varying(2048),
    client_session character varying(36) NOT NULL
);


--
-- Name: component; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


--
-- Name: component_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


--
-- Name: credential; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255),
    details_json_long_value text
);


--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024),
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL
);


--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36)
);


--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL
);


--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL
);


--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: realm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


--
-- Name: user_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_session (
    id character varying(36) NOT NULL,
    auth_method character varying(255),
    ip_address character varying(255),
    last_session_refresh integer,
    login_username character varying(255),
    realm_id character varying(255),
    remember_me boolean DEFAULT false NOT NULL,
    started integer,
    user_id character varying(255),
    user_session_state integer,
    broker_session_id character varying(255),
    broker_user_id character varying(255)
);


--
-- Name: user_session_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_session_note (
    user_session character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(2048)
);


--
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
3f8229da-1e97-4e2f-84ac-82d08118d52d	\N	auth-cookie	2334ed90-f617-4b21-ad06-1f96d7b25bf2	cff7d17c-27ad-4c95-845e-ee298190bb41	2	10	f	\N	\N
66b7240c-1160-4133-9388-c1e256a6fe52	\N	auth-spnego	2334ed90-f617-4b21-ad06-1f96d7b25bf2	cff7d17c-27ad-4c95-845e-ee298190bb41	3	20	f	\N	\N
37863447-40a2-4e8c-bc8e-0a9141914e87	\N	identity-provider-redirector	2334ed90-f617-4b21-ad06-1f96d7b25bf2	cff7d17c-27ad-4c95-845e-ee298190bb41	2	25	f	\N	\N
15f209e9-67e0-463c-9fb7-7fe8d26dd62c	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	cff7d17c-27ad-4c95-845e-ee298190bb41	2	30	t	e3f80acf-b1e8-4a0d-a59d-71fb9e8be088	\N
1f216ab8-47de-40ea-b9f9-80802a674e72	\N	auth-username-password-form	2334ed90-f617-4b21-ad06-1f96d7b25bf2	e3f80acf-b1e8-4a0d-a59d-71fb9e8be088	0	10	f	\N	\N
be6c5abb-e034-4f2f-b31f-5c7add79a184	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	e3f80acf-b1e8-4a0d-a59d-71fb9e8be088	1	20	t	a4ba3d8e-61de-4928-852c-902855df1924	\N
7613202c-cf61-4cd7-a8f5-4fd7a451d6c1	\N	conditional-user-configured	2334ed90-f617-4b21-ad06-1f96d7b25bf2	a4ba3d8e-61de-4928-852c-902855df1924	0	10	f	\N	\N
3d3465a8-f080-4420-8cb8-ac5dfd6dbb43	\N	auth-otp-form	2334ed90-f617-4b21-ad06-1f96d7b25bf2	a4ba3d8e-61de-4928-852c-902855df1924	0	20	f	\N	\N
7dec7e1f-c835-4b18-b310-79e477aa5cb4	\N	direct-grant-validate-username	2334ed90-f617-4b21-ad06-1f96d7b25bf2	b9b47dc0-e7fa-45ce-a4cd-7e7e60a5f489	0	10	f	\N	\N
83d60364-335a-4200-82bc-c1f80e4e9b45	\N	direct-grant-validate-password	2334ed90-f617-4b21-ad06-1f96d7b25bf2	b9b47dc0-e7fa-45ce-a4cd-7e7e60a5f489	0	20	f	\N	\N
5542ea02-7801-4e04-8fc7-90785578f36c	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	b9b47dc0-e7fa-45ce-a4cd-7e7e60a5f489	1	30	t	9f589ddb-af4a-460e-87fb-3229c867c68d	\N
4471e715-293c-45ec-bda5-33ab5316adb5	\N	conditional-user-configured	2334ed90-f617-4b21-ad06-1f96d7b25bf2	9f589ddb-af4a-460e-87fb-3229c867c68d	0	10	f	\N	\N
df9c3010-7398-457b-ba23-e90fbfb82838	\N	direct-grant-validate-otp	2334ed90-f617-4b21-ad06-1f96d7b25bf2	9f589ddb-af4a-460e-87fb-3229c867c68d	0	20	f	\N	\N
0da8d6b2-9c52-4a63-8e81-c44af73c275b	\N	registration-page-form	2334ed90-f617-4b21-ad06-1f96d7b25bf2	42472110-33db-45ac-99b8-71ef7ef94bc8	0	10	t	a0db1ba8-1faf-43d6-b809-4e6a7b317bdb	\N
8b096c1e-0256-4966-b4bd-ec10e9ded91e	\N	registration-user-creation	2334ed90-f617-4b21-ad06-1f96d7b25bf2	a0db1ba8-1faf-43d6-b809-4e6a7b317bdb	0	20	f	\N	\N
ad6ed06d-7970-4d1b-8a92-f6462ebad81d	\N	registration-password-action	2334ed90-f617-4b21-ad06-1f96d7b25bf2	a0db1ba8-1faf-43d6-b809-4e6a7b317bdb	0	50	f	\N	\N
e481aa35-603e-4259-a0a1-516b50bd6d0b	\N	registration-recaptcha-action	2334ed90-f617-4b21-ad06-1f96d7b25bf2	a0db1ba8-1faf-43d6-b809-4e6a7b317bdb	3	60	f	\N	\N
c6ef0633-ad56-4fe4-8a9b-9bc7f9cc9553	\N	registration-terms-and-conditions	2334ed90-f617-4b21-ad06-1f96d7b25bf2	a0db1ba8-1faf-43d6-b809-4e6a7b317bdb	3	70	f	\N	\N
6bd3d8e4-e584-49ed-ab21-80d48ce7d7bf	\N	reset-credentials-choose-user	2334ed90-f617-4b21-ad06-1f96d7b25bf2	29cfc270-bf14-42d2-be61-a3897984294f	0	10	f	\N	\N
5b7d23bf-4856-4dc0-992b-b2ba00eb91ea	\N	reset-credential-email	2334ed90-f617-4b21-ad06-1f96d7b25bf2	29cfc270-bf14-42d2-be61-a3897984294f	0	20	f	\N	\N
f8a31408-b063-4d20-a123-1d66966a38dd	\N	reset-password	2334ed90-f617-4b21-ad06-1f96d7b25bf2	29cfc270-bf14-42d2-be61-a3897984294f	0	30	f	\N	\N
5bce85f1-a25f-454c-b897-57d13b58de25	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	29cfc270-bf14-42d2-be61-a3897984294f	1	40	t	e0905375-3f7d-4807-a4be-1f7ec522f153	\N
546ceef0-0063-4a97-80bb-5e2bc309bbcb	\N	conditional-user-configured	2334ed90-f617-4b21-ad06-1f96d7b25bf2	e0905375-3f7d-4807-a4be-1f7ec522f153	0	10	f	\N	\N
3c13d842-ffdc-45db-b12d-ae592cfa1d1f	\N	reset-otp	2334ed90-f617-4b21-ad06-1f96d7b25bf2	e0905375-3f7d-4807-a4be-1f7ec522f153	0	20	f	\N	\N
6ecd81a6-2888-4259-b964-9042ea9fce02	\N	client-secret	2334ed90-f617-4b21-ad06-1f96d7b25bf2	2ab3ce63-7e4f-4220-9329-7d4e277a70cb	2	10	f	\N	\N
1b79f19d-689a-4132-a537-c7620bf20848	\N	client-jwt	2334ed90-f617-4b21-ad06-1f96d7b25bf2	2ab3ce63-7e4f-4220-9329-7d4e277a70cb	2	20	f	\N	\N
e5bc2aa6-b60c-4c2e-b62c-3dcab45275fc	\N	client-secret-jwt	2334ed90-f617-4b21-ad06-1f96d7b25bf2	2ab3ce63-7e4f-4220-9329-7d4e277a70cb	2	30	f	\N	\N
f31465f6-08e1-4e5d-a818-aebfdfee63fe	\N	client-x509	2334ed90-f617-4b21-ad06-1f96d7b25bf2	2ab3ce63-7e4f-4220-9329-7d4e277a70cb	2	40	f	\N	\N
3e62dbb6-f312-470d-89d8-9873dbe84cb6	\N	idp-review-profile	2334ed90-f617-4b21-ad06-1f96d7b25bf2	1be0602f-3721-494f-804c-068ede67e9b2	0	10	f	\N	f7a4ffb3-bb7a-4552-af54-c38f67ad9879
bcc88f4e-9674-46ac-ac90-c3887c917161	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	1be0602f-3721-494f-804c-068ede67e9b2	0	20	t	45bd53fb-29fc-4fcc-b685-2aebb63d0612	\N
624d2c81-ba7e-4a20-a6aa-19e51b7d9070	\N	idp-create-user-if-unique	2334ed90-f617-4b21-ad06-1f96d7b25bf2	45bd53fb-29fc-4fcc-b685-2aebb63d0612	2	10	f	\N	f8d05f71-b52f-4fe1-a650-a27846844505
3776e4fc-f03f-4898-b046-592136cca278	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	45bd53fb-29fc-4fcc-b685-2aebb63d0612	2	20	t	c641e4f0-816b-4e2b-a73d-2a10686fe215	\N
7fc3235e-cda1-4141-83bb-e92bf972a052	\N	idp-confirm-link	2334ed90-f617-4b21-ad06-1f96d7b25bf2	c641e4f0-816b-4e2b-a73d-2a10686fe215	0	10	f	\N	\N
b5ffa373-c6e6-448d-86fa-c3bf5d8bcae5	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	c641e4f0-816b-4e2b-a73d-2a10686fe215	0	20	t	172b41fa-99d4-4306-bd8e-3c1998ec00dc	\N
101ef430-b975-4f68-856a-b00a0c7705ea	\N	idp-email-verification	2334ed90-f617-4b21-ad06-1f96d7b25bf2	172b41fa-99d4-4306-bd8e-3c1998ec00dc	2	10	f	\N	\N
7eec7a32-9ce5-4fd4-87b0-2771f4bf8d1e	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	172b41fa-99d4-4306-bd8e-3c1998ec00dc	2	20	t	3f00bff1-91c6-4270-980e-85f02286a383	\N
4b69ca5b-c880-4796-b4e7-156d9193ce99	\N	idp-username-password-form	2334ed90-f617-4b21-ad06-1f96d7b25bf2	3f00bff1-91c6-4270-980e-85f02286a383	0	10	f	\N	\N
7337ef77-c6be-4f31-8aee-782056946d37	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	3f00bff1-91c6-4270-980e-85f02286a383	1	20	t	955e3870-2d49-4daf-b858-1fca35b5e9f6	\N
4c744584-741f-4947-afa7-1c6f6f340109	\N	conditional-user-configured	2334ed90-f617-4b21-ad06-1f96d7b25bf2	955e3870-2d49-4daf-b858-1fca35b5e9f6	0	10	f	\N	\N
33dd14df-087e-4cf0-bc21-1257eb96133c	\N	auth-otp-form	2334ed90-f617-4b21-ad06-1f96d7b25bf2	955e3870-2d49-4daf-b858-1fca35b5e9f6	0	20	f	\N	\N
b7422647-e439-49b5-9565-5d149a209851	\N	http-basic-authenticator	2334ed90-f617-4b21-ad06-1f96d7b25bf2	2ffc5a72-d357-40dd-bb53-6bd63d7acc66	0	10	f	\N	\N
cdc8bd26-2d53-4db5-92ed-efc0c31e8e12	\N	docker-http-basic-authenticator	2334ed90-f617-4b21-ad06-1f96d7b25bf2	91b0e79f-bdec-402f-9693-903474354aa7	0	10	f	\N	\N
c7c5ef09-b6fe-4008-88f3-dc456087d50d	\N	auth-cookie	cca741d1-bc8c-4408-87d3-1831c344aac7	5dac7847-eca5-4ae9-9a26-04e9416d63fc	2	10	f	\N	\N
342d517b-b740-4edf-be32-391f1e72b83f	\N	auth-spnego	cca741d1-bc8c-4408-87d3-1831c344aac7	5dac7847-eca5-4ae9-9a26-04e9416d63fc	3	20	f	\N	\N
d41ccdf3-e3ab-4605-8da4-b03a0b8a27c5	\N	identity-provider-redirector	cca741d1-bc8c-4408-87d3-1831c344aac7	5dac7847-eca5-4ae9-9a26-04e9416d63fc	2	25	f	\N	\N
333269ec-2ea6-4a68-a822-aedbec226714	\N	\N	cca741d1-bc8c-4408-87d3-1831c344aac7	5dac7847-eca5-4ae9-9a26-04e9416d63fc	2	30	t	4a5a0c3e-df74-4ac6-aaae-63275cdf6704	\N
c43192f9-0cb8-403e-a796-34868daa4ec7	\N	auth-username-password-form	cca741d1-bc8c-4408-87d3-1831c344aac7	4a5a0c3e-df74-4ac6-aaae-63275cdf6704	0	10	f	\N	\N
80d60991-7231-48da-b627-9ce3233b9d78	\N	\N	cca741d1-bc8c-4408-87d3-1831c344aac7	4a5a0c3e-df74-4ac6-aaae-63275cdf6704	1	20	t	71d1c122-37ae-4d01-a348-0ffff81575e3	\N
6306d06e-da87-47f0-9657-f8f1bbd82260	\N	conditional-user-configured	cca741d1-bc8c-4408-87d3-1831c344aac7	71d1c122-37ae-4d01-a348-0ffff81575e3	0	10	f	\N	\N
775efdb7-fcaf-4748-be14-f67f764d3787	\N	auth-otp-form	cca741d1-bc8c-4408-87d3-1831c344aac7	71d1c122-37ae-4d01-a348-0ffff81575e3	0	20	f	\N	\N
d6778e20-d2a2-4aed-864a-dab3665bddd7	\N	direct-grant-validate-username	cca741d1-bc8c-4408-87d3-1831c344aac7	9cbf69be-6177-422e-8287-f534d8798a63	0	10	f	\N	\N
df6cbda6-63c0-4618-880c-4c89c844a520	\N	direct-grant-validate-password	cca741d1-bc8c-4408-87d3-1831c344aac7	9cbf69be-6177-422e-8287-f534d8798a63	0	20	f	\N	\N
2259816a-1e8a-4de7-9a71-fa3d7f1acfa9	\N	\N	cca741d1-bc8c-4408-87d3-1831c344aac7	9cbf69be-6177-422e-8287-f534d8798a63	1	30	t	7e4b703d-c9fd-4303-8a13-ea35a115f408	\N
b31b7684-58fc-457b-831e-09b2a551870b	\N	conditional-user-configured	cca741d1-bc8c-4408-87d3-1831c344aac7	7e4b703d-c9fd-4303-8a13-ea35a115f408	0	10	f	\N	\N
72406f1a-c2fa-4445-972e-b8d96e02720c	\N	direct-grant-validate-otp	cca741d1-bc8c-4408-87d3-1831c344aac7	7e4b703d-c9fd-4303-8a13-ea35a115f408	0	20	f	\N	\N
fcefdde5-fa71-480e-a2df-0aa36a00e176	\N	registration-page-form	cca741d1-bc8c-4408-87d3-1831c344aac7	148ae55e-f124-42c2-a205-3a571b674529	0	10	t	9dc0e1a2-5863-4c53-ba8e-3b507f181280	\N
b2cc3bfe-0a32-4128-a3de-deb9d0f527f0	\N	registration-user-creation	cca741d1-bc8c-4408-87d3-1831c344aac7	9dc0e1a2-5863-4c53-ba8e-3b507f181280	0	20	f	\N	\N
45fa9b43-df09-491d-b641-a625b9cf2a2a	\N	registration-password-action	cca741d1-bc8c-4408-87d3-1831c344aac7	9dc0e1a2-5863-4c53-ba8e-3b507f181280	0	50	f	\N	\N
f0427fa2-f597-4d7f-a5c7-36caf7521eb5	\N	registration-recaptcha-action	cca741d1-bc8c-4408-87d3-1831c344aac7	9dc0e1a2-5863-4c53-ba8e-3b507f181280	3	60	f	\N	\N
3478714e-0842-469d-b5ce-fa832da75869	\N	registration-terms-and-conditions	cca741d1-bc8c-4408-87d3-1831c344aac7	9dc0e1a2-5863-4c53-ba8e-3b507f181280	3	70	f	\N	\N
cc5b7b16-14a4-4f6a-aebf-5bcfa42e38d3	\N	reset-credentials-choose-user	cca741d1-bc8c-4408-87d3-1831c344aac7	2977955c-0fca-4eb0-a313-aac76f331163	0	10	f	\N	\N
b0b9b602-d832-491a-af2a-11c5142c0a41	\N	reset-credential-email	cca741d1-bc8c-4408-87d3-1831c344aac7	2977955c-0fca-4eb0-a313-aac76f331163	0	20	f	\N	\N
91f4501c-b18a-47c1-8461-6e70c9297b72	\N	reset-password	cca741d1-bc8c-4408-87d3-1831c344aac7	2977955c-0fca-4eb0-a313-aac76f331163	0	30	f	\N	\N
04e59947-d491-4f0a-9b4e-846469677073	\N	\N	cca741d1-bc8c-4408-87d3-1831c344aac7	2977955c-0fca-4eb0-a313-aac76f331163	1	40	t	76715ee1-caf7-4d1a-971d-a41945f3e79a	\N
f94e3269-2b6a-4645-86f9-38cd676d2c81	\N	conditional-user-configured	cca741d1-bc8c-4408-87d3-1831c344aac7	76715ee1-caf7-4d1a-971d-a41945f3e79a	0	10	f	\N	\N
1c8e7914-17bb-4d6f-b2d1-880600e83721	\N	reset-otp	cca741d1-bc8c-4408-87d3-1831c344aac7	76715ee1-caf7-4d1a-971d-a41945f3e79a	0	20	f	\N	\N
ce6494d5-57ec-4e61-89b8-4ad6aad447c5	\N	client-secret	cca741d1-bc8c-4408-87d3-1831c344aac7	2afd76ac-aff1-4c5a-b7f9-0fc07e5e4693	2	10	f	\N	\N
b2bf09a1-fb81-4e05-b8f4-f5ca2912c906	\N	client-jwt	cca741d1-bc8c-4408-87d3-1831c344aac7	2afd76ac-aff1-4c5a-b7f9-0fc07e5e4693	2	20	f	\N	\N
89d2f011-e166-4d91-a2e6-1b326106cfb7	\N	client-secret-jwt	cca741d1-bc8c-4408-87d3-1831c344aac7	2afd76ac-aff1-4c5a-b7f9-0fc07e5e4693	2	30	f	\N	\N
f5de7e55-fe63-496f-96b8-10749b3b8c5b	\N	client-x509	cca741d1-bc8c-4408-87d3-1831c344aac7	2afd76ac-aff1-4c5a-b7f9-0fc07e5e4693	2	40	f	\N	\N
1d72af67-a52e-4612-aca7-842cc97f0fe5	\N	idp-review-profile	cca741d1-bc8c-4408-87d3-1831c344aac7	9504779d-3196-40be-a17b-0b164a9f5a7d	0	10	f	\N	ec44b18e-fad5-453c-92d3-7c21ee4817c1
13b66171-3c16-424e-85cd-9d3b44ebaf8f	\N	\N	cca741d1-bc8c-4408-87d3-1831c344aac7	9504779d-3196-40be-a17b-0b164a9f5a7d	0	20	t	fd3d7c6e-e10b-4c57-a619-4ddce9858bec	\N
20b2d4c5-1016-4108-a0b2-8735787217eb	\N	idp-create-user-if-unique	cca741d1-bc8c-4408-87d3-1831c344aac7	fd3d7c6e-e10b-4c57-a619-4ddce9858bec	2	10	f	\N	4f492482-868e-4c6f-a3cc-1f1ad47091c1
ed5aa854-81bd-4882-a072-c10eb4a959a1	\N	\N	cca741d1-bc8c-4408-87d3-1831c344aac7	fd3d7c6e-e10b-4c57-a619-4ddce9858bec	2	20	t	fa8f1fed-c99c-4460-b6f8-3194fa0a7a49	\N
ef91e8db-c750-4192-b051-805d0f0817d6	\N	idp-confirm-link	cca741d1-bc8c-4408-87d3-1831c344aac7	fa8f1fed-c99c-4460-b6f8-3194fa0a7a49	0	10	f	\N	\N
711ff8d8-c038-4946-b3cb-2c055a1e493e	\N	\N	cca741d1-bc8c-4408-87d3-1831c344aac7	fa8f1fed-c99c-4460-b6f8-3194fa0a7a49	0	20	t	e0876bdc-8fe7-42d4-b00a-0b972c1ce1fb	\N
d79427c7-7bd8-4378-ba76-539fbfdd856b	\N	idp-email-verification	cca741d1-bc8c-4408-87d3-1831c344aac7	e0876bdc-8fe7-42d4-b00a-0b972c1ce1fb	2	10	f	\N	\N
870b9f30-b8c6-40b5-86c8-c374bad3db96	\N	\N	cca741d1-bc8c-4408-87d3-1831c344aac7	e0876bdc-8fe7-42d4-b00a-0b972c1ce1fb	2	20	t	a892a42b-f4e7-49b5-9b28-e5c6bb419108	\N
5e083fd9-c9b6-4ad4-97db-36dd5cc007df	\N	idp-username-password-form	cca741d1-bc8c-4408-87d3-1831c344aac7	a892a42b-f4e7-49b5-9b28-e5c6bb419108	0	10	f	\N	\N
cd618e26-8038-4ea3-8de6-effbf1a6d1f8	\N	\N	cca741d1-bc8c-4408-87d3-1831c344aac7	a892a42b-f4e7-49b5-9b28-e5c6bb419108	1	20	t	72de085b-9d25-4f72-ac5a-8180e5e0941c	\N
a2b59e94-93da-4982-a915-440a1305cc58	\N	conditional-user-configured	cca741d1-bc8c-4408-87d3-1831c344aac7	72de085b-9d25-4f72-ac5a-8180e5e0941c	0	10	f	\N	\N
629599b8-5834-412a-87d2-9b33294e7d14	\N	auth-otp-form	cca741d1-bc8c-4408-87d3-1831c344aac7	72de085b-9d25-4f72-ac5a-8180e5e0941c	0	20	f	\N	\N
488f1521-4a06-4f80-864d-5d74776adf7d	\N	http-basic-authenticator	cca741d1-bc8c-4408-87d3-1831c344aac7	570af2c5-4f13-444b-b048-61372d71aafc	0	10	f	\N	\N
fc25eb3e-1b08-49c0-adc8-20fa14e93c2a	\N	docker-http-basic-authenticator	cca741d1-bc8c-4408-87d3-1831c344aac7	6c047f7e-bb7a-4072-9b2b-7c297d938486	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
cff7d17c-27ad-4c95-845e-ee298190bb41	browser	browser based authentication	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	t	t
e3f80acf-b1e8-4a0d-a59d-71fb9e8be088	forms	Username, password, otp and other auth forms.	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	f	t
a4ba3d8e-61de-4928-852c-902855df1924	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	f	t
b9b47dc0-e7fa-45ce-a4cd-7e7e60a5f489	direct grant	OpenID Connect Resource Owner Grant	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	t	t
9f589ddb-af4a-460e-87fb-3229c867c68d	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	f	t
42472110-33db-45ac-99b8-71ef7ef94bc8	registration	registration flow	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	t	t
a0db1ba8-1faf-43d6-b809-4e6a7b317bdb	registration form	registration form	2334ed90-f617-4b21-ad06-1f96d7b25bf2	form-flow	f	t
29cfc270-bf14-42d2-be61-a3897984294f	reset credentials	Reset credentials for a user if they forgot their password or something	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	t	t
e0905375-3f7d-4807-a4be-1f7ec522f153	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	f	t
2ab3ce63-7e4f-4220-9329-7d4e277a70cb	clients	Base authentication for clients	2334ed90-f617-4b21-ad06-1f96d7b25bf2	client-flow	t	t
1be0602f-3721-494f-804c-068ede67e9b2	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	t	t
45bd53fb-29fc-4fcc-b685-2aebb63d0612	User creation or linking	Flow for the existing/non-existing user alternatives	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	f	t
c641e4f0-816b-4e2b-a73d-2a10686fe215	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	f	t
172b41fa-99d4-4306-bd8e-3c1998ec00dc	Account verification options	Method with which to verity the existing account	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	f	t
3f00bff1-91c6-4270-980e-85f02286a383	Verify Existing Account by Re-authentication	Reauthentication of existing account	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	f	t
955e3870-2d49-4daf-b858-1fca35b5e9f6	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	f	t
2ffc5a72-d357-40dd-bb53-6bd63d7acc66	saml ecp	SAML ECP Profile Authentication Flow	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	t	t
91b0e79f-bdec-402f-9693-903474354aa7	docker auth	Used by Docker clients to authenticate against the IDP	2334ed90-f617-4b21-ad06-1f96d7b25bf2	basic-flow	t	t
5dac7847-eca5-4ae9-9a26-04e9416d63fc	browser	browser based authentication	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	t	t
4a5a0c3e-df74-4ac6-aaae-63275cdf6704	forms	Username, password, otp and other auth forms.	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	f	t
71d1c122-37ae-4d01-a348-0ffff81575e3	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	f	t
9cbf69be-6177-422e-8287-f534d8798a63	direct grant	OpenID Connect Resource Owner Grant	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	t	t
7e4b703d-c9fd-4303-8a13-ea35a115f408	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	f	t
148ae55e-f124-42c2-a205-3a571b674529	registration	registration flow	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	t	t
9dc0e1a2-5863-4c53-ba8e-3b507f181280	registration form	registration form	cca741d1-bc8c-4408-87d3-1831c344aac7	form-flow	f	t
2977955c-0fca-4eb0-a313-aac76f331163	reset credentials	Reset credentials for a user if they forgot their password or something	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	t	t
76715ee1-caf7-4d1a-971d-a41945f3e79a	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	f	t
2afd76ac-aff1-4c5a-b7f9-0fc07e5e4693	clients	Base authentication for clients	cca741d1-bc8c-4408-87d3-1831c344aac7	client-flow	t	t
9504779d-3196-40be-a17b-0b164a9f5a7d	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	t	t
fd3d7c6e-e10b-4c57-a619-4ddce9858bec	User creation or linking	Flow for the existing/non-existing user alternatives	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	f	t
fa8f1fed-c99c-4460-b6f8-3194fa0a7a49	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	f	t
e0876bdc-8fe7-42d4-b00a-0b972c1ce1fb	Account verification options	Method with which to verity the existing account	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	f	t
a892a42b-f4e7-49b5-9b28-e5c6bb419108	Verify Existing Account by Re-authentication	Reauthentication of existing account	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	f	t
72de085b-9d25-4f72-ac5a-8180e5e0941c	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	f	t
570af2c5-4f13-444b-b048-61372d71aafc	saml ecp	SAML ECP Profile Authentication Flow	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	t	t
6c047f7e-bb7a-4072-9b2b-7c297d938486	docker auth	Used by Docker clients to authenticate against the IDP	cca741d1-bc8c-4408-87d3-1831c344aac7	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
f7a4ffb3-bb7a-4552-af54-c38f67ad9879	review profile config	2334ed90-f617-4b21-ad06-1f96d7b25bf2
f8d05f71-b52f-4fe1-a650-a27846844505	create unique user config	2334ed90-f617-4b21-ad06-1f96d7b25bf2
ec44b18e-fad5-453c-92d3-7c21ee4817c1	review profile config	cca741d1-bc8c-4408-87d3-1831c344aac7
4f492482-868e-4c6f-a3cc-1f1ad47091c1	create unique user config	cca741d1-bc8c-4408-87d3-1831c344aac7
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
f7a4ffb3-bb7a-4552-af54-c38f67ad9879	missing	update.profile.on.first.login
f8d05f71-b52f-4fe1-a650-a27846844505	false	require.password.update.after.registration
4f492482-868e-4c6f-a3cc-1f1ad47091c1	false	require.password.update.after.registration
ec44b18e-fad5-453c-92d3-7c21ee4817c1	missing	update.profile.on.first.login
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	f	master-realm	0	f	\N	\N	t	\N	f	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
13144151-41b0-48a2-b08f-2e88309599c9	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	2334ed90-f617-4b21-ad06-1f96d7b25bf2	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	2334ed90-f617-4b21-ad06-1f96d7b25bf2	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
74d4541e-9e12-4c82-8e58-9dce4711356f	t	f	broker	0	f	\N	\N	t	\N	f	2334ed90-f617-4b21-ad06-1f96d7b25bf2	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
41f6de3e-281b-45b2-968a-da1822a5deaf	t	f	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	2334ed90-f617-4b21-ad06-1f96d7b25bf2	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
77c86c9e-b8eb-435a-810f-c81a83b53937	t	f	admin-cli	0	t	\N	\N	f	\N	f	2334ed90-f617-4b21-ad06-1f96d7b25bf2	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	f	attendance-realm	0	f	\N	\N	t	\N	f	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N	0	f	f	attendance Realm	f	client-secret	\N	\N	\N	t	f	f	f
fbad5179-1373-4927-950c-de3614156022	t	f	realm-management	0	f	\N	\N	t	\N	f	cca741d1-bc8c-4408-87d3-1831c344aac7	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
4158b612-6349-4ee8-bbe9-712e39fe3b18	t	f	account	0	t	\N	/realms/attendance/account/	f	\N	f	cca741d1-bc8c-4408-87d3-1831c344aac7	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
810bae0c-bd22-473d-be9f-6802d42d21f5	t	f	account-console	0	t	\N	/realms/attendance/account/	f	\N	f	cca741d1-bc8c-4408-87d3-1831c344aac7	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
66e637ae-1b47-4122-976a-ce26d18f6f42	t	f	broker	0	f	\N	\N	t	\N	f	cca741d1-bc8c-4408-87d3-1831c344aac7	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
bc5d5436-458e-43ce-b6ad-f300b9132ed1	t	f	security-admin-console	0	t	\N	/admin/attendance/console/	f	\N	f	cca741d1-bc8c-4408-87d3-1831c344aac7	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
4ac349c2-cfac-4625-b780-cfda3ba615b9	t	f	admin-cli	0	t	\N	\N	f	\N	f	cca741d1-bc8c-4408-87d3-1831c344aac7	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	t	t	attendance-frontend	0	t	\N	\N	f	\N	f	cca741d1-bc8c-4408-87d3-1831c344aac7	openid-connect	-1	f	f	Attendance Frontend	f	client-secret	\N	React SPA — public client with PKCE	\N	t	f	t	f
88df8275-d32d-4a52-a122-552aeaa0da77	t	t	attendance-api	0	f	\N	\N	t	\N	f	cca741d1-bc8c-4408-87d3-1831c344aac7	openid-connect	-1	f	f	Attendance API	f	client-secret	\N	Backend resource server — bearer-only	\N	f	f	f	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
13144151-41b0-48a2-b08f-2e88309599c9	post.logout.redirect.uris	+
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	post.logout.redirect.uris	+
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	pkce.code.challenge.method	S256
41f6de3e-281b-45b2-968a-da1822a5deaf	post.logout.redirect.uris	+
41f6de3e-281b-45b2-968a-da1822a5deaf	pkce.code.challenge.method	S256
4158b612-6349-4ee8-bbe9-712e39fe3b18	post.logout.redirect.uris	+
810bae0c-bd22-473d-be9f-6802d42d21f5	post.logout.redirect.uris	+
810bae0c-bd22-473d-be9f-6802d42d21f5	pkce.code.challenge.method	S256
bc5d5436-458e-43ce-b6ad-f300b9132ed1	post.logout.redirect.uris	+
bc5d5436-458e-43ce-b6ad-f300b9132ed1	pkce.code.challenge.method	S256
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	pkce.code.challenge.method	S256
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	post.logout.redirect.uris	http://172.20.100.222:5173/*##http://localhost:5173/*
88df8275-d32d-4a52-a122-552aeaa0da77	post.logout.redirect.uris	+
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	offline_access	2334ed90-f617-4b21-ad06-1f96d7b25bf2	OpenID Connect built-in scope: offline_access	openid-connect
affd743f-e013-41a1-9e28-46f29276c85e	role_list	2334ed90-f617-4b21-ad06-1f96d7b25bf2	SAML role list	saml
970e8cd1-70c4-4394-8614-bbf97ff173af	profile	2334ed90-f617-4b21-ad06-1f96d7b25bf2	OpenID Connect built-in scope: profile	openid-connect
4a28b531-8c93-4c8d-8d71-6a7f44d84c30	email	2334ed90-f617-4b21-ad06-1f96d7b25bf2	OpenID Connect built-in scope: email	openid-connect
9502f7a6-0912-4226-9136-d135044a8b81	address	2334ed90-f617-4b21-ad06-1f96d7b25bf2	OpenID Connect built-in scope: address	openid-connect
2f7eab35-11bb-466b-a89c-af998c736afc	phone	2334ed90-f617-4b21-ad06-1f96d7b25bf2	OpenID Connect built-in scope: phone	openid-connect
e5710616-257d-4187-bdf8-1cc835dfac20	roles	2334ed90-f617-4b21-ad06-1f96d7b25bf2	OpenID Connect scope for add user roles to the access token	openid-connect
0c9c2fe1-1bcc-4e78-b010-817f54b69c20	web-origins	2334ed90-f617-4b21-ad06-1f96d7b25bf2	OpenID Connect scope for add allowed web origins to the access token	openid-connect
a68485f5-d306-40cd-a7e8-c9f2f61b5884	microprofile-jwt	2334ed90-f617-4b21-ad06-1f96d7b25bf2	Microprofile - JWT built-in scope	openid-connect
c9130b00-7c39-4691-b27a-7661312f48c5	acr	2334ed90-f617-4b21-ad06-1f96d7b25bf2	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
868548e6-46be-410e-b774-d0419c04b9c9	offline_access	cca741d1-bc8c-4408-87d3-1831c344aac7	OpenID Connect built-in scope: offline_access	openid-connect
ced791c7-d494-43ee-9a40-b99cefbc9df3	role_list	cca741d1-bc8c-4408-87d3-1831c344aac7	SAML role list	saml
09818233-afd4-4a3b-808e-3ac62d5592a0	profile	cca741d1-bc8c-4408-87d3-1831c344aac7	OpenID Connect built-in scope: profile	openid-connect
a7ad064d-a335-4897-afb2-6bc6bef6ba08	email	cca741d1-bc8c-4408-87d3-1831c344aac7	OpenID Connect built-in scope: email	openid-connect
facb300d-f4e2-4acc-9f74-d2d9526854e0	address	cca741d1-bc8c-4408-87d3-1831c344aac7	OpenID Connect built-in scope: address	openid-connect
1a05be77-be3c-4d0d-be2c-e701f29bba39	phone	cca741d1-bc8c-4408-87d3-1831c344aac7	OpenID Connect built-in scope: phone	openid-connect
0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	roles	cca741d1-bc8c-4408-87d3-1831c344aac7	OpenID Connect scope for add user roles to the access token	openid-connect
47541632-e7dc-49dd-b6a2-976ba5b14561	web-origins	cca741d1-bc8c-4408-87d3-1831c344aac7	OpenID Connect scope for add allowed web origins to the access token	openid-connect
4cbe216b-8577-42f0-8038-b03fc82f0540	microprofile-jwt	cca741d1-bc8c-4408-87d3-1831c344aac7	Microprofile - JWT built-in scope	openid-connect
f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	acr	cca741d1-bc8c-4408-87d3-1831c344aac7	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	true	display.on.consent.screen
2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	${offlineAccessScopeConsentText}	consent.screen.text
affd743f-e013-41a1-9e28-46f29276c85e	true	display.on.consent.screen
affd743f-e013-41a1-9e28-46f29276c85e	${samlRoleListScopeConsentText}	consent.screen.text
970e8cd1-70c4-4394-8614-bbf97ff173af	true	display.on.consent.screen
970e8cd1-70c4-4394-8614-bbf97ff173af	${profileScopeConsentText}	consent.screen.text
970e8cd1-70c4-4394-8614-bbf97ff173af	true	include.in.token.scope
4a28b531-8c93-4c8d-8d71-6a7f44d84c30	true	display.on.consent.screen
4a28b531-8c93-4c8d-8d71-6a7f44d84c30	${emailScopeConsentText}	consent.screen.text
4a28b531-8c93-4c8d-8d71-6a7f44d84c30	true	include.in.token.scope
9502f7a6-0912-4226-9136-d135044a8b81	true	display.on.consent.screen
9502f7a6-0912-4226-9136-d135044a8b81	${addressScopeConsentText}	consent.screen.text
9502f7a6-0912-4226-9136-d135044a8b81	true	include.in.token.scope
2f7eab35-11bb-466b-a89c-af998c736afc	true	display.on.consent.screen
2f7eab35-11bb-466b-a89c-af998c736afc	${phoneScopeConsentText}	consent.screen.text
2f7eab35-11bb-466b-a89c-af998c736afc	true	include.in.token.scope
e5710616-257d-4187-bdf8-1cc835dfac20	true	display.on.consent.screen
e5710616-257d-4187-bdf8-1cc835dfac20	${rolesScopeConsentText}	consent.screen.text
e5710616-257d-4187-bdf8-1cc835dfac20	false	include.in.token.scope
0c9c2fe1-1bcc-4e78-b010-817f54b69c20	false	display.on.consent.screen
0c9c2fe1-1bcc-4e78-b010-817f54b69c20		consent.screen.text
0c9c2fe1-1bcc-4e78-b010-817f54b69c20	false	include.in.token.scope
a68485f5-d306-40cd-a7e8-c9f2f61b5884	false	display.on.consent.screen
a68485f5-d306-40cd-a7e8-c9f2f61b5884	true	include.in.token.scope
c9130b00-7c39-4691-b27a-7661312f48c5	false	display.on.consent.screen
c9130b00-7c39-4691-b27a-7661312f48c5	false	include.in.token.scope
868548e6-46be-410e-b774-d0419c04b9c9	true	display.on.consent.screen
868548e6-46be-410e-b774-d0419c04b9c9	${offlineAccessScopeConsentText}	consent.screen.text
ced791c7-d494-43ee-9a40-b99cefbc9df3	true	display.on.consent.screen
ced791c7-d494-43ee-9a40-b99cefbc9df3	${samlRoleListScopeConsentText}	consent.screen.text
09818233-afd4-4a3b-808e-3ac62d5592a0	true	display.on.consent.screen
09818233-afd4-4a3b-808e-3ac62d5592a0	${profileScopeConsentText}	consent.screen.text
09818233-afd4-4a3b-808e-3ac62d5592a0	true	include.in.token.scope
a7ad064d-a335-4897-afb2-6bc6bef6ba08	true	display.on.consent.screen
a7ad064d-a335-4897-afb2-6bc6bef6ba08	${emailScopeConsentText}	consent.screen.text
a7ad064d-a335-4897-afb2-6bc6bef6ba08	true	include.in.token.scope
facb300d-f4e2-4acc-9f74-d2d9526854e0	true	display.on.consent.screen
facb300d-f4e2-4acc-9f74-d2d9526854e0	${addressScopeConsentText}	consent.screen.text
facb300d-f4e2-4acc-9f74-d2d9526854e0	true	include.in.token.scope
1a05be77-be3c-4d0d-be2c-e701f29bba39	true	display.on.consent.screen
1a05be77-be3c-4d0d-be2c-e701f29bba39	${phoneScopeConsentText}	consent.screen.text
1a05be77-be3c-4d0d-be2c-e701f29bba39	true	include.in.token.scope
0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	true	display.on.consent.screen
0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	${rolesScopeConsentText}	consent.screen.text
0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	false	include.in.token.scope
47541632-e7dc-49dd-b6a2-976ba5b14561	false	display.on.consent.screen
47541632-e7dc-49dd-b6a2-976ba5b14561		consent.screen.text
47541632-e7dc-49dd-b6a2-976ba5b14561	false	include.in.token.scope
4cbe216b-8577-42f0-8038-b03fc82f0540	false	display.on.consent.screen
4cbe216b-8577-42f0-8038-b03fc82f0540	true	include.in.token.scope
f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	false	display.on.consent.screen
f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	false	include.in.token.scope
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
13144151-41b0-48a2-b08f-2e88309599c9	970e8cd1-70c4-4394-8614-bbf97ff173af	t
13144151-41b0-48a2-b08f-2e88309599c9	e5710616-257d-4187-bdf8-1cc835dfac20	t
13144151-41b0-48a2-b08f-2e88309599c9	0c9c2fe1-1bcc-4e78-b010-817f54b69c20	t
13144151-41b0-48a2-b08f-2e88309599c9	c9130b00-7c39-4691-b27a-7661312f48c5	t
13144151-41b0-48a2-b08f-2e88309599c9	4a28b531-8c93-4c8d-8d71-6a7f44d84c30	t
13144151-41b0-48a2-b08f-2e88309599c9	2f7eab35-11bb-466b-a89c-af998c736afc	f
13144151-41b0-48a2-b08f-2e88309599c9	a68485f5-d306-40cd-a7e8-c9f2f61b5884	f
13144151-41b0-48a2-b08f-2e88309599c9	2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	f
13144151-41b0-48a2-b08f-2e88309599c9	9502f7a6-0912-4226-9136-d135044a8b81	f
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	970e8cd1-70c4-4394-8614-bbf97ff173af	t
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	e5710616-257d-4187-bdf8-1cc835dfac20	t
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	0c9c2fe1-1bcc-4e78-b010-817f54b69c20	t
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	c9130b00-7c39-4691-b27a-7661312f48c5	t
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	4a28b531-8c93-4c8d-8d71-6a7f44d84c30	t
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	2f7eab35-11bb-466b-a89c-af998c736afc	f
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	a68485f5-d306-40cd-a7e8-c9f2f61b5884	f
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	f
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	9502f7a6-0912-4226-9136-d135044a8b81	f
77c86c9e-b8eb-435a-810f-c81a83b53937	970e8cd1-70c4-4394-8614-bbf97ff173af	t
77c86c9e-b8eb-435a-810f-c81a83b53937	e5710616-257d-4187-bdf8-1cc835dfac20	t
77c86c9e-b8eb-435a-810f-c81a83b53937	0c9c2fe1-1bcc-4e78-b010-817f54b69c20	t
77c86c9e-b8eb-435a-810f-c81a83b53937	c9130b00-7c39-4691-b27a-7661312f48c5	t
77c86c9e-b8eb-435a-810f-c81a83b53937	4a28b531-8c93-4c8d-8d71-6a7f44d84c30	t
77c86c9e-b8eb-435a-810f-c81a83b53937	2f7eab35-11bb-466b-a89c-af998c736afc	f
77c86c9e-b8eb-435a-810f-c81a83b53937	a68485f5-d306-40cd-a7e8-c9f2f61b5884	f
77c86c9e-b8eb-435a-810f-c81a83b53937	2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	f
77c86c9e-b8eb-435a-810f-c81a83b53937	9502f7a6-0912-4226-9136-d135044a8b81	f
74d4541e-9e12-4c82-8e58-9dce4711356f	970e8cd1-70c4-4394-8614-bbf97ff173af	t
74d4541e-9e12-4c82-8e58-9dce4711356f	e5710616-257d-4187-bdf8-1cc835dfac20	t
74d4541e-9e12-4c82-8e58-9dce4711356f	0c9c2fe1-1bcc-4e78-b010-817f54b69c20	t
74d4541e-9e12-4c82-8e58-9dce4711356f	c9130b00-7c39-4691-b27a-7661312f48c5	t
74d4541e-9e12-4c82-8e58-9dce4711356f	4a28b531-8c93-4c8d-8d71-6a7f44d84c30	t
74d4541e-9e12-4c82-8e58-9dce4711356f	2f7eab35-11bb-466b-a89c-af998c736afc	f
74d4541e-9e12-4c82-8e58-9dce4711356f	a68485f5-d306-40cd-a7e8-c9f2f61b5884	f
74d4541e-9e12-4c82-8e58-9dce4711356f	2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	f
74d4541e-9e12-4c82-8e58-9dce4711356f	9502f7a6-0912-4226-9136-d135044a8b81	f
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	970e8cd1-70c4-4394-8614-bbf97ff173af	t
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	e5710616-257d-4187-bdf8-1cc835dfac20	t
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	0c9c2fe1-1bcc-4e78-b010-817f54b69c20	t
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	c9130b00-7c39-4691-b27a-7661312f48c5	t
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	4a28b531-8c93-4c8d-8d71-6a7f44d84c30	t
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	2f7eab35-11bb-466b-a89c-af998c736afc	f
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	a68485f5-d306-40cd-a7e8-c9f2f61b5884	f
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	f
029685e2-8b2c-4435-a9b6-e1ef371ccd6f	9502f7a6-0912-4226-9136-d135044a8b81	f
41f6de3e-281b-45b2-968a-da1822a5deaf	970e8cd1-70c4-4394-8614-bbf97ff173af	t
41f6de3e-281b-45b2-968a-da1822a5deaf	e5710616-257d-4187-bdf8-1cc835dfac20	t
41f6de3e-281b-45b2-968a-da1822a5deaf	0c9c2fe1-1bcc-4e78-b010-817f54b69c20	t
41f6de3e-281b-45b2-968a-da1822a5deaf	c9130b00-7c39-4691-b27a-7661312f48c5	t
41f6de3e-281b-45b2-968a-da1822a5deaf	4a28b531-8c93-4c8d-8d71-6a7f44d84c30	t
41f6de3e-281b-45b2-968a-da1822a5deaf	2f7eab35-11bb-466b-a89c-af998c736afc	f
41f6de3e-281b-45b2-968a-da1822a5deaf	a68485f5-d306-40cd-a7e8-c9f2f61b5884	f
41f6de3e-281b-45b2-968a-da1822a5deaf	2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	f
41f6de3e-281b-45b2-968a-da1822a5deaf	9502f7a6-0912-4226-9136-d135044a8b81	f
4158b612-6349-4ee8-bbe9-712e39fe3b18	47541632-e7dc-49dd-b6a2-976ba5b14561	t
4158b612-6349-4ee8-bbe9-712e39fe3b18	09818233-afd4-4a3b-808e-3ac62d5592a0	t
4158b612-6349-4ee8-bbe9-712e39fe3b18	a7ad064d-a335-4897-afb2-6bc6bef6ba08	t
4158b612-6349-4ee8-bbe9-712e39fe3b18	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	t
4158b612-6349-4ee8-bbe9-712e39fe3b18	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	t
4158b612-6349-4ee8-bbe9-712e39fe3b18	4cbe216b-8577-42f0-8038-b03fc82f0540	f
4158b612-6349-4ee8-bbe9-712e39fe3b18	facb300d-f4e2-4acc-9f74-d2d9526854e0	f
4158b612-6349-4ee8-bbe9-712e39fe3b18	868548e6-46be-410e-b774-d0419c04b9c9	f
4158b612-6349-4ee8-bbe9-712e39fe3b18	1a05be77-be3c-4d0d-be2c-e701f29bba39	f
810bae0c-bd22-473d-be9f-6802d42d21f5	47541632-e7dc-49dd-b6a2-976ba5b14561	t
810bae0c-bd22-473d-be9f-6802d42d21f5	09818233-afd4-4a3b-808e-3ac62d5592a0	t
810bae0c-bd22-473d-be9f-6802d42d21f5	a7ad064d-a335-4897-afb2-6bc6bef6ba08	t
810bae0c-bd22-473d-be9f-6802d42d21f5	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	t
810bae0c-bd22-473d-be9f-6802d42d21f5	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	t
810bae0c-bd22-473d-be9f-6802d42d21f5	4cbe216b-8577-42f0-8038-b03fc82f0540	f
810bae0c-bd22-473d-be9f-6802d42d21f5	facb300d-f4e2-4acc-9f74-d2d9526854e0	f
810bae0c-bd22-473d-be9f-6802d42d21f5	868548e6-46be-410e-b774-d0419c04b9c9	f
810bae0c-bd22-473d-be9f-6802d42d21f5	1a05be77-be3c-4d0d-be2c-e701f29bba39	f
4ac349c2-cfac-4625-b780-cfda3ba615b9	47541632-e7dc-49dd-b6a2-976ba5b14561	t
4ac349c2-cfac-4625-b780-cfda3ba615b9	09818233-afd4-4a3b-808e-3ac62d5592a0	t
4ac349c2-cfac-4625-b780-cfda3ba615b9	a7ad064d-a335-4897-afb2-6bc6bef6ba08	t
4ac349c2-cfac-4625-b780-cfda3ba615b9	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	t
4ac349c2-cfac-4625-b780-cfda3ba615b9	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	t
4ac349c2-cfac-4625-b780-cfda3ba615b9	4cbe216b-8577-42f0-8038-b03fc82f0540	f
4ac349c2-cfac-4625-b780-cfda3ba615b9	facb300d-f4e2-4acc-9f74-d2d9526854e0	f
4ac349c2-cfac-4625-b780-cfda3ba615b9	868548e6-46be-410e-b774-d0419c04b9c9	f
4ac349c2-cfac-4625-b780-cfda3ba615b9	1a05be77-be3c-4d0d-be2c-e701f29bba39	f
66e637ae-1b47-4122-976a-ce26d18f6f42	47541632-e7dc-49dd-b6a2-976ba5b14561	t
66e637ae-1b47-4122-976a-ce26d18f6f42	09818233-afd4-4a3b-808e-3ac62d5592a0	t
66e637ae-1b47-4122-976a-ce26d18f6f42	a7ad064d-a335-4897-afb2-6bc6bef6ba08	t
66e637ae-1b47-4122-976a-ce26d18f6f42	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	t
66e637ae-1b47-4122-976a-ce26d18f6f42	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	t
66e637ae-1b47-4122-976a-ce26d18f6f42	4cbe216b-8577-42f0-8038-b03fc82f0540	f
66e637ae-1b47-4122-976a-ce26d18f6f42	facb300d-f4e2-4acc-9f74-d2d9526854e0	f
66e637ae-1b47-4122-976a-ce26d18f6f42	868548e6-46be-410e-b774-d0419c04b9c9	f
66e637ae-1b47-4122-976a-ce26d18f6f42	1a05be77-be3c-4d0d-be2c-e701f29bba39	f
fbad5179-1373-4927-950c-de3614156022	47541632-e7dc-49dd-b6a2-976ba5b14561	t
fbad5179-1373-4927-950c-de3614156022	09818233-afd4-4a3b-808e-3ac62d5592a0	t
fbad5179-1373-4927-950c-de3614156022	a7ad064d-a335-4897-afb2-6bc6bef6ba08	t
fbad5179-1373-4927-950c-de3614156022	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	t
fbad5179-1373-4927-950c-de3614156022	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	t
fbad5179-1373-4927-950c-de3614156022	4cbe216b-8577-42f0-8038-b03fc82f0540	f
fbad5179-1373-4927-950c-de3614156022	facb300d-f4e2-4acc-9f74-d2d9526854e0	f
fbad5179-1373-4927-950c-de3614156022	868548e6-46be-410e-b774-d0419c04b9c9	f
fbad5179-1373-4927-950c-de3614156022	1a05be77-be3c-4d0d-be2c-e701f29bba39	f
bc5d5436-458e-43ce-b6ad-f300b9132ed1	47541632-e7dc-49dd-b6a2-976ba5b14561	t
bc5d5436-458e-43ce-b6ad-f300b9132ed1	09818233-afd4-4a3b-808e-3ac62d5592a0	t
bc5d5436-458e-43ce-b6ad-f300b9132ed1	a7ad064d-a335-4897-afb2-6bc6bef6ba08	t
bc5d5436-458e-43ce-b6ad-f300b9132ed1	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	t
bc5d5436-458e-43ce-b6ad-f300b9132ed1	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	t
bc5d5436-458e-43ce-b6ad-f300b9132ed1	4cbe216b-8577-42f0-8038-b03fc82f0540	f
bc5d5436-458e-43ce-b6ad-f300b9132ed1	facb300d-f4e2-4acc-9f74-d2d9526854e0	f
bc5d5436-458e-43ce-b6ad-f300b9132ed1	868548e6-46be-410e-b774-d0419c04b9c9	f
bc5d5436-458e-43ce-b6ad-f300b9132ed1	1a05be77-be3c-4d0d-be2c-e701f29bba39	f
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	47541632-e7dc-49dd-b6a2-976ba5b14561	t
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	09818233-afd4-4a3b-808e-3ac62d5592a0	t
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	a7ad064d-a335-4897-afb2-6bc6bef6ba08	t
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	t
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	t
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	4cbe216b-8577-42f0-8038-b03fc82f0540	f
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	facb300d-f4e2-4acc-9f74-d2d9526854e0	f
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	868548e6-46be-410e-b774-d0419c04b9c9	f
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	1a05be77-be3c-4d0d-be2c-e701f29bba39	f
88df8275-d32d-4a52-a122-552aeaa0da77	47541632-e7dc-49dd-b6a2-976ba5b14561	t
88df8275-d32d-4a52-a122-552aeaa0da77	09818233-afd4-4a3b-808e-3ac62d5592a0	t
88df8275-d32d-4a52-a122-552aeaa0da77	a7ad064d-a335-4897-afb2-6bc6bef6ba08	t
88df8275-d32d-4a52-a122-552aeaa0da77	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	t
88df8275-d32d-4a52-a122-552aeaa0da77	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	t
88df8275-d32d-4a52-a122-552aeaa0da77	4cbe216b-8577-42f0-8038-b03fc82f0540	f
88df8275-d32d-4a52-a122-552aeaa0da77	facb300d-f4e2-4acc-9f74-d2d9526854e0	f
88df8275-d32d-4a52-a122-552aeaa0da77	868548e6-46be-410e-b774-d0419c04b9c9	f
88df8275-d32d-4a52-a122-552aeaa0da77	1a05be77-be3c-4d0d-be2c-e701f29bba39	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	cc17bb61-fcb1-4b08-adb1-50d7d12ed0ed
868548e6-46be-410e-b774-d0419c04b9c9	6ea8aa9c-d06c-44d0-b71f-aabda6641a72
\.


--
-- Data for Name: client_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session (id, client_id, redirect_uri, state, "timestamp", session_id, auth_method, realm_id, auth_user_id, current_action) FROM stdin;
\.


--
-- Data for Name: client_session_auth_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session_auth_status (authenticator, status, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_prot_mapper; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session_prot_mapper (protocol_mapper_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_session_role (role_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_user_session_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_user_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
68e75a1a-b8e5-4118-82f7-a718047e070e	Trusted Hosts	2334ed90-f617-4b21-ad06-1f96d7b25bf2	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	anonymous
ab2d81df-031d-4312-9cb2-37e39e5283b0	Consent Required	2334ed90-f617-4b21-ad06-1f96d7b25bf2	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	anonymous
605974a3-3142-4b6a-98f3-5e719df6211f	Full Scope Disabled	2334ed90-f617-4b21-ad06-1f96d7b25bf2	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	anonymous
9187e2bf-3cc2-4c95-aca2-4a2d6ecc9855	Max Clients Limit	2334ed90-f617-4b21-ad06-1f96d7b25bf2	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	anonymous
4ba63da8-6abf-469b-a904-a16c57a2b5d3	Allowed Protocol Mapper Types	2334ed90-f617-4b21-ad06-1f96d7b25bf2	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	anonymous
3905e219-e3c9-4721-b35e-2be939877753	Allowed Client Scopes	2334ed90-f617-4b21-ad06-1f96d7b25bf2	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	anonymous
91dcc9bd-4ab2-4418-95ba-9b472c83b755	Allowed Protocol Mapper Types	2334ed90-f617-4b21-ad06-1f96d7b25bf2	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	authenticated
732df614-e6fa-4131-9406-784adf4474ea	Allowed Client Scopes	2334ed90-f617-4b21-ad06-1f96d7b25bf2	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	authenticated
deea9afd-1b19-4252-910e-187bf5ec8600	rsa-generated	2334ed90-f617-4b21-ad06-1f96d7b25bf2	rsa-generated	org.keycloak.keys.KeyProvider	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N
d3230ed3-ddf6-48ec-b4ff-8516049f9791	rsa-enc-generated	2334ed90-f617-4b21-ad06-1f96d7b25bf2	rsa-enc-generated	org.keycloak.keys.KeyProvider	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N
62061b40-35c1-4aa4-b061-0e8e31dc2721	hmac-generated-hs512	2334ed90-f617-4b21-ad06-1f96d7b25bf2	hmac-generated	org.keycloak.keys.KeyProvider	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N
9cbab8b2-49a1-415d-b8ed-977c9eb91fb4	aes-generated	2334ed90-f617-4b21-ad06-1f96d7b25bf2	aes-generated	org.keycloak.keys.KeyProvider	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N
97bb7881-52a4-4d63-a5b8-74ab4aa5e5fe	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	declarative-user-profile	org.keycloak.userprofile.UserProfileProvider	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N
ace80f1b-a4cc-4149-b2c2-abe390f4a153	rsa-generated	cca741d1-bc8c-4408-87d3-1831c344aac7	rsa-generated	org.keycloak.keys.KeyProvider	cca741d1-bc8c-4408-87d3-1831c344aac7	\N
37150a25-d623-42e9-912f-d065a74ee09c	rsa-enc-generated	cca741d1-bc8c-4408-87d3-1831c344aac7	rsa-enc-generated	org.keycloak.keys.KeyProvider	cca741d1-bc8c-4408-87d3-1831c344aac7	\N
ca477280-fe7a-4fd1-a319-9190bd3d1a4b	hmac-generated-hs512	cca741d1-bc8c-4408-87d3-1831c344aac7	hmac-generated	org.keycloak.keys.KeyProvider	cca741d1-bc8c-4408-87d3-1831c344aac7	\N
2989a4e4-54ce-48f2-a796-d024824cdf15	aes-generated	cca741d1-bc8c-4408-87d3-1831c344aac7	aes-generated	org.keycloak.keys.KeyProvider	cca741d1-bc8c-4408-87d3-1831c344aac7	\N
9e129a1d-6104-44e7-bf3f-54a751898b21	Trusted Hosts	cca741d1-bc8c-4408-87d3-1831c344aac7	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	anonymous
306b8509-fbcb-48a9-89f1-6032061b4d7c	Consent Required	cca741d1-bc8c-4408-87d3-1831c344aac7	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	anonymous
312bd1ff-fd9a-4d8a-aede-a21f85dc1e66	Full Scope Disabled	cca741d1-bc8c-4408-87d3-1831c344aac7	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	anonymous
25b52e54-cc44-4aaf-8f52-37c6f75953bf	Max Clients Limit	cca741d1-bc8c-4408-87d3-1831c344aac7	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	anonymous
362f5728-a10d-4700-b560-e6ab4da27092	Allowed Protocol Mapper Types	cca741d1-bc8c-4408-87d3-1831c344aac7	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	anonymous
0145a4f9-2c87-4fca-adc4-ccd66a5722f4	Allowed Client Scopes	cca741d1-bc8c-4408-87d3-1831c344aac7	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	anonymous
d62007f1-910d-416e-aa85-7ee208ceea1f	Allowed Protocol Mapper Types	cca741d1-bc8c-4408-87d3-1831c344aac7	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	authenticated
f428caec-bc50-4deb-b7c0-80b6d9db6fe9	Allowed Client Scopes	cca741d1-bc8c-4408-87d3-1831c344aac7	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	authenticated
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
140806db-32cb-4a4e-851a-7a7db92824ee	68e75a1a-b8e5-4118-82f7-a718047e070e	host-sending-registration-request-must-match	true
7a8bc2c9-7d67-4926-b5a7-543df19a4d96	68e75a1a-b8e5-4118-82f7-a718047e070e	client-uris-must-match	true
e13f0311-32bb-437b-bdaf-a8dbbb660b3b	732df614-e6fa-4131-9406-784adf4474ea	allow-default-scopes	true
a56af869-7550-4cca-8418-af105ea0a829	4ba63da8-6abf-469b-a904-a16c57a2b5d3	allowed-protocol-mapper-types	saml-user-attribute-mapper
551582c2-3a6f-459d-a147-7ab891523c57	4ba63da8-6abf-469b-a904-a16c57a2b5d3	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
fc3f2ceb-32f7-4eb8-bbff-61bfe498309a	4ba63da8-6abf-469b-a904-a16c57a2b5d3	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
90a57768-be89-40cb-ac22-3dc953516994	4ba63da8-6abf-469b-a904-a16c57a2b5d3	allowed-protocol-mapper-types	saml-user-property-mapper
d5419a3c-7682-42cb-b13b-44ea0e782437	4ba63da8-6abf-469b-a904-a16c57a2b5d3	allowed-protocol-mapper-types	oidc-address-mapper
9be23158-b6f9-4307-87bc-ff9b92fd0309	4ba63da8-6abf-469b-a904-a16c57a2b5d3	allowed-protocol-mapper-types	saml-role-list-mapper
08d32da8-42bc-4531-8426-79cc43c3d17b	4ba63da8-6abf-469b-a904-a16c57a2b5d3	allowed-protocol-mapper-types	oidc-full-name-mapper
fb9c6c0a-0551-490d-a9a4-5b4cb2357bdb	4ba63da8-6abf-469b-a904-a16c57a2b5d3	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
dc2013ca-7a79-478f-867a-772b5ec7d868	9187e2bf-3cc2-4c95-aca2-4a2d6ecc9855	max-clients	200
89365fc7-79b6-4498-8c35-73f7d9b5edc2	91dcc9bd-4ab2-4418-95ba-9b472c83b755	allowed-protocol-mapper-types	oidc-full-name-mapper
8fac3d45-9c4c-4e02-83e9-79f99b9f650e	91dcc9bd-4ab2-4418-95ba-9b472c83b755	allowed-protocol-mapper-types	saml-user-attribute-mapper
f3a9c911-e35d-4ae4-a7a2-009412ad80fa	91dcc9bd-4ab2-4418-95ba-9b472c83b755	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
2ed954f0-b992-465b-9795-5ddf6cb5d41a	91dcc9bd-4ab2-4418-95ba-9b472c83b755	allowed-protocol-mapper-types	saml-role-list-mapper
ba4c09bc-0d69-4ae6-ac28-e5daf9e920d4	91dcc9bd-4ab2-4418-95ba-9b472c83b755	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
cd871eac-fc05-4e87-8bdf-b0b8ebb276db	91dcc9bd-4ab2-4418-95ba-9b472c83b755	allowed-protocol-mapper-types	oidc-address-mapper
3f8359b0-0a5a-4ca9-8748-6e11b1eeb1ee	91dcc9bd-4ab2-4418-95ba-9b472c83b755	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
cbece8b1-440f-4a2f-8ac2-9952e3dad0dd	91dcc9bd-4ab2-4418-95ba-9b472c83b755	allowed-protocol-mapper-types	saml-user-property-mapper
cf48485b-f09e-4e0c-b5e3-bf664cc3f716	3905e219-e3c9-4721-b35e-2be939877753	allow-default-scopes	true
98394c9b-8255-442f-9676-22d72e496d54	deea9afd-1b19-4252-910e-187bf5ec8600	certificate	MIICmzCCAYMCBgGdHis9wjANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwMzI0MDQ0NTQzWhcNMzYwMzI0MDQ0NzIzWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCioP92TyyoveTiH2IWWEcCldlc3YHV3FbgYwHw9PRUdQJkNyerY7AinqQhDozs+VmdOfZ/YdhYAr6jdPY5PscxyKoObuqbksqKXNhHsqK1NarYrgSRnJV6hrXPLxi14bD1yk8GV5fnOdnD7pDpnHoIg5PSCI+k5HSx2WVZxX1ZXC3CxF6ic9zdV/A8nlGipiSMQphfI/k7B9OlSKsv6S3CNz5Wh1m/37EwqI+VbUtY9os/jxfgKGMpdJaK341vQSQsy/3+8+T8gjMj6f22bfAkVMtGtB5lj382QgUGnAzpAlv4x2FhV/Gj+w3xEgglq4QcX+jhTkuOkHNClARKpJOlAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAEdIum1wcodfrBleXw44bf55JEbYRAzqI2ly5bd6tLvCYblfESgIZct1dSdz2EzPEi3Q4y0O4IUz2xyDvG8/1cC/osWjZPoWG7PaA+yf8GviXzEA0d/AOkn42TjIYXmFv3qcJ4KqsKqrH5W+dQXyv6Ed3l80xFeQo2QQnNLeobYMAorQwpu1vhgsY+TovaWMbtSjJLDalytUos5ppDxdis/ZaWrCHxHHyoXPO5WvFQvwqV6GXIh0EYRhXvwIOfnTsVGPPFMRqMwS93NpsPinfeq6NJvL9QHR1/jaRxOtvlxFR6j9762FI7P2v6wayVmQkcthonSqHNjN1ej75pQ5sJk=
7adc2317-9b72-471c-9aca-f2cbc7cc8a06	deea9afd-1b19-4252-910e-187bf5ec8600	privateKey	MIIEowIBAAKCAQEAoqD/dk8sqL3k4h9iFlhHApXZXN2B1dxW4GMB8PT0VHUCZDcnq2OwIp6kIQ6M7PlZnTn2f2HYWAK+o3T2OT7HMciqDm7qm5LKilzYR7KitTWq2K4EkZyVeoa1zy8YteGw9cpPBleX5znZw+6Q6Zx6CIOT0giPpOR0sdllWcV9WVwtwsReonPc3VfwPJ5RoqYkjEKYXyP5OwfTpUirL+ktwjc+VodZv9+xMKiPlW1LWPaLP48X4ChjKXSWit+Nb0EkLMv9/vPk/IIzI+n9tm3wJFTLRrQeZY9/NkIFBpwM6QJb+MdhYVfxo/sN8RIIJauEHF/o4U5LjpBzQpQESqSTpQIDAQABAoIBAAmKaepCK1PL7iNQ5YN7ktDlQx72VMFb35Hi5RCCgln5ElaYQMDGhKUHSwgwbxaQ60+0wJAJCLTjFlWHDVHe67cxNz7JBYTyd+TlnP+ZzH9WgmsbTGPRfJh3Ui+xKuEyuBu3TmsIFP6I74xV0NUPq74XoAKso2awS2NKpm49joTBMk45otrQh5z0m0U+9T60wcDAnMZ71xRXBaz4wS7puxmZa57gILHIHgiZN1OxmtwPHQZF/tHx0JbuAIJskUNwwVwp1A4U7XiXfHUtwm1pJX/gp0FlSSMBwEVqxH28+6zSe9eumouvtcN4flvg0mcT0gLVHKlvFFFaudV0IRK4lLkCgYEA42TunOPijnWQLAuGSsLFIsViwHlzNfm5XOni7cQnpEOr747zo5wmsBqp60BtxQI7jV9HLOtPM2BLVWyfOZN5ljKR7Uiqh9E58NWbQu6cA4uKpO4eP27xuxy0rT9ZnQ1EYfL1c7nLdonX0XNgi/4QIZ66n6y+6bpv+LAfZOzLpXkCgYEAtxZYDpYCQTS+2H4/9h4eVXTAaekDEscvIoUaQZzmo+xGFCYo/SQeOYS1MBCv62+mwttNa+Jg/+2+PaThLsmEe/SFdRxLfbo92hcpSRfZdEcDkeSgSgtyryGW7+gN0xC3SmVFr8dCV7NUvIZFSI7/Xy9IzP0+6jbeVNcSuaTh8I0CgYBISbPZSFCjfRgiCF/esGA/F4S3L2TCyep1cRzk/TCk9aZY95bYcjGSVkeiM88xi+4mmR1lWEDLUldghrFvekRyzQy65BjiKE9FEoLTGkuajOe8Wr5e6AQMualuUe9JEAinIreI3I2j11o2iXktx8yVA4LMc/wVDWG/Ky4vxV9P8QKBgQCeDD3LqZccrumofaO9VFafMn//bVRn22ZHCFuYFFfNXeNI9YAgthMZWAQJD/6s4N82CpYU8YEGrTayhCiXeQJS9sxWQiywxhsqrx/Gpz3icIMWaCQuhx9jKz3er5VvhFiVckLr8LjGeFpHvCkG79pnUqwnuN2c1eyrlFXnx/v66QKBgF2ZBx3s+ir+jCfw12KNaXwMc/BAIKrNiouMQPwX2XU+0Of1El/Batwe9ciYbcg/WV15ros/De3VjDyxT/7j/4s8+8aWE2akEMO1hwVvuZ8UPrRzdJrSnAcEPb5+bTFy5XY/IvgaZ1tlilfaqqvJLllHhF6jm5CgbVqByyXV/Hff
1257e274-c06a-4549-95d8-4dbcbba32765	deea9afd-1b19-4252-910e-187bf5ec8600	keyUse	SIG
224e81de-2e79-4480-9f30-db034572afbc	deea9afd-1b19-4252-910e-187bf5ec8600	priority	100
2d1a19ad-3061-4267-b065-17e50470aa78	d3230ed3-ddf6-48ec-b4ff-8516049f9791	algorithm	RSA-OAEP
98fec636-f9dc-4f9f-960c-d387de72a7c8	d3230ed3-ddf6-48ec-b4ff-8516049f9791	certificate	MIICmzCCAYMCBgGdHis+lDANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwMzI0MDQ0NTQzWhcNMzYwMzI0MDQ0NzIzWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDJJd6cHE0pTUK156W/gwjy4L1HwG7Pk79u9blv/CU4c53xTvouBptp18vvUawZJEV6lJq3xiHMp/bYIgr8sCY1M7ZmSODavUkq3kOVUG20gtov6ptdeYhvAFDBy30e7K1lFDM4s5MX+d2uDEDsKzVIrdH0jdC/UfyQVBXQ6jKdhQWaJCwTfW1sU3svQmuQYVP9rjeCUVzcQyRtAun/TgLykIxKczm9TY5SOcTqF+x2ljXYDNj3C7Uzv5V7g+d7QMA5D2zmNM91yP2MZtBAiJx/lO5bMPkhc9Rb1IqpQG04yOaxdke+lGEMLQutxDj3O/8/VtYHEBPv32oWiYG4aUqDAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAAfr3oCSajy3HDzTkbZRzgMPjo23c6O3iXIR6UObOnA6P6SYZzdSszGL/NT92xqKFD3+7Pjx6X/Ii/JD1rCSFeQHwlzsxTJOUtZSlFbq/5cNu7RdupbCHqezJE45NjaeQswlPEdtWsyNWxGx2Dxb9Ft0GKcfiv2nnwkKdvUmnBwGBuieW5NPErJDKpaGK5Iyh4jD/M0HckwUc8dLqorVj0xG6HbTZZGcNAaNTV326I/UMw0DXLt0Z46DOn/lhhLeRiv7Ojgrf7WVH5wABWOqLmMMWrZFub8IDwIoeANJ5LiuhRRpi7G6/T+tuVIZ++s+NozzKgzRTol0qxU5lHI6gw4=
8613c427-f967-4f55-8ba1-1bc444f44322	d3230ed3-ddf6-48ec-b4ff-8516049f9791	keyUse	ENC
a94a4d77-8781-4873-a9d4-f29624545a31	d3230ed3-ddf6-48ec-b4ff-8516049f9791	privateKey	MIIEpAIBAAKCAQEAySXenBxNKU1Cteelv4MI8uC9R8Buz5O/bvW5b/wlOHOd8U76LgabadfL71GsGSRFepSat8YhzKf22CIK/LAmNTO2Zkjg2r1JKt5DlVBttILaL+qbXXmIbwBQwct9HuytZRQzOLOTF/ndrgxA7Cs1SK3R9I3Qv1H8kFQV0OoynYUFmiQsE31tbFN7L0JrkGFT/a43glFc3EMkbQLp/04C8pCMSnM5vU2OUjnE6hfsdpY12AzY9wu1M7+Ve4Pne0DAOQ9s5jTPdcj9jGbQQIicf5TuWzD5IXPUW9SKqUBtOMjmsXZHvpRhDC0LrcQ49zv/P1bWBxAT799qFomBuGlKgwIDAQABAoIBAB2swREt2bJYrBlTAfBlf/n47uO5f3+PMARKKx/axpDz+Z6ihKUqo13zkKoPVgDliXyClOq8x7q+ItwS9aT+xbw+k0+2u7l5iGRTIwxRr8WcMl00UtRw/BBILyHQB/b6esA5QS9BytcULUCinSdaXoOI5TsbeurmyQhv50IJcwsq1CZZ2uuQwwB+x89sz4K2DuZRKFuxB0sH07udMXK3Ls7G4/PbmHfwuZk4uvujaJlN7pCJej6QQLBrRODm4sfblBmGTnBG60mqEbSCzCYKOdo94q1Eyt1T+UJKGxkFHkgbLprA4wsggUFf7iwNXL15DN2QSkCcefO/Itey7pJqLDECgYEA8ivrHDzUj2pNI17JDOTKZRfO2m53ITfsGbTr5YM3rLYmuw8CsFae4vmCF3SlZvew3xoTJrs8sn1c1MWMUgBDD5+dBzx+CHgJMxpdMP/358LK5sEV1mKFtO1FQcr0TgE8KOHLCxVlpbNOmqYx3GwY/msKy0jYizFX9Kg9c1+DFPMCgYEA1KJDxzZRonB+41i5r5lRcH8cY9+CTQKBQO8PRWkZaFxu1Col+uI8TDalKgo96ss6+Kd+oix9yJAS1chV7reaLKUWGMGS/a3Dg658dwzRXhOhPi6HG8Cka3FG+hf/9seQKixNLh/NMOKPvDasub/faOxqBQbF6qBlJ4mnkbUWmDECgYA0lhLUq+TgS436iz+PHDNS5muVhP07amBLaLz8tpSlXVxlrCnCTtzrnpCANWUhSdHPcGMOOwRAIfbBgTAqMkJdpyQ7CQi5IA+nWCc6V6rmWacjmnP6fKRaGFe8pKyOL7h3jChB/OB4rcn4zPPw0ExRGr9aSzQybYGS7+GAJxJYvwKBgQCZIHHnGLsZXCJE3zR5vNPlS+TKF7/ibZdfh8lblyBxA3/c0q2fSyVZTVEMQWvtloXVY+nSKHA862RlCGy6CQbCd/C9y0lr3qMaRaHkqhpswX4xJZiu58CAj4cpu/bdZUHw3Q6H1OcT+VTBmi4xZnghO3/uNr55BSFTo9JFIEAxQQKBgQChG7ViprgI+wNMeSvQXQDW8mBEoG5konzYg3IQGzzjOelGeNLAs0DoigOEZseAKfsHCwQGcopYhX/QMLb69daKFXqJUE/yQfjivGCOH0hGP+6G5bEYeOaoUXduX/o3cTS+95JTPKcMpP2NUxnPD47Nmtn2QpBaFz4/I1aZrBNcNw==
1013ca50-e1d6-468f-bd7a-8aa94f700393	d3230ed3-ddf6-48ec-b4ff-8516049f9791	priority	100
43c4483b-ccfc-476a-b921-13a7864460bd	97bb7881-52a4-4d63-a5b8-74ab4aa5e5fe	kc.user.profile.config	{"attributes":[{"name":"username","displayName":"${username}","validations":{"length":{"min":3,"max":255},"username-prohibited-characters":{},"up-username-not-idn-homograph":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"email","displayName":"${email}","validations":{"email":{},"length":{"max":255}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"firstName","displayName":"${firstName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"lastName","displayName":"${lastName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false}],"groups":[{"name":"user-metadata","displayHeader":"User metadata","displayDescription":"Attributes, which refer to user metadata"}]}
bf93869e-4a2d-4340-993a-0bdd49ecf744	62061b40-35c1-4aa4-b061-0e8e31dc2721	secret	RxIwKqzyrBWi3ParKEH6aRRJDI2_lG1SocblbfCsiisn2tnQtsJIdOwMHNtTCLn56TYpie0SgFT11sM-GsgwSdNIgH3fvtM1_5EU-A81KoNf0O8Np6MYmjl-Gfl96_PvMNXdfTBwx7iOC34yYBgYF2EDFBS3mgjjubCdtg_O584
f862b7c3-f5b5-4117-9508-96555d3eb706	62061b40-35c1-4aa4-b061-0e8e31dc2721	kid	2aecd5ce-e74b-4fcc-aef3-19a9ead7a318
4adddba2-4b2c-4914-8ed0-a0e4e5f470bd	62061b40-35c1-4aa4-b061-0e8e31dc2721	priority	100
77fe91c1-a2c5-457e-ab9c-8416d5c09109	62061b40-35c1-4aa4-b061-0e8e31dc2721	algorithm	HS512
7d1b28aa-8a93-4e27-a721-7934d0dc8156	9cbab8b2-49a1-415d-b8ed-977c9eb91fb4	secret	TYPbAiW9YzJGYQ8DmT7p-w
bb903832-ff5f-4384-8446-1d1dd5b6fcca	9cbab8b2-49a1-415d-b8ed-977c9eb91fb4	priority	100
eca7fbe6-7355-4397-be4d-09148d905a95	9cbab8b2-49a1-415d-b8ed-977c9eb91fb4	kid	e3455264-9c8f-42e7-974e-a6f52f57cdba
ecaced2a-1e87-43ef-9f28-ccb9160df180	2989a4e4-54ce-48f2-a796-d024824cdf15	kid	512b977c-b018-4af4-a22c-b67c2d65dcf0
5a5ab84c-77c4-4107-8085-b82c1dd7e98b	2989a4e4-54ce-48f2-a796-d024824cdf15	priority	100
59e8f85d-695c-4c92-8601-ef1f234ab572	2989a4e4-54ce-48f2-a796-d024824cdf15	secret	8v87gMMeQbtQjfng4kSHmQ
026a0b91-0380-4299-8eac-25b2c191adeb	ace80f1b-a4cc-4149-b2c2-abe390f4a153	priority	100
a5c43446-5b87-4bd1-9c10-1954f72258d2	ace80f1b-a4cc-4149-b2c2-abe390f4a153	certificate	MIICozCCAYsCBgGdHitINTANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDDAphdHRlbmRhbmNlMB4XDTI2MDMyNDA0NDU0NloXDTM2MDMyNDA0NDcyNlowFTETMBEGA1UEAwwKYXR0ZW5kYW5jZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJTd336P8OB7Plp9Q5Y1FbxQWU2/1Rq+tWIZTIQYSKAd+BBINLuP96r58dPKLwlhoMyDTdmnFoM89n8xK0YyrS5wAMrFJORKiw9op3zyGWT7nBIMzJz1tNClSfnA+5NgBl5hqiZbOoKEgxJkV35h06FAlQKBaxyLpuRhxnwyEjbm95cggqoOghfYngB6/bTaPfyBR+xUZgvKsjcnFLL+9IbXPFUCcEpIJCukpLA7SeKJuwK0lbGD/AnumKfMppW1Rz4g3hbK20gfsmnesyUOBc+qY8G/hxKvhZMHzmczv8pe1lbaNoxRcE0Yq91HoWO0M8YwVsfyHDPo7e6h7RBuBCMCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAA3aU4LB0iijWsvmIkyEwqvHeQOEThUV88BqzHmCzQ/L6kLtUmfNfogpRGZ377/XqokbB3JpOpTsryFKXr5dkeuoRKoBLf+T3+2Jd5S2QhGtV+tdEb3uOgYQF5Inv9i9/XcMwvuz07pjZldXx4BmbW9e8z8TOlSDG2JRomg7GcxI4cEN5T1/JKzMsy7rwN80STdb5glxLC6xmWXkNB3feZz4tY96n6FDnQUk/lzXSh3zm+kO9bJOZ5iq9mdPgII6KAuKanklekN3XVeOZ3e5Aov8B5XQO5oHhzml2AfVWW4HdNCV3ljolw/Q7r38REO+bjvOBKcBoZRI/zgSgpON5pQ==
88bacc9d-c40c-447a-ba67-862872322c29	ace80f1b-a4cc-4149-b2c2-abe390f4a153	privateKey	MIIEoQIBAAKCAQEAlN3ffo/w4Hs+Wn1DljUVvFBZTb/VGr61YhlMhBhIoB34EEg0u4/3qvnx08ovCWGgzINN2acWgzz2fzErRjKtLnAAysUk5EqLD2infPIZZPucEgzMnPW00KVJ+cD7k2AGXmGqJls6goSDEmRXfmHToUCVAoFrHIum5GHGfDISNub3lyCCqg6CF9ieAHr9tNo9/IFH7FRmC8qyNycUsv70htc8VQJwSkgkK6SksDtJ4om7ArSVsYP8Ce6Yp8ymlbVHPiDeFsrbSB+yad6zJQ4Fz6pjwb+HEq+FkwfOZzO/yl7WVto2jFFwTRir3UehY7QzxjBWx/IcM+jt7qHtEG4EIwIDAQABAoH/Ik8AMyr5WMMOm8xCx1t0pvHdow2TD5bkNred6tOt6Tj+8sGxZYjIi58PHMB8Fq1pYbjhOEhJ5/Uk2it6zbLgNtOZWyIUXojPg72a3DDvqVZTodVRUttN0MhHREg1ssFutlHL5QshcPMZQiPeBkKFg6ReszUgenO1Au2F0Rm5GO3IJllSlU2paahisECKBaoxWkHLyNlzszTkp8E14MJoD6rDjN/5Ld6xgVsE9wf4hPcAr1D9+SqSYdWsBZnQJz3ie/vXXTnnU/LsVWZ2R0gLPhKKf2IsQgm/hCm+EMsJmWCFO8i+Kpp3+BN782WhkCl61rOFEn/yY8/lW824O1cpAoGBAMONuHLebq307F10PLAwdMy+AznEA0goPNI6qH18aXcyu6ItpNM0xuKhdEwxV8OgWNyEas8WYtwm34eSdm7koIWsEEv63IFGxxF2/SqLEs6RH0gfAlaaBR8k4BWnL/f9H17uiehgAPjpaWjGgYZHQl31SiKOp/cRkaVMVFwNasS1AoGBAMLhyc8BUKn6fFBmw9LV87JA4TUHJLNehvZHyO+WLB6mOrvsL/OhCFFEjYbVcv1cgQtnNXuWGmub3xpiQT0Y+o6xAiQf+jTjnPaAqgN8uLt6yMsPio0lT0FQKvAqKmJNnme9xY946eoO4V0BmDD6oWCpEAnREafIRLAHZ0LBqsR3AoGBAIuY39MgdmI4NYOBNtGPxdFi02qpQq6ACusIdL8f0SoGTWu4qbEcO94M47iAgOZl0QmafaTXljsShP+CzojbLLw/2GJk8oRWwkT1bESygvpzHqGdgU3RJVbWPCE4+EVPrNVX85qu7gLCnTzueAgjVn08XW/N5pm5MP+PPal46n8BAoGAG7SHwTMZqaCfrbp+WmnqREwu+B/02r80hqy75zu9N/o/3Vl9k7AwA4WwbRvJRjWxbtKUauZzCRtWw2R2i94SONj3SfV117EILo8qHGbNyHFzPFMQSnKkas+f2xbTgbgxLeRvwq7Y6lqFNXi1jzkCWkCOtCaR0P2Krk/PIVFxGo8CgYA8H0PdkkmyZHU/tIaqLbLtZFBffrt2+50BrAAO6CqfUn7E8Ma8MtzaXG6iOycy/V4zHq7jieTBXyH2W4xt2W8ButpOEE3GB6auXL4J1A+aRLHZJOd/oskcL1/JCxCgFa7wxneBC+oW8hIRYrtH3u5sWBY3BbGUXQCJMWAa9wcORQ==
15a2fc9c-f015-48d7-ba16-fbc261a2a22d	ace80f1b-a4cc-4149-b2c2-abe390f4a153	keyUse	SIG
5a66c6b8-02d8-451e-8b82-5a346404eed9	37150a25-d623-42e9-912f-d065a74ee09c	algorithm	RSA-OAEP
898ef103-e4da-4b73-b36a-f1d36b1956e7	37150a25-d623-42e9-912f-d065a74ee09c	priority	100
106c28bd-9f5f-4382-9efb-9f32ee82f435	37150a25-d623-42e9-912f-d065a74ee09c	privateKey	MIIEowIBAAKCAQEAsFsOmJSL9aAwA/WoPjX+xs5btkFko9I35asAD16ocbl8lCeliDkUqq1XP61RW4l2/jrq3Z5ih2yZ3d+EPed/V3dSPdp4A4k7dCOXmCEZfs8JLQoNUGoWE9znAd1bxxJIQCfX7onAvGBp8HllvFSZ50Kqy/BnBH26ExNe7klzM3EpCPOSdfNrxflyeWf3bPRT1/GGfdh42jCjvYZR4hFBEJoaAUM4dnqQlLApkMog/kKHkX6t36GH/5+03kJsW6bsvDJRqa0VlFba2quxG0jN/4M4WfX3VO8f7abWyk35siRNcFybSgz5gYVySvGK7+b+suI1Gg/rb51dqRfrvaJx1wIDAQABAoIBAC9DeBn0Vb4yfCvTfo+NsQZe771csTgmcsyek5mK6OHxsC2Uooxrn9pOMn/iV1eM89MWvzM963IX7PTFno9op3wtgmEJV/i6orBxiYM/+7E8k1z6wK64f8o6/b5GMP6dK7fl9bz8NidGP54vKtDaa5TLDTMy7qkJeQD7xAlgrfsu+rLCi5zozvIgCeFs2jFZJJGvGG1uNpnzdBVLHM96/YEe9slfG5x/I82OGOOGudAh8xA7lMUotJS0ggkLmZo1jkNuT2kRYT8kHNJJlMZn3tHvQY4gBRFCTLoBDDrP7VfYbNF0xuOzjWG/06dfKUCS7wdHYtrig0LH/etTZDyRRMECgYEA3NJZEX41rMrRegn/zaRd2nF/xGKZFv85JolMztKLY+nK/RjtAlJ3q91c/gspk5v/FbqHPeZvAAW81oqx/88D/zYPJA4257MFBuemsyk5U/MZ+H/rBn1P0cPzyuvrOlXufmcMsVYv/0n0pjJpk0TsYSd4CX1NU6cI7V/JFJNWMO8CgYEAzHNG3Y7LCnAuYiwHgW+wNyEDPzZ+dqqa74WCEO16XTzIHj5cjU55AcxYCBwMrmYdYsQnsjFR3yyIse/JhT4d/peAtb/UegOFxlSFrRUIHOpVQnSEgqJ1/81ELvfNfpdNPHCoHkzLh5QDdHsisHxztmgqaotd0T/f7aTDZAVt/ZkCgYAwTq//fK2/VEtJOGDGmvuRKx05WByHhGP7QzQTVsn5nI60mbxXsrTNW0rZpJV+3jSKi1jEuOF1jsvF32ebP61vKmNbjuSCAY7K+Ohl71HERL1cuJcwvz8z83sk3EGEbIIVEvQa43Dylzo3FXY1KnHPuzOuV8QP1c3FKBw0LRtA7wKBgQCnBwJ9HRxJwc5TC89x8nIPB9xkNzvn7Ic5aWQSOkD+jRqcgqwQEW0QiAXfUjMWA3y8ZK5diKdvYS2n2NNVFKNijBlt4nNO3zPaDNFMzuLa5KKU8SYUp28pdWPfzzjF1AwYdZ0Ta//XGpgcAEEd1/6cpcsJUiRqP/nMZw/t1fW++QKBgCfZYw7i0GcdXYqHJoksLQl+52FK/iLo9SMrtU7apwM/VnFt44TtN1F3w9nJExQknAtDj4DFQyvOgnqwuUtTv/lSxU10ygNT6ild4DwHzjwOim1tcBj3CzxYmJlLYq/tCkcs8JKuw3JuETLrzDBkNbKuIv5CXtU4r8hV4/RXyrr0
6db7b907-009c-4507-8168-9737089bb85f	37150a25-d623-42e9-912f-d065a74ee09c	certificate	MIICozCCAYsCBgGdHitJcjANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDDAphdHRlbmRhbmNlMB4XDTI2MDMyNDA0NDU0NloXDTM2MDMyNDA0NDcyNlowFTETMBEGA1UEAwwKYXR0ZW5kYW5jZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALBbDpiUi/WgMAP1qD41/sbOW7ZBZKPSN+WrAA9eqHG5fJQnpYg5FKqtVz+tUVuJdv466t2eYodsmd3fhD3nf1d3Uj3aeAOJO3Qjl5ghGX7PCS0KDVBqFhPc5wHdW8cSSEAn1+6JwLxgafB5ZbxUmedCqsvwZwR9uhMTXu5JczNxKQjzknXza8X5cnln92z0U9fxhn3YeNowo72GUeIRQRCaGgFDOHZ6kJSwKZDKIP5Ch5F+rd+hh/+ftN5CbFum7LwyUamtFZRW2tqrsRtIzf+DOFn191TvH+2m1spN+bIkTXBcm0oM+YGFckrxiu/m/rLiNRoP62+dXakX672icdcCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAByRTKXJg13VhLyVWYh/xRUBY8ZW219nFgHGoy8L6g7PTcUkLt6sihKubzixzasW8m2rLti/K74yjyS1ro9PP9YdR17VYMOsZOIMZ+u2qC5/9ljgPb+riaTb0aiTLTNesWOmZedvxjLQzbNcIoqxn/izjYRwslAyniUJ3j5uCtnjpJ0xdMbcWEzXJxJU5TUt4RyJKXH2YU+4+r8t4E4t2qKnob4LiQGhGkS7QZyo7QyX11aYGJByoY10A0W9Yjt/HRNEzN0Po3BpgU2ghc2qyE44jidHRwKP6gP9VZf/pi5uxGwmBOkb4uE0kcnSHgdckmgG+5aQRE+DvWQORRWKNYQ==
b886c126-6194-4165-b716-244290352f01	37150a25-d623-42e9-912f-d065a74ee09c	keyUse	ENC
03cf5680-4692-44bf-955c-169e5eecb231	ca477280-fe7a-4fd1-a319-9190bd3d1a4b	secret	wJToHKsqctXpwIEicaCP1EPSXOP6Vi6-AF161oHND81Ls_SXm6U79VZIAnAEw8DEKl4eU0ooB6bsqCHvktc4_N6ejxRiKI9_CVCBPG_oBU1U-IS3AuRdxQ4Vbsdw6-RcVciKciCmRnUBCARGLIwZijQZeMFdMpu0xre-ECNT16U
3447ca8e-1e25-4d55-941c-9e6230794005	ca477280-fe7a-4fd1-a319-9190bd3d1a4b	priority	100
12d00122-a052-43b7-a104-0cd3cf5616eb	ca477280-fe7a-4fd1-a319-9190bd3d1a4b	kid	4784ac98-40f1-486b-80f2-b24246e22e20
4164203a-f081-46be-a435-fc8fae181d06	ca477280-fe7a-4fd1-a319-9190bd3d1a4b	algorithm	HS512
2dabad0f-ae2d-47f8-970f-c7367daed09f	f428caec-bc50-4deb-b7c0-80b6d9db6fe9	allow-default-scopes	true
93f8e85d-f35d-44d9-bd72-3b7b51136de1	0145a4f9-2c87-4fca-adc4-ccd66a5722f4	allow-default-scopes	true
1b1c2bbb-aef6-4c6e-8829-c2c3157329b4	9e129a1d-6104-44e7-bf3f-54a751898b21	client-uris-must-match	true
c1541491-9a69-49e0-b464-956fd04848f1	9e129a1d-6104-44e7-bf3f-54a751898b21	host-sending-registration-request-must-match	true
ac8fe4ce-1e76-4ff9-a090-adb4b40c67b3	362f5728-a10d-4700-b560-e6ab4da27092	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
58c8909e-a7b4-4243-a420-bf9d23d030b4	362f5728-a10d-4700-b560-e6ab4da27092	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
a1f52179-71c2-477c-9944-652943cffee6	362f5728-a10d-4700-b560-e6ab4da27092	allowed-protocol-mapper-types	oidc-address-mapper
77514cd2-70d5-4b75-8a38-694203ab65d5	362f5728-a10d-4700-b560-e6ab4da27092	allowed-protocol-mapper-types	saml-role-list-mapper
7bba97a1-3987-4293-9620-52d4afeb568a	362f5728-a10d-4700-b560-e6ab4da27092	allowed-protocol-mapper-types	saml-user-attribute-mapper
a38d0d94-4dc0-459c-858f-bdd787538560	362f5728-a10d-4700-b560-e6ab4da27092	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
5361c414-9aff-49ea-a288-9c33a97a6eca	362f5728-a10d-4700-b560-e6ab4da27092	allowed-protocol-mapper-types	saml-user-property-mapper
c2d3f14b-2660-40c5-ad7e-2768d1b0736a	362f5728-a10d-4700-b560-e6ab4da27092	allowed-protocol-mapper-types	oidc-full-name-mapper
87245b1e-02fb-48d0-9457-3a0f10582d03	25b52e54-cc44-4aaf-8f52-37c6f75953bf	max-clients	200
6c409ffe-b314-4a48-9ebd-75acc202d6ce	d62007f1-910d-416e-aa85-7ee208ceea1f	allowed-protocol-mapper-types	saml-user-property-mapper
a2fdb10f-fa49-4a55-9095-17ffb9f5f70e	d62007f1-910d-416e-aa85-7ee208ceea1f	allowed-protocol-mapper-types	oidc-full-name-mapper
c845718a-27b6-42f4-97b3-636826d90d57	d62007f1-910d-416e-aa85-7ee208ceea1f	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
6ddb8166-cdf4-4ddf-9393-ba939b013fc0	d62007f1-910d-416e-aa85-7ee208ceea1f	allowed-protocol-mapper-types	oidc-address-mapper
9ffd803d-4d06-4497-8346-f14f59c9dd56	d62007f1-910d-416e-aa85-7ee208ceea1f	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
ab908a7b-9e70-4866-a49a-a651f15c9a28	d62007f1-910d-416e-aa85-7ee208ceea1f	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
5050df61-181c-4576-a201-cc7815687255	d62007f1-910d-416e-aa85-7ee208ceea1f	allowed-protocol-mapper-types	saml-role-list-mapper
e61e690e-0ddb-4278-a021-7c74573deff9	d62007f1-910d-416e-aa85-7ee208ceea1f	allowed-protocol-mapper-types	saml-user-attribute-mapper
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.composite_role (composite, child_role) FROM stdin;
8d09cc60-566c-4c44-a9db-c2657c461bb4	ba4e36fb-b098-4338-95c6-938b5eec2226
8d09cc60-566c-4c44-a9db-c2657c461bb4	6f19fb85-93c0-4e15-b7de-9f50db29cdfc
8d09cc60-566c-4c44-a9db-c2657c461bb4	618cc78a-96a9-44b3-9530-85ae3ccbb009
8d09cc60-566c-4c44-a9db-c2657c461bb4	ad2fe187-02f3-4614-b55d-d002ca88df74
8d09cc60-566c-4c44-a9db-c2657c461bb4	97a66d4c-872e-4922-9147-8933c6387f7a
8d09cc60-566c-4c44-a9db-c2657c461bb4	c469a378-87fc-4de9-bf42-9d59d90cd313
8d09cc60-566c-4c44-a9db-c2657c461bb4	f678ced1-7810-4265-803d-cf60370fe524
8d09cc60-566c-4c44-a9db-c2657c461bb4	ee80ede8-dfae-402d-b413-634df91785bf
8d09cc60-566c-4c44-a9db-c2657c461bb4	67b0420f-566c-4e0b-bd48-1c8bcb536d14
8d09cc60-566c-4c44-a9db-c2657c461bb4	41b0202d-bc04-4ebe-b0cb-23b3271e1361
8d09cc60-566c-4c44-a9db-c2657c461bb4	c4cacd4a-3301-4629-8eda-b4708a2a51c4
8d09cc60-566c-4c44-a9db-c2657c461bb4	8888784f-bb95-473e-9537-079eb9071644
8d09cc60-566c-4c44-a9db-c2657c461bb4	d99072ad-480c-4877-a190-fb6ee203076c
8d09cc60-566c-4c44-a9db-c2657c461bb4	fd7ffc17-f9c6-4760-98de-3bf4cfdb1522
8d09cc60-566c-4c44-a9db-c2657c461bb4	2243329f-922e-448e-81c9-16ad690bdfae
8d09cc60-566c-4c44-a9db-c2657c461bb4	5dd38269-2b24-4386-9d30-28580acf4ea9
8d09cc60-566c-4c44-a9db-c2657c461bb4	ee0a898f-b05d-4832-a14f-215819b8da70
8d09cc60-566c-4c44-a9db-c2657c461bb4	9963f45d-5f69-4436-a8f2-6ba50a10c0df
3fa9929b-b50a-4f0f-9a65-fc7b4332fcc3	fc8e2b32-765b-4cf7-8782-5f786a052564
97a66d4c-872e-4922-9147-8933c6387f7a	5dd38269-2b24-4386-9d30-28580acf4ea9
ad2fe187-02f3-4614-b55d-d002ca88df74	9963f45d-5f69-4436-a8f2-6ba50a10c0df
ad2fe187-02f3-4614-b55d-d002ca88df74	2243329f-922e-448e-81c9-16ad690bdfae
3fa9929b-b50a-4f0f-9a65-fc7b4332fcc3	070fa4d1-f3a4-450e-915d-3da2e77e1d8b
070fa4d1-f3a4-450e-915d-3da2e77e1d8b	68527ab5-c9ef-4631-9809-4b4efeb942a5
8d004390-c64a-4b00-812b-d00ae3772557	cb75f59c-358e-4ee9-87a9-49560f08315c
8d09cc60-566c-4c44-a9db-c2657c461bb4	8796f2fb-2b78-47e9-8c73-ed21d3e907e0
3fa9929b-b50a-4f0f-9a65-fc7b4332fcc3	cc17bb61-fcb1-4b08-adb1-50d7d12ed0ed
3fa9929b-b50a-4f0f-9a65-fc7b4332fcc3	fdbb6409-2600-4ad0-bb64-e9f13ceb723d
8d09cc60-566c-4c44-a9db-c2657c461bb4	8bb33f0f-9a84-49cc-9dcd-e3bd5ddfa52a
8d09cc60-566c-4c44-a9db-c2657c461bb4	3f09feec-a753-457a-ba74-5ad0886b3eca
8d09cc60-566c-4c44-a9db-c2657c461bb4	f7b55c16-d368-4e70-9123-91aa05f38584
8d09cc60-566c-4c44-a9db-c2657c461bb4	79897c0e-ddad-4afd-b32e-1a077313d697
8d09cc60-566c-4c44-a9db-c2657c461bb4	1a441f07-cd7c-4e59-ad31-3cc2703e4632
8d09cc60-566c-4c44-a9db-c2657c461bb4	4d6e8a1f-ad64-4cf8-a447-a4b604b0c2d2
8d09cc60-566c-4c44-a9db-c2657c461bb4	bb8c88da-d682-4566-bccb-a424d5947a63
8d09cc60-566c-4c44-a9db-c2657c461bb4	72a38988-20e2-4b57-b3bb-1dcf3b39f8bd
8d09cc60-566c-4c44-a9db-c2657c461bb4	bbfffe52-3a50-4d27-9fba-ed9eb4d29b09
8d09cc60-566c-4c44-a9db-c2657c461bb4	e7e9e6e5-6314-469e-afb9-1b5083ba2d57
8d09cc60-566c-4c44-a9db-c2657c461bb4	cfe0fc06-f40d-4214-9379-76955190d37e
8d09cc60-566c-4c44-a9db-c2657c461bb4	9ba6fe3a-d110-4963-8ee6-44e5cf449d7a
8d09cc60-566c-4c44-a9db-c2657c461bb4	5dc0b5cd-4aab-4d4f-b1af-dc386a23dc25
8d09cc60-566c-4c44-a9db-c2657c461bb4	138af772-e881-4700-8633-6382c67c62d0
8d09cc60-566c-4c44-a9db-c2657c461bb4	ca2f033a-91d9-4c7b-b18a-7c4e0fb0e2a0
8d09cc60-566c-4c44-a9db-c2657c461bb4	03b3350f-10c8-486c-a87e-146ae5451da8
8d09cc60-566c-4c44-a9db-c2657c461bb4	011e8f56-6d5e-4098-9452-50962075dbd4
79897c0e-ddad-4afd-b32e-1a077313d697	ca2f033a-91d9-4c7b-b18a-7c4e0fb0e2a0
f7b55c16-d368-4e70-9123-91aa05f38584	011e8f56-6d5e-4098-9452-50962075dbd4
f7b55c16-d368-4e70-9123-91aa05f38584	138af772-e881-4700-8633-6382c67c62d0
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	71443a2e-28d5-4733-94d6-56addc49e627
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	df3aec13-1841-46bb-8c5b-a76bdb3996bc
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	7a726e28-68bd-481c-acf4-8c2235dea87d
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	3579a427-3b67-429b-9461-b7fa94a89da8
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	4245ee15-f6ae-48ef-90f8-d30bc6d5e252
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	55e95b97-b45f-4444-a3cb-aeff75e3dd7c
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	6deb2bed-fca3-4d74-a5b1-e52c47142c77
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	53a56e94-f464-4f10-a8b0-a72e51b88b40
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	b6b487f8-709a-4730-8a56-0de7554ba41a
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	487618ea-f886-4b0c-bc0a-36e5f266e269
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	73ff1557-66e0-4497-84da-2c1d0db7acf8
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	843c6be6-b49d-4187-be40-5878b99f6295
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	27f70108-931e-41c5-b230-c646923b69bf
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	8589cd3b-6c6d-40a6-ac07-0284a1bde616
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	10f8d0d2-4325-463f-ac81-a0b3e7cc2ac9
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	49e09e45-7e7d-45b7-8a5c-ecb260f05000
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	31ddacd4-79d1-4039-972f-f77dfa0f6019
3579a427-3b67-429b-9461-b7fa94a89da8	10f8d0d2-4325-463f-ac81-a0b3e7cc2ac9
7a726e28-68bd-481c-acf4-8c2235dea87d	8589cd3b-6c6d-40a6-ac07-0284a1bde616
7a726e28-68bd-481c-acf4-8c2235dea87d	31ddacd4-79d1-4039-972f-f77dfa0f6019
f5ae953a-8a5e-417c-a285-592abc5146ae	c5d79202-22af-4817-88a6-f784fd23a03e
f5ae953a-8a5e-417c-a285-592abc5146ae	745846b4-9b47-4473-b031-e0c6fa641540
745846b4-9b47-4473-b031-e0c6fa641540	6777570f-dd0f-4aa8-a077-5d15f12b398a
596b7650-625a-41c0-a768-2c656aaebb45	632f4123-2cd4-43d9-a57a-0177911835b4
8d09cc60-566c-4c44-a9db-c2657c461bb4	91499a0b-c4ec-40bc-a776-8eba771f4983
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	b3e2e2e0-903b-4090-ae19-7b6127015077
f5ae953a-8a5e-417c-a285-592abc5146ae	6ea8aa9c-d06c-44d0-b71f-aabda6641a72
f5ae953a-8a5e-417c-a285-592abc5146ae	8831a3a7-650b-404a-9883-ea8997dc96ec
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
50896cbc-de47-4c8b-be44-b157d3c835dd	\N	password	b0dae712-f417-40ee-9546-c98c084c03e7	1774327645604	\N	{"value":"3AJG31C1p5QG8Y9SfkEntZiHLn5QPPMiHnTE7wqJ+3BkvvFQKXUMro+4zIrubJC69Uj3+5dns+VqpB2MBVDwqw==","salt":"4obroAoMzs9ubY+UOpd38Q==","additionalParameters":{}}	{"hashIterations":210000,"algorithm":"pbkdf2-sha512","additionalParameters":{}}	10
54bc661b-d5f2-4012-8ef6-8f78924f5c98	\N	password	4b7f959d-0909-438c-9087-f458de0027c1	1774327646024	\N	{"value":"vqP/JwCV/AOfDnADeoNQvujjQL1t0ql33stE0dAhP3CB816V+t+CbD714TzzQMPOYjm2nSeHDI3mpqGUvZvNLw==","salt":"zaECRxG3KzC1cYct+N9TaA==","additionalParameters":{}}	{"hashIterations":210000,"algorithm":"pbkdf2-sha512","additionalParameters":{}}	10
25ef8525-3a4c-4daf-98f4-a598bdf0f4d9	\N	password	52548f9e-606e-4e7c-88e8-b4e8cad4e0bc	1774327647260	\N	{"value":"WRmHOyzwi+ISmSPVNhR/vevvdCUskWWLdvbv+Zjl1ib2Qn7idE/2nxQifGQNM4xFmbIV1+fXz5gRZh6Mxk3SBQ==","salt":"G5LYUY3IBkMiYTY+BBOJSg==","additionalParameters":{}}	{"hashIterations":210000,"algorithm":"pbkdf2-sha512","additionalParameters":{}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2026-03-24 04:47:19.745849	1	EXECUTED	9:6f1016664e21e16d26517a4418f5e3df	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.25.1	\N	\N	4327639182
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2026-03-24 04:47:19.766414	2	MARK_RAN	9:828775b1596a07d1200ba1d49e5e3941	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.25.1	\N	\N	4327639182
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2026-03-24 04:47:19.826588	3	EXECUTED	9:5f090e44a7d595883c1fb61f4b41fd38	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.25.1	\N	\N	4327639182
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2026-03-24 04:47:19.83066	4	EXECUTED	9:c07e577387a3d2c04d1adc9aaad8730e	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.25.1	\N	\N	4327639182
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2026-03-24 04:47:19.973932	5	EXECUTED	9:b68ce996c655922dbcd2fe6b6ae72686	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.25.1	\N	\N	4327639182
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2026-03-24 04:47:19.980505	6	MARK_RAN	9:543b5c9989f024fe35c6f6c5a97de88e	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.25.1	\N	\N	4327639182
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2026-03-24 04:47:20.107554	7	EXECUTED	9:765afebbe21cf5bbca048e632df38336	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.25.1	\N	\N	4327639182
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2026-03-24 04:47:20.114033	8	MARK_RAN	9:db4a145ba11a6fdaefb397f6dbf829a1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.25.1	\N	\N	4327639182
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2026-03-24 04:47:20.120656	9	EXECUTED	9:9d05c7be10cdb873f8bcb41bc3a8ab23	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.25.1	\N	\N	4327639182
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2026-03-24 04:47:20.249119	10	EXECUTED	9:18593702353128d53111f9b1ff0b82b8	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.25.1	\N	\N	4327639182
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2026-03-24 04:47:20.320987	11	EXECUTED	9:6122efe5f090e41a85c0f1c9e52cbb62	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.25.1	\N	\N	4327639182
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2026-03-24 04:47:20.326099	12	MARK_RAN	9:e1ff28bf7568451453f844c5d54bb0b5	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.25.1	\N	\N	4327639182
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2026-03-24 04:47:20.363249	13	EXECUTED	9:7af32cd8957fbc069f796b61217483fd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.25.1	\N	\N	4327639182
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-03-24 04:47:20.388829	14	EXECUTED	9:6005e15e84714cd83226bf7879f54190	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.25.1	\N	\N	4327639182
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-03-24 04:47:20.390301	15	MARK_RAN	9:bf656f5a2b055d07f314431cae76f06c	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.25.1	\N	\N	4327639182
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-03-24 04:47:20.392905	16	MARK_RAN	9:f8dadc9284440469dcf71e25ca6ab99b	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.25.1	\N	\N	4327639182
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-03-24 04:47:20.395651	17	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.25.1	\N	\N	4327639182
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2026-03-24 04:47:20.456576	18	EXECUTED	9:3368ff0be4c2855ee2dd9ca813b38d8e	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.25.1	\N	\N	4327639182
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2026-03-24 04:47:20.514768	19	EXECUTED	9:8ac2fb5dd030b24c0570a763ed75ed20	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.25.1	\N	\N	4327639182
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2026-03-24 04:47:20.519485	20	EXECUTED	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.25.1	\N	\N	4327639182
24.0.0-9758-2	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-03-24 04:47:21.867928	119	EXECUTED	9:bf0fdee10afdf597a987adbf291db7b2	customChange		\N	4.25.1	\N	\N	4327639182
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2026-03-24 04:47:20.523117	21	MARK_RAN	9:831e82914316dc8a57dc09d755f23c51	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.25.1	\N	\N	4327639182
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2026-03-24 04:47:20.525697	22	MARK_RAN	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.25.1	\N	\N	4327639182
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2026-03-24 04:47:20.567058	23	EXECUTED	9:bc3d0f9e823a69dc21e23e94c7a94bb1	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.25.1	\N	\N	4327639182
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2026-03-24 04:47:20.573256	24	EXECUTED	9:c9999da42f543575ab790e76439a2679	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.25.1	\N	\N	4327639182
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2026-03-24 04:47:20.574586	25	MARK_RAN	9:0d6c65c6f58732d81569e77b10ba301d	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.25.1	\N	\N	4327639182
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2026-03-24 04:47:20.605515	26	EXECUTED	9:fc576660fc016ae53d2d4778d84d86d0	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.25.1	\N	\N	4327639182
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2026-03-24 04:47:20.695258	27	EXECUTED	9:43ed6b0da89ff77206289e87eaa9c024	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.25.1	\N	\N	4327639182
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2026-03-24 04:47:20.698891	28	EXECUTED	9:44bae577f551b3738740281eceb4ea70	update tableName=RESOURCE_SERVER_POLICY		\N	4.25.1	\N	\N	4327639182
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2026-03-24 04:47:20.772537	29	EXECUTED	9:bd88e1f833df0420b01e114533aee5e8	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.25.1	\N	\N	4327639182
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2026-03-24 04:47:20.79077	30	EXECUTED	9:a7022af5267f019d020edfe316ef4371	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.25.1	\N	\N	4327639182
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2026-03-24 04:47:20.814953	31	EXECUTED	9:fc155c394040654d6a79227e56f5e25a	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.25.1	\N	\N	4327639182
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2026-03-24 04:47:20.822324	32	EXECUTED	9:eac4ffb2a14795e5dc7b426063e54d88	customChange		\N	4.25.1	\N	\N	4327639182
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-03-24 04:47:20.830323	33	EXECUTED	9:54937c05672568c4c64fc9524c1e9462	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.25.1	\N	\N	4327639182
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-03-24 04:47:20.832346	34	MARK_RAN	9:3a32bace77c84d7678d035a7f5a8084e	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.25.1	\N	\N	4327639182
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-03-24 04:47:20.867101	35	EXECUTED	9:33d72168746f81f98ae3a1e8e0ca3554	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.25.1	\N	\N	4327639182
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2026-03-24 04:47:20.872621	36	EXECUTED	9:61b6d3d7a4c0e0024b0c839da283da0c	addColumn tableName=REALM		\N	4.25.1	\N	\N	4327639182
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-03-24 04:47:20.877609	37	EXECUTED	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.25.1	\N	\N	4327639182
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2026-03-24 04:47:20.881135	38	EXECUTED	9:a2b870802540cb3faa72098db5388af3	addColumn tableName=FED_USER_CONSENT		\N	4.25.1	\N	\N	4327639182
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2026-03-24 04:47:20.884653	39	EXECUTED	9:132a67499ba24bcc54fb5cbdcfe7e4c0	addColumn tableName=IDENTITY_PROVIDER		\N	4.25.1	\N	\N	4327639182
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-03-24 04:47:20.885805	40	MARK_RAN	9:938f894c032f5430f2b0fafb1a243462	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.25.1	\N	\N	4327639182
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-03-24 04:47:20.887697	41	MARK_RAN	9:845c332ff1874dc5d35974b0babf3006	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.25.1	\N	\N	4327639182
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2026-03-24 04:47:20.896108	42	EXECUTED	9:fc86359c079781adc577c5a217e4d04c	customChange		\N	4.25.1	\N	\N	4327639182
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-03-24 04:47:21.025239	43	EXECUTED	9:59a64800e3c0d09b825f8a3b444fa8f4	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.25.1	\N	\N	4327639182
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2026-03-24 04:47:21.029569	44	EXECUTED	9:d48d6da5c6ccf667807f633fe489ce88	addColumn tableName=USER_ENTITY		\N	4.25.1	\N	\N	4327639182
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-03-24 04:47:21.034751	45	EXECUTED	9:dde36f7973e80d71fceee683bc5d2951	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.25.1	\N	\N	4327639182
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-03-24 04:47:21.042634	46	EXECUTED	9:b855e9b0a406b34fa323235a0cf4f640	customChange		\N	4.25.1	\N	\N	4327639182
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-03-24 04:47:21.044157	47	MARK_RAN	9:51abbacd7b416c50c4421a8cabf7927e	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.25.1	\N	\N	4327639182
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-03-24 04:47:21.096618	48	EXECUTED	9:bdc99e567b3398bac83263d375aad143	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.25.1	\N	\N	4327639182
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-03-24 04:47:21.100621	49	EXECUTED	9:d198654156881c46bfba39abd7769e69	addColumn tableName=REALM		\N	4.25.1	\N	\N	4327639182
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2026-03-24 04:47:21.148918	50	EXECUTED	9:cfdd8736332ccdd72c5256ccb42335db	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.25.1	\N	\N	4327639182
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2026-03-24 04:47:21.177694	51	EXECUTED	9:7c84de3d9bd84d7f077607c1a4dcb714	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.25.1	\N	\N	4327639182
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2026-03-24 04:47:21.180794	52	EXECUTED	9:5a6bb36cbefb6a9d6928452c0852af2d	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2026-03-24 04:47:21.18352	53	EXECUTED	9:8f23e334dbc59f82e0a328373ca6ced0	update tableName=REALM		\N	4.25.1	\N	\N	4327639182
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2026-03-24 04:47:21.186099	54	EXECUTED	9:9156214268f09d970cdf0e1564d866af	update tableName=CLIENT		\N	4.25.1	\N	\N	4327639182
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-03-24 04:47:21.192504	55	EXECUTED	9:db806613b1ed154826c02610b7dbdf74	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.25.1	\N	\N	4327639182
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-03-24 04:47:21.203433	56	EXECUTED	9:229a041fb72d5beac76bb94a5fa709de	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.25.1	\N	\N	4327639182
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-03-24 04:47:21.229317	57	EXECUTED	9:079899dade9c1e683f26b2aa9ca6ff04	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.25.1	\N	\N	4327639182
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-03-24 04:47:21.374143	58	EXECUTED	9:139b79bcbbfe903bb1c2d2a4dbf001d9	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.25.1	\N	\N	4327639182
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2026-03-24 04:47:21.407064	59	EXECUTED	9:b55738ad889860c625ba2bf483495a04	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.25.1	\N	\N	4327639182
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2026-03-24 04:47:21.414554	60	EXECUTED	9:e0057eac39aa8fc8e09ac6cfa4ae15fe	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.25.1	\N	\N	4327639182
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2026-03-24 04:47:21.427071	61	EXECUTED	9:42a33806f3a0443fe0e7feeec821326c	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.25.1	\N	\N	4327639182
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2026-03-24 04:47:21.431967	62	EXECUTED	9:9968206fca46eecc1f51db9c024bfe56	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.25.1	\N	\N	4327639182
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2026-03-24 04:47:21.434863	63	EXECUTED	9:92143a6daea0a3f3b8f598c97ce55c3d	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.25.1	\N	\N	4327639182
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2026-03-24 04:47:21.437894	64	EXECUTED	9:82bab26a27195d889fb0429003b18f40	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.25.1	\N	\N	4327639182
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2026-03-24 04:47:21.44075	65	EXECUTED	9:e590c88ddc0b38b0ae4249bbfcb5abc3	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.25.1	\N	\N	4327639182
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2026-03-24 04:47:21.454727	66	EXECUTED	9:5c1f475536118dbdc38d5d7977950cc0	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.25.1	\N	\N	4327639182
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2026-03-24 04:47:21.45915	67	EXECUTED	9:e7c9f5f9c4d67ccbbcc215440c718a17	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.25.1	\N	\N	4327639182
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2026-03-24 04:47:21.464345	68	EXECUTED	9:88e0bfdda924690d6f4e430c53447dd5	addColumn tableName=REALM		\N	4.25.1	\N	\N	4327639182
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2026-03-24 04:47:21.477778	69	EXECUTED	9:f53177f137e1c46b6a88c59ec1cb5218	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.25.1	\N	\N	4327639182
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2026-03-24 04:47:21.482612	70	EXECUTED	9:a74d33da4dc42a37ec27121580d1459f	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.25.1	\N	\N	4327639182
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2026-03-24 04:47:21.48623	71	EXECUTED	9:fd4ade7b90c3b67fae0bfcfcb42dfb5f	addColumn tableName=RESOURCE_SERVER		\N	4.25.1	\N	\N	4327639182
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-03-24 04:47:21.494165	72	EXECUTED	9:aa072ad090bbba210d8f18781b8cebf4	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.25.1	\N	\N	4327639182
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-03-24 04:47:21.502398	73	EXECUTED	9:1ae6be29bab7c2aa376f6983b932be37	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.25.1	\N	\N	4327639182
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-03-24 04:47:21.504599	74	MARK_RAN	9:14706f286953fc9a25286dbd8fb30d97	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.25.1	\N	\N	4327639182
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-03-24 04:47:21.539284	75	EXECUTED	9:2b9cc12779be32c5b40e2e67711a218b	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.25.1	\N	\N	4327639182
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-03-24 04:47:21.546529	76	EXECUTED	9:91fa186ce7a5af127a2d7a91ee083cc5	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.25.1	\N	\N	4327639182
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-03-24 04:47:21.550242	77	EXECUTED	9:6335e5c94e83a2639ccd68dd24e2e5ad	addColumn tableName=CLIENT		\N	4.25.1	\N	\N	4327639182
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-03-24 04:47:21.551406	78	MARK_RAN	9:6bdb5658951e028bfe16fa0a8228b530	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.25.1	\N	\N	4327639182
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-03-24 04:47:21.583084	79	EXECUTED	9:d5bc15a64117ccad481ce8792d4c608f	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.25.1	\N	\N	4327639182
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-03-24 04:47:21.584626	80	MARK_RAN	9:077cba51999515f4d3e7ad5619ab592c	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.25.1	\N	\N	4327639182
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-03-24 04:47:21.590241	81	EXECUTED	9:be969f08a163bf47c6b9e9ead8ac2afb	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.25.1	\N	\N	4327639182
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-03-24 04:47:21.591294	82	MARK_RAN	9:6d3bb4408ba5a72f39bd8a0b301ec6e3	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.25.1	\N	\N	4327639182
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-03-24 04:47:21.595655	83	EXECUTED	9:966bda61e46bebf3cc39518fbed52fa7	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.25.1	\N	\N	4327639182
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-03-24 04:47:21.596723	84	MARK_RAN	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.25.1	\N	\N	4327639182
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-03-24 04:47:21.601911	85	EXECUTED	9:7d93d602352a30c0c317e6a609b56599	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.25.1	\N	\N	4327639182
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2026-03-24 04:47:21.609489	86	EXECUTED	9:71c5969e6cdd8d7b6f47cebc86d37627	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.25.1	\N	\N	4327639182
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2026-03-24 04:47:21.625971	87	EXECUTED	9:a9ba7d47f065f041b7da856a81762021	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.25.1	\N	\N	4327639182
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2026-03-24 04:47:21.634831	88	EXECUTED	9:fffabce2bc01e1a8f5110d5278500065	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.25.1	\N	\N	4327639182
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-03-24 04:47:21.643328	89	EXECUTED	9:fa8a5b5445e3857f4b010bafb5009957	addColumn tableName=REALM; customChange		\N	4.25.1	\N	\N	4327639182
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-03-24 04:47:21.65746	90	EXECUTED	9:67ac3241df9a8582d591c5ed87125f39	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.25.1	\N	\N	4327639182
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-03-24 04:47:21.662301	91	EXECUTED	9:ad1194d66c937e3ffc82386c050ba089	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.25.1	\N	\N	4327639182
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-03-24 04:47:21.679836	92	EXECUTED	9:d9be619d94af5a2f5d07b9f003543b91	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.25.1	\N	\N	4327639182
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-03-24 04:47:21.681027	93	MARK_RAN	9:544d201116a0fcc5a5da0925fbbc3bde	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.25.1	\N	\N	4327639182
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-03-24 04:47:21.694873	94	EXECUTED	9:43c0c1055b6761b4b3e89de76d612ccf	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.25.1	\N	\N	4327639182
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-03-24 04:47:21.696259	95	MARK_RAN	9:8bd711fd0330f4fe980494ca43ab1139	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.25.1	\N	\N	4327639182
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-03-24 04:47:21.702716	96	EXECUTED	9:e07d2bc0970c348bb06fb63b1f82ddbf	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.25.1	\N	\N	4327639182
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-03-24 04:47:21.712198	97	EXECUTED	9:24fb8611e97f29989bea412aa38d12b7	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.25.1	\N	\N	4327639182
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-03-24 04:47:21.713405	98	MARK_RAN	9:259f89014ce2506ee84740cbf7163aa7	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-03-24 04:47:21.726838	99	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-03-24 04:47:21.732276	100	EXECUTED	9:60ca84a0f8c94ec8c3504a5a3bc88ee8	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-03-24 04:47:21.733567	101	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-03-24 04:47:21.738969	102	EXECUTED	9:0b305d8d1277f3a89a0a53a659ad274c	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.25.1	\N	\N	4327639182
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-03-24 04:47:21.747918	103	EXECUTED	9:2c374ad2cdfe20e2905a84c8fac48460	customChange		\N	4.25.1	\N	\N	4327639182
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2026-03-24 04:47:21.754049	104	EXECUTED	9:47a760639ac597360a8219f5b768b4de	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.25.1	\N	\N	4327639182
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2026-03-24 04:47:21.758876	105	EXECUTED	9:a6272f0576727dd8cad2522335f5d99e	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.25.1	\N	\N	4327639182
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2026-03-24 04:47:21.76316	106	EXECUTED	9:015479dbd691d9cc8669282f4828c41d	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.25.1	\N	\N	4327639182
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2026-03-24 04:47:21.770104	107	EXECUTED	9:9518e495fdd22f78ad6425cc30630221	customChange		\N	4.25.1	\N	\N	4327639182
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-03-24 04:47:21.774761	108	EXECUTED	9:e5f243877199fd96bcc842f27a1656ac	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.25.1	\N	\N	4327639182
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-03-24 04:47:21.775892	109	MARK_RAN	9:1a6fcaa85e20bdeae0a9ce49b41946a5	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.25.1	\N	\N	4327639182
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-03-24 04:47:21.782886	110	EXECUTED	9:3f332e13e90739ed0c35b0b25b7822ca	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2026-03-24 04:47:21.789782	111	EXECUTED	9:7ee1f7a3fb8f5588f171fb9a6ab623c0	customChange		\N	4.25.1	\N	\N	4327639182
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2026-03-24 04:47:21.822337	112	EXECUTED	9:3d7e830b52f33676b9d64f7f2b2ea634	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.25.1	\N	\N	4327639182
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2026-03-24 04:47:21.824262	113	MARK_RAN	9:627d032e3ef2c06c0e1f73d2ae25c26c	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.25.1	\N	\N	4327639182
22.0.0-17484-updated	keycloak	META-INF/jpa-changelog-22.0.0.xml	2026-03-24 04:47:21.832164	114	EXECUTED	9:90af0bfd30cafc17b9f4d6eccd92b8b3	customChange		\N	4.25.1	\N	\N	4327639182
22.0.5-24031	keycloak	META-INF/jpa-changelog-22.0.0.xml	2026-03-24 04:47:21.833279	115	MARK_RAN	9:a60d2d7b315ec2d3eba9e2f145f9df28	customChange		\N	4.25.1	\N	\N	4327639182
23.0.0-12062	keycloak	META-INF/jpa-changelog-23.0.0.xml	2026-03-24 04:47:21.839606	116	EXECUTED	9:2168fbe728fec46ae9baf15bf80927b8	addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG		\N	4.25.1	\N	\N	4327639182
23.0.0-17258	keycloak	META-INF/jpa-changelog-23.0.0.xml	2026-03-24 04:47:21.842443	117	EXECUTED	9:36506d679a83bbfda85a27ea1864dca8	addColumn tableName=EVENT_ENTITY		\N	4.25.1	\N	\N	4327639182
24.0.0-9758	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-03-24 04:47:21.860827	118	EXECUTED	9:502c557a5189f600f0f445a9b49ebbce	addColumn tableName=USER_ATTRIBUTE; addColumn tableName=FED_USER_ATTRIBUTE; createIndex indexName=USER_ATTR_LONG_VALUES, tableName=USER_ATTRIBUTE; createIndex indexName=FED_USER_ATTR_LONG_VALUES, tableName=FED_USER_ATTRIBUTE; createIndex indexName...		\N	4.25.1	\N	\N	4327639182
24.0.0-26618-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-03-24 04:47:21.874447	120	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
24.0.0-26618-reindex	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-03-24 04:47:21.879975	121	EXECUTED	9:08707c0f0db1cef6b352db03a60edc7f	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
24.0.2-27228	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-03-24 04:47:21.887011	122	EXECUTED	9:eaee11f6b8aa25d2cc6a84fb86fc6238	customChange		\N	4.25.1	\N	\N	4327639182
24.0.2-27967-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-03-24 04:47:21.888131	123	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
24.0.2-27967-reindex	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-03-24 04:47:21.889946	124	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.25.1	\N	\N	4327639182
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
1001	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
2334ed90-f617-4b21-ad06-1f96d7b25bf2	2e097a56-9a2c-4b5c-b1b0-1a5213d9f9dc	f
2334ed90-f617-4b21-ad06-1f96d7b25bf2	affd743f-e013-41a1-9e28-46f29276c85e	t
2334ed90-f617-4b21-ad06-1f96d7b25bf2	970e8cd1-70c4-4394-8614-bbf97ff173af	t
2334ed90-f617-4b21-ad06-1f96d7b25bf2	4a28b531-8c93-4c8d-8d71-6a7f44d84c30	t
2334ed90-f617-4b21-ad06-1f96d7b25bf2	9502f7a6-0912-4226-9136-d135044a8b81	f
2334ed90-f617-4b21-ad06-1f96d7b25bf2	2f7eab35-11bb-466b-a89c-af998c736afc	f
2334ed90-f617-4b21-ad06-1f96d7b25bf2	e5710616-257d-4187-bdf8-1cc835dfac20	t
2334ed90-f617-4b21-ad06-1f96d7b25bf2	0c9c2fe1-1bcc-4e78-b010-817f54b69c20	t
2334ed90-f617-4b21-ad06-1f96d7b25bf2	a68485f5-d306-40cd-a7e8-c9f2f61b5884	f
2334ed90-f617-4b21-ad06-1f96d7b25bf2	c9130b00-7c39-4691-b27a-7661312f48c5	t
cca741d1-bc8c-4408-87d3-1831c344aac7	868548e6-46be-410e-b774-d0419c04b9c9	f
cca741d1-bc8c-4408-87d3-1831c344aac7	ced791c7-d494-43ee-9a40-b99cefbc9df3	t
cca741d1-bc8c-4408-87d3-1831c344aac7	09818233-afd4-4a3b-808e-3ac62d5592a0	t
cca741d1-bc8c-4408-87d3-1831c344aac7	a7ad064d-a335-4897-afb2-6bc6bef6ba08	t
cca741d1-bc8c-4408-87d3-1831c344aac7	facb300d-f4e2-4acc-9f74-d2d9526854e0	f
cca741d1-bc8c-4408-87d3-1831c344aac7	1a05be77-be3c-4d0d-be2c-e701f29bba39	f
cca741d1-bc8c-4408-87d3-1831c344aac7	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9	t
cca741d1-bc8c-4408-87d3-1831c344aac7	47541632-e7dc-49dd-b6a2-976ba5b14561	t
cca741d1-bc8c-4408-87d3-1831c344aac7	4cbe216b-8577-42f0-8038-b03fc82f0540	f
cca741d1-bc8c-4408-87d3-1831c344aac7	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933	t
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id, details_json_long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keycloak_group (id, name, parent_group, realm_id) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
3fa9929b-b50a-4f0f-9a65-fc7b4332fcc3	2334ed90-f617-4b21-ad06-1f96d7b25bf2	f	${role_default-roles}	default-roles-master	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N	\N
8d09cc60-566c-4c44-a9db-c2657c461bb4	2334ed90-f617-4b21-ad06-1f96d7b25bf2	f	${role_admin}	admin	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N	\N
ba4e36fb-b098-4338-95c6-938b5eec2226	2334ed90-f617-4b21-ad06-1f96d7b25bf2	f	${role_create-realm}	create-realm	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N	\N
6f19fb85-93c0-4e15-b7de-9f50db29cdfc	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_create-client}	create-client	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
618cc78a-96a9-44b3-9530-85ae3ccbb009	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_view-realm}	view-realm	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
ad2fe187-02f3-4614-b55d-d002ca88df74	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_view-users}	view-users	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
97a66d4c-872e-4922-9147-8933c6387f7a	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_view-clients}	view-clients	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
c469a378-87fc-4de9-bf42-9d59d90cd313	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_view-events}	view-events	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
f678ced1-7810-4265-803d-cf60370fe524	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_view-identity-providers}	view-identity-providers	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
ee80ede8-dfae-402d-b413-634df91785bf	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_view-authorization}	view-authorization	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
67b0420f-566c-4e0b-bd48-1c8bcb536d14	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_manage-realm}	manage-realm	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
41b0202d-bc04-4ebe-b0cb-23b3271e1361	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_manage-users}	manage-users	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
c4cacd4a-3301-4629-8eda-b4708a2a51c4	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_manage-clients}	manage-clients	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
8888784f-bb95-473e-9537-079eb9071644	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_manage-events}	manage-events	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
d99072ad-480c-4877-a190-fb6ee203076c	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_manage-identity-providers}	manage-identity-providers	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
fd7ffc17-f9c6-4760-98de-3bf4cfdb1522	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_manage-authorization}	manage-authorization	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
2243329f-922e-448e-81c9-16ad690bdfae	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_query-users}	query-users	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
5dd38269-2b24-4386-9d30-28580acf4ea9	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_query-clients}	query-clients	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
ee0a898f-b05d-4832-a14f-215819b8da70	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_query-realms}	query-realms	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
9963f45d-5f69-4436-a8f2-6ba50a10c0df	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_query-groups}	query-groups	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
fc8e2b32-765b-4cf7-8782-5f786a052564	13144151-41b0-48a2-b08f-2e88309599c9	t	${role_view-profile}	view-profile	2334ed90-f617-4b21-ad06-1f96d7b25bf2	13144151-41b0-48a2-b08f-2e88309599c9	\N
070fa4d1-f3a4-450e-915d-3da2e77e1d8b	13144151-41b0-48a2-b08f-2e88309599c9	t	${role_manage-account}	manage-account	2334ed90-f617-4b21-ad06-1f96d7b25bf2	13144151-41b0-48a2-b08f-2e88309599c9	\N
68527ab5-c9ef-4631-9809-4b4efeb942a5	13144151-41b0-48a2-b08f-2e88309599c9	t	${role_manage-account-links}	manage-account-links	2334ed90-f617-4b21-ad06-1f96d7b25bf2	13144151-41b0-48a2-b08f-2e88309599c9	\N
7057ff59-d983-4a0f-b5cd-16e8664e9cca	13144151-41b0-48a2-b08f-2e88309599c9	t	${role_view-applications}	view-applications	2334ed90-f617-4b21-ad06-1f96d7b25bf2	13144151-41b0-48a2-b08f-2e88309599c9	\N
cb75f59c-358e-4ee9-87a9-49560f08315c	13144151-41b0-48a2-b08f-2e88309599c9	t	${role_view-consent}	view-consent	2334ed90-f617-4b21-ad06-1f96d7b25bf2	13144151-41b0-48a2-b08f-2e88309599c9	\N
8d004390-c64a-4b00-812b-d00ae3772557	13144151-41b0-48a2-b08f-2e88309599c9	t	${role_manage-consent}	manage-consent	2334ed90-f617-4b21-ad06-1f96d7b25bf2	13144151-41b0-48a2-b08f-2e88309599c9	\N
c87123c9-d77c-4626-9222-4b03347de58e	13144151-41b0-48a2-b08f-2e88309599c9	t	${role_view-groups}	view-groups	2334ed90-f617-4b21-ad06-1f96d7b25bf2	13144151-41b0-48a2-b08f-2e88309599c9	\N
72c1b854-eeb2-43b6-8b4a-63846950d257	13144151-41b0-48a2-b08f-2e88309599c9	t	${role_delete-account}	delete-account	2334ed90-f617-4b21-ad06-1f96d7b25bf2	13144151-41b0-48a2-b08f-2e88309599c9	\N
8ad02f67-08d0-4c8c-ab55-8fa675accc04	74d4541e-9e12-4c82-8e58-9dce4711356f	t	${role_read-token}	read-token	2334ed90-f617-4b21-ad06-1f96d7b25bf2	74d4541e-9e12-4c82-8e58-9dce4711356f	\N
8796f2fb-2b78-47e9-8c73-ed21d3e907e0	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	t	${role_impersonation}	impersonation	2334ed90-f617-4b21-ad06-1f96d7b25bf2	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	\N
cc17bb61-fcb1-4b08-adb1-50d7d12ed0ed	2334ed90-f617-4b21-ad06-1f96d7b25bf2	f	${role_offline-access}	offline_access	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N	\N
fdbb6409-2600-4ad0-bb64-e9f13ceb723d	2334ed90-f617-4b21-ad06-1f96d7b25bf2	f	${role_uma_authorization}	uma_authorization	2334ed90-f617-4b21-ad06-1f96d7b25bf2	\N	\N
f5ae953a-8a5e-417c-a285-592abc5146ae	cca741d1-bc8c-4408-87d3-1831c344aac7	f	${role_default-roles}	default-roles-attendance	cca741d1-bc8c-4408-87d3-1831c344aac7	\N	\N
8bb33f0f-9a84-49cc-9dcd-e3bd5ddfa52a	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_create-client}	create-client	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
3f09feec-a753-457a-ba74-5ad0886b3eca	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_view-realm}	view-realm	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
f7b55c16-d368-4e70-9123-91aa05f38584	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_view-users}	view-users	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
79897c0e-ddad-4afd-b32e-1a077313d697	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_view-clients}	view-clients	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
1a441f07-cd7c-4e59-ad31-3cc2703e4632	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_view-events}	view-events	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
4d6e8a1f-ad64-4cf8-a447-a4b604b0c2d2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_view-identity-providers}	view-identity-providers	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
bb8c88da-d682-4566-bccb-a424d5947a63	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_view-authorization}	view-authorization	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
72a38988-20e2-4b57-b3bb-1dcf3b39f8bd	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_manage-realm}	manage-realm	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
bbfffe52-3a50-4d27-9fba-ed9eb4d29b09	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_manage-users}	manage-users	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
e7e9e6e5-6314-469e-afb9-1b5083ba2d57	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_manage-clients}	manage-clients	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
cfe0fc06-f40d-4214-9379-76955190d37e	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_manage-events}	manage-events	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
9ba6fe3a-d110-4963-8ee6-44e5cf449d7a	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_manage-identity-providers}	manage-identity-providers	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
5dc0b5cd-4aab-4d4f-b1af-dc386a23dc25	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_manage-authorization}	manage-authorization	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
138af772-e881-4700-8633-6382c67c62d0	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_query-users}	query-users	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
ca2f033a-91d9-4c7b-b18a-7c4e0fb0e2a0	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_query-clients}	query-clients	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
03b3350f-10c8-486c-a87e-146ae5451da8	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_query-realms}	query-realms	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
011e8f56-6d5e-4098-9452-50962075dbd4	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_query-groups}	query-groups	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
b49f5ce7-5d6b-4b03-95eb-22ce4fb53a51	fbad5179-1373-4927-950c-de3614156022	t	${role_realm-admin}	realm-admin	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
71443a2e-28d5-4733-94d6-56addc49e627	fbad5179-1373-4927-950c-de3614156022	t	${role_create-client}	create-client	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
df3aec13-1841-46bb-8c5b-a76bdb3996bc	fbad5179-1373-4927-950c-de3614156022	t	${role_view-realm}	view-realm	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
7a726e28-68bd-481c-acf4-8c2235dea87d	fbad5179-1373-4927-950c-de3614156022	t	${role_view-users}	view-users	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
3579a427-3b67-429b-9461-b7fa94a89da8	fbad5179-1373-4927-950c-de3614156022	t	${role_view-clients}	view-clients	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
4245ee15-f6ae-48ef-90f8-d30bc6d5e252	fbad5179-1373-4927-950c-de3614156022	t	${role_view-events}	view-events	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
55e95b97-b45f-4444-a3cb-aeff75e3dd7c	fbad5179-1373-4927-950c-de3614156022	t	${role_view-identity-providers}	view-identity-providers	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
6deb2bed-fca3-4d74-a5b1-e52c47142c77	fbad5179-1373-4927-950c-de3614156022	t	${role_view-authorization}	view-authorization	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
53a56e94-f464-4f10-a8b0-a72e51b88b40	fbad5179-1373-4927-950c-de3614156022	t	${role_manage-realm}	manage-realm	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
b6b487f8-709a-4730-8a56-0de7554ba41a	fbad5179-1373-4927-950c-de3614156022	t	${role_manage-users}	manage-users	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
487618ea-f886-4b0c-bc0a-36e5f266e269	fbad5179-1373-4927-950c-de3614156022	t	${role_manage-clients}	manage-clients	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
73ff1557-66e0-4497-84da-2c1d0db7acf8	fbad5179-1373-4927-950c-de3614156022	t	${role_manage-events}	manage-events	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
843c6be6-b49d-4187-be40-5878b99f6295	fbad5179-1373-4927-950c-de3614156022	t	${role_manage-identity-providers}	manage-identity-providers	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
27f70108-931e-41c5-b230-c646923b69bf	fbad5179-1373-4927-950c-de3614156022	t	${role_manage-authorization}	manage-authorization	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
8589cd3b-6c6d-40a6-ac07-0284a1bde616	fbad5179-1373-4927-950c-de3614156022	t	${role_query-users}	query-users	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
10f8d0d2-4325-463f-ac81-a0b3e7cc2ac9	fbad5179-1373-4927-950c-de3614156022	t	${role_query-clients}	query-clients	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
49e09e45-7e7d-45b7-8a5c-ecb260f05000	fbad5179-1373-4927-950c-de3614156022	t	${role_query-realms}	query-realms	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
31ddacd4-79d1-4039-972f-f77dfa0f6019	fbad5179-1373-4927-950c-de3614156022	t	${role_query-groups}	query-groups	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
c5d79202-22af-4817-88a6-f784fd23a03e	4158b612-6349-4ee8-bbe9-712e39fe3b18	t	${role_view-profile}	view-profile	cca741d1-bc8c-4408-87d3-1831c344aac7	4158b612-6349-4ee8-bbe9-712e39fe3b18	\N
745846b4-9b47-4473-b031-e0c6fa641540	4158b612-6349-4ee8-bbe9-712e39fe3b18	t	${role_manage-account}	manage-account	cca741d1-bc8c-4408-87d3-1831c344aac7	4158b612-6349-4ee8-bbe9-712e39fe3b18	\N
6777570f-dd0f-4aa8-a077-5d15f12b398a	4158b612-6349-4ee8-bbe9-712e39fe3b18	t	${role_manage-account-links}	manage-account-links	cca741d1-bc8c-4408-87d3-1831c344aac7	4158b612-6349-4ee8-bbe9-712e39fe3b18	\N
4e6e70d6-da4c-4953-b1aa-70654a2650cc	4158b612-6349-4ee8-bbe9-712e39fe3b18	t	${role_view-applications}	view-applications	cca741d1-bc8c-4408-87d3-1831c344aac7	4158b612-6349-4ee8-bbe9-712e39fe3b18	\N
632f4123-2cd4-43d9-a57a-0177911835b4	4158b612-6349-4ee8-bbe9-712e39fe3b18	t	${role_view-consent}	view-consent	cca741d1-bc8c-4408-87d3-1831c344aac7	4158b612-6349-4ee8-bbe9-712e39fe3b18	\N
596b7650-625a-41c0-a768-2c656aaebb45	4158b612-6349-4ee8-bbe9-712e39fe3b18	t	${role_manage-consent}	manage-consent	cca741d1-bc8c-4408-87d3-1831c344aac7	4158b612-6349-4ee8-bbe9-712e39fe3b18	\N
b76c8eed-3084-44b9-83cf-10fa8bb7ac7c	4158b612-6349-4ee8-bbe9-712e39fe3b18	t	${role_view-groups}	view-groups	cca741d1-bc8c-4408-87d3-1831c344aac7	4158b612-6349-4ee8-bbe9-712e39fe3b18	\N
eeade03f-aa4a-40d2-8ae2-138625e7c6f9	4158b612-6349-4ee8-bbe9-712e39fe3b18	t	${role_delete-account}	delete-account	cca741d1-bc8c-4408-87d3-1831c344aac7	4158b612-6349-4ee8-bbe9-712e39fe3b18	\N
91499a0b-c4ec-40bc-a776-8eba771f4983	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	t	${role_impersonation}	impersonation	2334ed90-f617-4b21-ad06-1f96d7b25bf2	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	\N
b3e2e2e0-903b-4090-ae19-7b6127015077	fbad5179-1373-4927-950c-de3614156022	t	${role_impersonation}	impersonation	cca741d1-bc8c-4408-87d3-1831c344aac7	fbad5179-1373-4927-950c-de3614156022	\N
7546627d-520d-4625-b9f5-fdfcaefbacdb	66e637ae-1b47-4122-976a-ce26d18f6f42	t	${role_read-token}	read-token	cca741d1-bc8c-4408-87d3-1831c344aac7	66e637ae-1b47-4122-976a-ce26d18f6f42	\N
6ea8aa9c-d06c-44d0-b71f-aabda6641a72	cca741d1-bc8c-4408-87d3-1831c344aac7	f	${role_offline-access}	offline_access	cca741d1-bc8c-4408-87d3-1831c344aac7	\N	\N
ba6cf79d-060a-4e25-8eb0-b99ce28a3ed2	cca741d1-bc8c-4408-87d3-1831c344aac7	f	System administrator	admin	cca741d1-bc8c-4408-87d3-1831c344aac7	\N	\N
4aa44bd8-c0e2-435c-88fc-2605edc312a2	cca741d1-bc8c-4408-87d3-1831c344aac7	f	HR manager	hr	cca741d1-bc8c-4408-87d3-1831c344aac7	\N	\N
9243f7f3-b19c-48f9-9f59-b4d6aa6f878a	cca741d1-bc8c-4408-87d3-1831c344aac7	f	Read-only access	viewer	cca741d1-bc8c-4408-87d3-1831c344aac7	\N	\N
8831a3a7-650b-404a-9883-ea8997dc96ec	cca741d1-bc8c-4408-87d3-1831c344aac7	f	${role_uma_authorization}	uma_authorization	cca741d1-bc8c-4408-87d3-1831c344aac7	\N	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migration_model (id, version, update_time) FROM stdin;
5zb21	24.0.2	1774327642
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
c6fd10ee-1395-466e-ad8f-abfe14ba8147	audience resolve	openid-connect	oidc-audience-resolve-mapper	3cfab432-bb34-453a-bcc5-44c5e0f5fafa	\N
dc9e659f-026b-4a3f-884d-6b43ce8026cb	locale	openid-connect	oidc-usermodel-attribute-mapper	41f6de3e-281b-45b2-968a-da1822a5deaf	\N
b9e3171a-d6a6-4fa8-af61-c4222a706a81	role list	saml	saml-role-list-mapper	\N	affd743f-e013-41a1-9e28-46f29276c85e
627291e0-4098-41d0-9839-6f99342eb4db	full name	openid-connect	oidc-full-name-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
bbae4de0-7b29-44fb-9fa5-73335bca1554	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
510a797c-d224-446c-a536-d861bb326061	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
f0b0fad0-9299-48b6-8d8f-394569a948a3	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
ad68ff27-fdd2-4220-9297-0cf8756bc781	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
e89eee10-83af-492f-82c6-5af8a1c64dee	username	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
0e95bebd-8513-451d-85a4-8db6ae636a4b	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
ace2d731-9c37-43af-8a09-ee6515a624b9	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
a9275563-5ec0-4e69-829d-74c7bcb077dd	website	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
455738d4-ee40-4a80-8b98-63152119b5d8	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
cb7008e1-f979-4c50-b578-98ee6f3ee9ad	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
8b27426a-3ee3-4103-b48d-62b6c27e09cc	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
7d471159-2b6d-416e-bac9-70b5bedfdf45	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
33b5253b-2cc5-40c6-9013-03ae193c1f0d	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	970e8cd1-70c4-4394-8614-bbf97ff173af
da66fc76-8591-45f3-98c3-e3f3e7870ee2	email	openid-connect	oidc-usermodel-attribute-mapper	\N	4a28b531-8c93-4c8d-8d71-6a7f44d84c30
2de10487-c5e2-4659-8055-af77bf2b3bcf	email verified	openid-connect	oidc-usermodel-property-mapper	\N	4a28b531-8c93-4c8d-8d71-6a7f44d84c30
eda4d095-c321-4628-9600-3bcec7c6c724	address	openid-connect	oidc-address-mapper	\N	9502f7a6-0912-4226-9136-d135044a8b81
e9785494-f5cf-4ef7-9686-83f5565ccbf3	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	2f7eab35-11bb-466b-a89c-af998c736afc
d9f4daa9-97b9-4894-a044-3eebefb040d8	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	2f7eab35-11bb-466b-a89c-af998c736afc
269edd89-8789-43c6-8ac8-b5a0cb8e0a1d	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	e5710616-257d-4187-bdf8-1cc835dfac20
269883e3-85fa-4243-9880-005a5f852e1e	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	e5710616-257d-4187-bdf8-1cc835dfac20
c7edc033-7ab3-4c61-b942-b317e75ebd76	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	e5710616-257d-4187-bdf8-1cc835dfac20
6ab079cf-669b-4c72-9164-2af8fb4848bb	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	0c9c2fe1-1bcc-4e78-b010-817f54b69c20
d7ceb089-0be6-490c-82e3-d6787e7bb23f	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	a68485f5-d306-40cd-a7e8-c9f2f61b5884
360c2b75-0836-4a61-bf05-7ceb2e2c291e	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	a68485f5-d306-40cd-a7e8-c9f2f61b5884
14ec8577-fd69-42fd-922e-d83d7b45a518	acr loa level	openid-connect	oidc-acr-mapper	\N	c9130b00-7c39-4691-b27a-7661312f48c5
7ec65e50-fa59-46f3-9f20-d51d8c57bcb5	audience resolve	openid-connect	oidc-audience-resolve-mapper	810bae0c-bd22-473d-be9f-6802d42d21f5	\N
9aed2854-7ffa-44ab-b94e-9d53cd979df5	role list	saml	saml-role-list-mapper	\N	ced791c7-d494-43ee-9a40-b99cefbc9df3
23032c8f-a7f0-40e1-9916-783c07cdf89e	full name	openid-connect	oidc-full-name-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
994b5956-7a27-4867-b19b-eb2901dd4f1a	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
d2df1536-f255-478c-9d24-46f1fb4e3a21	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
fa67625f-67ae-4fa7-8589-46c94eb6466e	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
1c394bc6-5fe2-4ee4-b9da-55234e4923cb	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
734fd66c-3bd8-4f13-9d81-2366fc9a3d99	username	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
25491dd6-5918-4ca9-bed9-6797d6fe6f16	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
d855f2f3-803d-454e-a9b0-c0586ba3913e	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
399a48d1-3a6e-4411-af5d-ae5087011b2d	website	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
8c82ccaa-fbb4-476f-b59c-345247940a34	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
4a61f140-e9c1-42da-89c9-c1a53b1c9938	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
5bf5b67b-13f1-4882-8f74-c01acd27fd75	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
81449d21-d32c-4f6f-83d4-600b50911452	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
d86d538e-4b13-4d08-89a6-949044add9fd	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	09818233-afd4-4a3b-808e-3ac62d5592a0
9486c1c0-f39d-44e2-952f-2eda6fd80c75	email	openid-connect	oidc-usermodel-attribute-mapper	\N	a7ad064d-a335-4897-afb2-6bc6bef6ba08
569e7f84-fd66-458f-a150-129f2b0c92c3	email verified	openid-connect	oidc-usermodel-property-mapper	\N	a7ad064d-a335-4897-afb2-6bc6bef6ba08
8c62aec0-50da-4e62-af64-5e382a610fce	address	openid-connect	oidc-address-mapper	\N	facb300d-f4e2-4acc-9f74-d2d9526854e0
845ee161-9a11-4154-836b-8725b1da2315	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	1a05be77-be3c-4d0d-be2c-e701f29bba39
9f63c435-edb4-46fb-ab44-eb1b4a4e4a6f	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	1a05be77-be3c-4d0d-be2c-e701f29bba39
7d15cff5-3590-4c0e-bdf9-fb6bea48026c	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9
b86eeb7e-d5cb-464d-b7df-b3b0bcb6f09d	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9
ab60d7bd-3bc3-4e24-b410-08613841b59e	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	0059cce9-c06a-4bf2-a3cd-d18cd66d17d9
4828e108-cf36-4995-8f27-b9d5f4748ba8	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	47541632-e7dc-49dd-b6a2-976ba5b14561
fc15ac46-1417-4052-953c-1dcad433db7a	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	4cbe216b-8577-42f0-8038-b03fc82f0540
ba445554-3272-45e4-9cde-15359be2b823	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	4cbe216b-8577-42f0-8038-b03fc82f0540
4730d3c7-bb0e-426f-b40e-816984a0ccd6	acr loa level	openid-connect	oidc-acr-mapper	\N	f4f2c0a9-b1ca-4588-a3f7-26a374d0d933
228ab354-18a1-4b85-8cb6-2ffcaba6931e	audience-mapper	openid-connect	oidc-audience-mapper	dc28b2f3-6250-407e-8b2d-b261f71cb6fd	\N
08e7caf9-5a7d-4d21-a01d-efe6bdbacf27	realm-roles-mapper	openid-connect	oidc-usermodel-realm-role-mapper	dc28b2f3-6250-407e-8b2d-b261f71cb6fd	\N
b7f0cad9-1303-43ea-bcca-ab50710fe049	email-mapper	openid-connect	oidc-usermodel-property-mapper	dc28b2f3-6250-407e-8b2d-b261f71cb6fd	\N
8c33c6a5-bbce-4a1b-8113-42bc05d40f54	full-name-mapper	openid-connect	oidc-full-name-mapper	dc28b2f3-6250-407e-8b2d-b261f71cb6fd	\N
1e5816ce-576f-4486-8d56-32470d5929aa	locale	openid-connect	oidc-usermodel-attribute-mapper	bc5d5436-458e-43ce-b6ad-f300b9132ed1	\N
ce92c5f3-0099-4981-ab20-18a3777db358	tenant_id	openid-connect	oidc-hardcoded-claim-mapper	dc28b2f3-6250-407e-8b2d-b261f71cb6fd	\N
0dd44e27-7bf3-40f3-a892-62eb092d28d1	customer_id	openid-connect	oidc-hardcoded-claim-mapper	dc28b2f3-6250-407e-8b2d-b261f71cb6fd	\N
5ec38456-45a4-4f87-84fb-29f3db1eeed3	site_id	openid-connect	oidc-hardcoded-claim-mapper	dc28b2f3-6250-407e-8b2d-b261f71cb6fd	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
dc9e659f-026b-4a3f-884d-6b43ce8026cb	true	introspection.token.claim
dc9e659f-026b-4a3f-884d-6b43ce8026cb	true	userinfo.token.claim
dc9e659f-026b-4a3f-884d-6b43ce8026cb	locale	user.attribute
dc9e659f-026b-4a3f-884d-6b43ce8026cb	true	id.token.claim
dc9e659f-026b-4a3f-884d-6b43ce8026cb	true	access.token.claim
dc9e659f-026b-4a3f-884d-6b43ce8026cb	locale	claim.name
dc9e659f-026b-4a3f-884d-6b43ce8026cb	String	jsonType.label
b9e3171a-d6a6-4fa8-af61-c4222a706a81	false	single
b9e3171a-d6a6-4fa8-af61-c4222a706a81	Basic	attribute.nameformat
b9e3171a-d6a6-4fa8-af61-c4222a706a81	Role	attribute.name
0e95bebd-8513-451d-85a4-8db6ae636a4b	true	introspection.token.claim
0e95bebd-8513-451d-85a4-8db6ae636a4b	true	userinfo.token.claim
0e95bebd-8513-451d-85a4-8db6ae636a4b	profile	user.attribute
0e95bebd-8513-451d-85a4-8db6ae636a4b	true	id.token.claim
0e95bebd-8513-451d-85a4-8db6ae636a4b	true	access.token.claim
0e95bebd-8513-451d-85a4-8db6ae636a4b	profile	claim.name
0e95bebd-8513-451d-85a4-8db6ae636a4b	String	jsonType.label
33b5253b-2cc5-40c6-9013-03ae193c1f0d	true	introspection.token.claim
33b5253b-2cc5-40c6-9013-03ae193c1f0d	true	userinfo.token.claim
33b5253b-2cc5-40c6-9013-03ae193c1f0d	updatedAt	user.attribute
33b5253b-2cc5-40c6-9013-03ae193c1f0d	true	id.token.claim
33b5253b-2cc5-40c6-9013-03ae193c1f0d	true	access.token.claim
33b5253b-2cc5-40c6-9013-03ae193c1f0d	updated_at	claim.name
33b5253b-2cc5-40c6-9013-03ae193c1f0d	long	jsonType.label
455738d4-ee40-4a80-8b98-63152119b5d8	true	introspection.token.claim
455738d4-ee40-4a80-8b98-63152119b5d8	true	userinfo.token.claim
455738d4-ee40-4a80-8b98-63152119b5d8	gender	user.attribute
455738d4-ee40-4a80-8b98-63152119b5d8	true	id.token.claim
455738d4-ee40-4a80-8b98-63152119b5d8	true	access.token.claim
455738d4-ee40-4a80-8b98-63152119b5d8	gender	claim.name
455738d4-ee40-4a80-8b98-63152119b5d8	String	jsonType.label
510a797c-d224-446c-a536-d861bb326061	true	introspection.token.claim
510a797c-d224-446c-a536-d861bb326061	true	userinfo.token.claim
510a797c-d224-446c-a536-d861bb326061	firstName	user.attribute
510a797c-d224-446c-a536-d861bb326061	true	id.token.claim
510a797c-d224-446c-a536-d861bb326061	true	access.token.claim
510a797c-d224-446c-a536-d861bb326061	given_name	claim.name
510a797c-d224-446c-a536-d861bb326061	String	jsonType.label
627291e0-4098-41d0-9839-6f99342eb4db	true	introspection.token.claim
627291e0-4098-41d0-9839-6f99342eb4db	true	userinfo.token.claim
627291e0-4098-41d0-9839-6f99342eb4db	true	id.token.claim
627291e0-4098-41d0-9839-6f99342eb4db	true	access.token.claim
7d471159-2b6d-416e-bac9-70b5bedfdf45	true	introspection.token.claim
7d471159-2b6d-416e-bac9-70b5bedfdf45	true	userinfo.token.claim
7d471159-2b6d-416e-bac9-70b5bedfdf45	locale	user.attribute
7d471159-2b6d-416e-bac9-70b5bedfdf45	true	id.token.claim
7d471159-2b6d-416e-bac9-70b5bedfdf45	true	access.token.claim
7d471159-2b6d-416e-bac9-70b5bedfdf45	locale	claim.name
7d471159-2b6d-416e-bac9-70b5bedfdf45	String	jsonType.label
8b27426a-3ee3-4103-b48d-62b6c27e09cc	true	introspection.token.claim
8b27426a-3ee3-4103-b48d-62b6c27e09cc	true	userinfo.token.claim
8b27426a-3ee3-4103-b48d-62b6c27e09cc	zoneinfo	user.attribute
8b27426a-3ee3-4103-b48d-62b6c27e09cc	true	id.token.claim
8b27426a-3ee3-4103-b48d-62b6c27e09cc	true	access.token.claim
8b27426a-3ee3-4103-b48d-62b6c27e09cc	zoneinfo	claim.name
8b27426a-3ee3-4103-b48d-62b6c27e09cc	String	jsonType.label
a9275563-5ec0-4e69-829d-74c7bcb077dd	true	introspection.token.claim
a9275563-5ec0-4e69-829d-74c7bcb077dd	true	userinfo.token.claim
a9275563-5ec0-4e69-829d-74c7bcb077dd	website	user.attribute
a9275563-5ec0-4e69-829d-74c7bcb077dd	true	id.token.claim
a9275563-5ec0-4e69-829d-74c7bcb077dd	true	access.token.claim
a9275563-5ec0-4e69-829d-74c7bcb077dd	website	claim.name
a9275563-5ec0-4e69-829d-74c7bcb077dd	String	jsonType.label
ace2d731-9c37-43af-8a09-ee6515a624b9	true	introspection.token.claim
ace2d731-9c37-43af-8a09-ee6515a624b9	true	userinfo.token.claim
ace2d731-9c37-43af-8a09-ee6515a624b9	picture	user.attribute
ace2d731-9c37-43af-8a09-ee6515a624b9	true	id.token.claim
ace2d731-9c37-43af-8a09-ee6515a624b9	true	access.token.claim
ace2d731-9c37-43af-8a09-ee6515a624b9	picture	claim.name
ace2d731-9c37-43af-8a09-ee6515a624b9	String	jsonType.label
ad68ff27-fdd2-4220-9297-0cf8756bc781	true	introspection.token.claim
ad68ff27-fdd2-4220-9297-0cf8756bc781	true	userinfo.token.claim
ad68ff27-fdd2-4220-9297-0cf8756bc781	nickname	user.attribute
ad68ff27-fdd2-4220-9297-0cf8756bc781	true	id.token.claim
ad68ff27-fdd2-4220-9297-0cf8756bc781	true	access.token.claim
ad68ff27-fdd2-4220-9297-0cf8756bc781	nickname	claim.name
ad68ff27-fdd2-4220-9297-0cf8756bc781	String	jsonType.label
bbae4de0-7b29-44fb-9fa5-73335bca1554	true	introspection.token.claim
bbae4de0-7b29-44fb-9fa5-73335bca1554	true	userinfo.token.claim
bbae4de0-7b29-44fb-9fa5-73335bca1554	lastName	user.attribute
bbae4de0-7b29-44fb-9fa5-73335bca1554	true	id.token.claim
bbae4de0-7b29-44fb-9fa5-73335bca1554	true	access.token.claim
bbae4de0-7b29-44fb-9fa5-73335bca1554	family_name	claim.name
bbae4de0-7b29-44fb-9fa5-73335bca1554	String	jsonType.label
cb7008e1-f979-4c50-b578-98ee6f3ee9ad	true	introspection.token.claim
cb7008e1-f979-4c50-b578-98ee6f3ee9ad	true	userinfo.token.claim
cb7008e1-f979-4c50-b578-98ee6f3ee9ad	birthdate	user.attribute
cb7008e1-f979-4c50-b578-98ee6f3ee9ad	true	id.token.claim
cb7008e1-f979-4c50-b578-98ee6f3ee9ad	true	access.token.claim
cb7008e1-f979-4c50-b578-98ee6f3ee9ad	birthdate	claim.name
cb7008e1-f979-4c50-b578-98ee6f3ee9ad	String	jsonType.label
e89eee10-83af-492f-82c6-5af8a1c64dee	true	introspection.token.claim
e89eee10-83af-492f-82c6-5af8a1c64dee	true	userinfo.token.claim
e89eee10-83af-492f-82c6-5af8a1c64dee	username	user.attribute
e89eee10-83af-492f-82c6-5af8a1c64dee	true	id.token.claim
e89eee10-83af-492f-82c6-5af8a1c64dee	true	access.token.claim
e89eee10-83af-492f-82c6-5af8a1c64dee	preferred_username	claim.name
e89eee10-83af-492f-82c6-5af8a1c64dee	String	jsonType.label
f0b0fad0-9299-48b6-8d8f-394569a948a3	true	introspection.token.claim
f0b0fad0-9299-48b6-8d8f-394569a948a3	true	userinfo.token.claim
f0b0fad0-9299-48b6-8d8f-394569a948a3	middleName	user.attribute
f0b0fad0-9299-48b6-8d8f-394569a948a3	true	id.token.claim
f0b0fad0-9299-48b6-8d8f-394569a948a3	true	access.token.claim
f0b0fad0-9299-48b6-8d8f-394569a948a3	middle_name	claim.name
f0b0fad0-9299-48b6-8d8f-394569a948a3	String	jsonType.label
2de10487-c5e2-4659-8055-af77bf2b3bcf	true	introspection.token.claim
2de10487-c5e2-4659-8055-af77bf2b3bcf	true	userinfo.token.claim
2de10487-c5e2-4659-8055-af77bf2b3bcf	emailVerified	user.attribute
2de10487-c5e2-4659-8055-af77bf2b3bcf	true	id.token.claim
2de10487-c5e2-4659-8055-af77bf2b3bcf	true	access.token.claim
2de10487-c5e2-4659-8055-af77bf2b3bcf	email_verified	claim.name
2de10487-c5e2-4659-8055-af77bf2b3bcf	boolean	jsonType.label
da66fc76-8591-45f3-98c3-e3f3e7870ee2	true	introspection.token.claim
da66fc76-8591-45f3-98c3-e3f3e7870ee2	true	userinfo.token.claim
da66fc76-8591-45f3-98c3-e3f3e7870ee2	email	user.attribute
da66fc76-8591-45f3-98c3-e3f3e7870ee2	true	id.token.claim
da66fc76-8591-45f3-98c3-e3f3e7870ee2	true	access.token.claim
da66fc76-8591-45f3-98c3-e3f3e7870ee2	email	claim.name
da66fc76-8591-45f3-98c3-e3f3e7870ee2	String	jsonType.label
eda4d095-c321-4628-9600-3bcec7c6c724	formatted	user.attribute.formatted
eda4d095-c321-4628-9600-3bcec7c6c724	country	user.attribute.country
eda4d095-c321-4628-9600-3bcec7c6c724	true	introspection.token.claim
eda4d095-c321-4628-9600-3bcec7c6c724	postal_code	user.attribute.postal_code
eda4d095-c321-4628-9600-3bcec7c6c724	true	userinfo.token.claim
eda4d095-c321-4628-9600-3bcec7c6c724	street	user.attribute.street
eda4d095-c321-4628-9600-3bcec7c6c724	true	id.token.claim
eda4d095-c321-4628-9600-3bcec7c6c724	region	user.attribute.region
eda4d095-c321-4628-9600-3bcec7c6c724	true	access.token.claim
eda4d095-c321-4628-9600-3bcec7c6c724	locality	user.attribute.locality
d9f4daa9-97b9-4894-a044-3eebefb040d8	true	introspection.token.claim
d9f4daa9-97b9-4894-a044-3eebefb040d8	true	userinfo.token.claim
d9f4daa9-97b9-4894-a044-3eebefb040d8	phoneNumberVerified	user.attribute
d9f4daa9-97b9-4894-a044-3eebefb040d8	true	id.token.claim
d9f4daa9-97b9-4894-a044-3eebefb040d8	true	access.token.claim
d9f4daa9-97b9-4894-a044-3eebefb040d8	phone_number_verified	claim.name
d9f4daa9-97b9-4894-a044-3eebefb040d8	boolean	jsonType.label
e9785494-f5cf-4ef7-9686-83f5565ccbf3	true	introspection.token.claim
e9785494-f5cf-4ef7-9686-83f5565ccbf3	true	userinfo.token.claim
e9785494-f5cf-4ef7-9686-83f5565ccbf3	phoneNumber	user.attribute
e9785494-f5cf-4ef7-9686-83f5565ccbf3	true	id.token.claim
e9785494-f5cf-4ef7-9686-83f5565ccbf3	true	access.token.claim
e9785494-f5cf-4ef7-9686-83f5565ccbf3	phone_number	claim.name
e9785494-f5cf-4ef7-9686-83f5565ccbf3	String	jsonType.label
269883e3-85fa-4243-9880-005a5f852e1e	true	introspection.token.claim
269883e3-85fa-4243-9880-005a5f852e1e	true	multivalued
269883e3-85fa-4243-9880-005a5f852e1e	foo	user.attribute
269883e3-85fa-4243-9880-005a5f852e1e	true	access.token.claim
269883e3-85fa-4243-9880-005a5f852e1e	resource_access.${client_id}.roles	claim.name
269883e3-85fa-4243-9880-005a5f852e1e	String	jsonType.label
269edd89-8789-43c6-8ac8-b5a0cb8e0a1d	true	introspection.token.claim
269edd89-8789-43c6-8ac8-b5a0cb8e0a1d	true	multivalued
269edd89-8789-43c6-8ac8-b5a0cb8e0a1d	foo	user.attribute
269edd89-8789-43c6-8ac8-b5a0cb8e0a1d	true	access.token.claim
269edd89-8789-43c6-8ac8-b5a0cb8e0a1d	realm_access.roles	claim.name
269edd89-8789-43c6-8ac8-b5a0cb8e0a1d	String	jsonType.label
c7edc033-7ab3-4c61-b942-b317e75ebd76	true	introspection.token.claim
c7edc033-7ab3-4c61-b942-b317e75ebd76	true	access.token.claim
6ab079cf-669b-4c72-9164-2af8fb4848bb	true	introspection.token.claim
6ab079cf-669b-4c72-9164-2af8fb4848bb	true	access.token.claim
360c2b75-0836-4a61-bf05-7ceb2e2c291e	true	introspection.token.claim
360c2b75-0836-4a61-bf05-7ceb2e2c291e	true	multivalued
360c2b75-0836-4a61-bf05-7ceb2e2c291e	foo	user.attribute
360c2b75-0836-4a61-bf05-7ceb2e2c291e	true	id.token.claim
360c2b75-0836-4a61-bf05-7ceb2e2c291e	true	access.token.claim
360c2b75-0836-4a61-bf05-7ceb2e2c291e	groups	claim.name
360c2b75-0836-4a61-bf05-7ceb2e2c291e	String	jsonType.label
d7ceb089-0be6-490c-82e3-d6787e7bb23f	true	introspection.token.claim
d7ceb089-0be6-490c-82e3-d6787e7bb23f	true	userinfo.token.claim
d7ceb089-0be6-490c-82e3-d6787e7bb23f	username	user.attribute
d7ceb089-0be6-490c-82e3-d6787e7bb23f	true	id.token.claim
d7ceb089-0be6-490c-82e3-d6787e7bb23f	true	access.token.claim
d7ceb089-0be6-490c-82e3-d6787e7bb23f	upn	claim.name
d7ceb089-0be6-490c-82e3-d6787e7bb23f	String	jsonType.label
14ec8577-fd69-42fd-922e-d83d7b45a518	true	introspection.token.claim
14ec8577-fd69-42fd-922e-d83d7b45a518	true	id.token.claim
14ec8577-fd69-42fd-922e-d83d7b45a518	true	access.token.claim
9aed2854-7ffa-44ab-b94e-9d53cd979df5	false	single
9aed2854-7ffa-44ab-b94e-9d53cd979df5	Basic	attribute.nameformat
9aed2854-7ffa-44ab-b94e-9d53cd979df5	Role	attribute.name
1c394bc6-5fe2-4ee4-b9da-55234e4923cb	true	introspection.token.claim
1c394bc6-5fe2-4ee4-b9da-55234e4923cb	true	userinfo.token.claim
1c394bc6-5fe2-4ee4-b9da-55234e4923cb	nickname	user.attribute
1c394bc6-5fe2-4ee4-b9da-55234e4923cb	true	id.token.claim
1c394bc6-5fe2-4ee4-b9da-55234e4923cb	true	access.token.claim
1c394bc6-5fe2-4ee4-b9da-55234e4923cb	nickname	claim.name
1c394bc6-5fe2-4ee4-b9da-55234e4923cb	String	jsonType.label
23032c8f-a7f0-40e1-9916-783c07cdf89e	true	introspection.token.claim
23032c8f-a7f0-40e1-9916-783c07cdf89e	true	userinfo.token.claim
23032c8f-a7f0-40e1-9916-783c07cdf89e	true	id.token.claim
23032c8f-a7f0-40e1-9916-783c07cdf89e	true	access.token.claim
25491dd6-5918-4ca9-bed9-6797d6fe6f16	true	introspection.token.claim
25491dd6-5918-4ca9-bed9-6797d6fe6f16	true	userinfo.token.claim
25491dd6-5918-4ca9-bed9-6797d6fe6f16	profile	user.attribute
25491dd6-5918-4ca9-bed9-6797d6fe6f16	true	id.token.claim
25491dd6-5918-4ca9-bed9-6797d6fe6f16	true	access.token.claim
25491dd6-5918-4ca9-bed9-6797d6fe6f16	profile	claim.name
25491dd6-5918-4ca9-bed9-6797d6fe6f16	String	jsonType.label
399a48d1-3a6e-4411-af5d-ae5087011b2d	true	introspection.token.claim
399a48d1-3a6e-4411-af5d-ae5087011b2d	true	userinfo.token.claim
399a48d1-3a6e-4411-af5d-ae5087011b2d	website	user.attribute
399a48d1-3a6e-4411-af5d-ae5087011b2d	true	id.token.claim
399a48d1-3a6e-4411-af5d-ae5087011b2d	true	access.token.claim
399a48d1-3a6e-4411-af5d-ae5087011b2d	website	claim.name
399a48d1-3a6e-4411-af5d-ae5087011b2d	String	jsonType.label
4a61f140-e9c1-42da-89c9-c1a53b1c9938	true	introspection.token.claim
4a61f140-e9c1-42da-89c9-c1a53b1c9938	true	userinfo.token.claim
4a61f140-e9c1-42da-89c9-c1a53b1c9938	birthdate	user.attribute
4a61f140-e9c1-42da-89c9-c1a53b1c9938	true	id.token.claim
4a61f140-e9c1-42da-89c9-c1a53b1c9938	true	access.token.claim
4a61f140-e9c1-42da-89c9-c1a53b1c9938	birthdate	claim.name
4a61f140-e9c1-42da-89c9-c1a53b1c9938	String	jsonType.label
5bf5b67b-13f1-4882-8f74-c01acd27fd75	true	introspection.token.claim
5bf5b67b-13f1-4882-8f74-c01acd27fd75	true	userinfo.token.claim
5bf5b67b-13f1-4882-8f74-c01acd27fd75	zoneinfo	user.attribute
5bf5b67b-13f1-4882-8f74-c01acd27fd75	true	id.token.claim
5bf5b67b-13f1-4882-8f74-c01acd27fd75	true	access.token.claim
5bf5b67b-13f1-4882-8f74-c01acd27fd75	zoneinfo	claim.name
5bf5b67b-13f1-4882-8f74-c01acd27fd75	String	jsonType.label
734fd66c-3bd8-4f13-9d81-2366fc9a3d99	true	introspection.token.claim
734fd66c-3bd8-4f13-9d81-2366fc9a3d99	true	userinfo.token.claim
734fd66c-3bd8-4f13-9d81-2366fc9a3d99	username	user.attribute
734fd66c-3bd8-4f13-9d81-2366fc9a3d99	true	id.token.claim
734fd66c-3bd8-4f13-9d81-2366fc9a3d99	true	access.token.claim
734fd66c-3bd8-4f13-9d81-2366fc9a3d99	preferred_username	claim.name
734fd66c-3bd8-4f13-9d81-2366fc9a3d99	String	jsonType.label
81449d21-d32c-4f6f-83d4-600b50911452	true	introspection.token.claim
81449d21-d32c-4f6f-83d4-600b50911452	true	userinfo.token.claim
81449d21-d32c-4f6f-83d4-600b50911452	locale	user.attribute
81449d21-d32c-4f6f-83d4-600b50911452	true	id.token.claim
81449d21-d32c-4f6f-83d4-600b50911452	true	access.token.claim
81449d21-d32c-4f6f-83d4-600b50911452	locale	claim.name
81449d21-d32c-4f6f-83d4-600b50911452	String	jsonType.label
8c82ccaa-fbb4-476f-b59c-345247940a34	true	introspection.token.claim
8c82ccaa-fbb4-476f-b59c-345247940a34	true	userinfo.token.claim
8c82ccaa-fbb4-476f-b59c-345247940a34	gender	user.attribute
8c82ccaa-fbb4-476f-b59c-345247940a34	true	id.token.claim
8c82ccaa-fbb4-476f-b59c-345247940a34	true	access.token.claim
8c82ccaa-fbb4-476f-b59c-345247940a34	gender	claim.name
8c82ccaa-fbb4-476f-b59c-345247940a34	String	jsonType.label
994b5956-7a27-4867-b19b-eb2901dd4f1a	true	introspection.token.claim
994b5956-7a27-4867-b19b-eb2901dd4f1a	true	userinfo.token.claim
994b5956-7a27-4867-b19b-eb2901dd4f1a	lastName	user.attribute
994b5956-7a27-4867-b19b-eb2901dd4f1a	true	id.token.claim
994b5956-7a27-4867-b19b-eb2901dd4f1a	true	access.token.claim
994b5956-7a27-4867-b19b-eb2901dd4f1a	family_name	claim.name
994b5956-7a27-4867-b19b-eb2901dd4f1a	String	jsonType.label
d2df1536-f255-478c-9d24-46f1fb4e3a21	true	introspection.token.claim
d2df1536-f255-478c-9d24-46f1fb4e3a21	true	userinfo.token.claim
d2df1536-f255-478c-9d24-46f1fb4e3a21	firstName	user.attribute
d2df1536-f255-478c-9d24-46f1fb4e3a21	true	id.token.claim
d2df1536-f255-478c-9d24-46f1fb4e3a21	true	access.token.claim
d2df1536-f255-478c-9d24-46f1fb4e3a21	given_name	claim.name
d2df1536-f255-478c-9d24-46f1fb4e3a21	String	jsonType.label
d855f2f3-803d-454e-a9b0-c0586ba3913e	true	introspection.token.claim
d855f2f3-803d-454e-a9b0-c0586ba3913e	true	userinfo.token.claim
d855f2f3-803d-454e-a9b0-c0586ba3913e	picture	user.attribute
d855f2f3-803d-454e-a9b0-c0586ba3913e	true	id.token.claim
d855f2f3-803d-454e-a9b0-c0586ba3913e	true	access.token.claim
d855f2f3-803d-454e-a9b0-c0586ba3913e	picture	claim.name
d855f2f3-803d-454e-a9b0-c0586ba3913e	String	jsonType.label
d86d538e-4b13-4d08-89a6-949044add9fd	true	introspection.token.claim
d86d538e-4b13-4d08-89a6-949044add9fd	true	userinfo.token.claim
d86d538e-4b13-4d08-89a6-949044add9fd	updatedAt	user.attribute
d86d538e-4b13-4d08-89a6-949044add9fd	true	id.token.claim
d86d538e-4b13-4d08-89a6-949044add9fd	true	access.token.claim
d86d538e-4b13-4d08-89a6-949044add9fd	updated_at	claim.name
d86d538e-4b13-4d08-89a6-949044add9fd	long	jsonType.label
fa67625f-67ae-4fa7-8589-46c94eb6466e	true	introspection.token.claim
fa67625f-67ae-4fa7-8589-46c94eb6466e	true	userinfo.token.claim
fa67625f-67ae-4fa7-8589-46c94eb6466e	middleName	user.attribute
fa67625f-67ae-4fa7-8589-46c94eb6466e	true	id.token.claim
fa67625f-67ae-4fa7-8589-46c94eb6466e	true	access.token.claim
fa67625f-67ae-4fa7-8589-46c94eb6466e	middle_name	claim.name
fa67625f-67ae-4fa7-8589-46c94eb6466e	String	jsonType.label
569e7f84-fd66-458f-a150-129f2b0c92c3	true	introspection.token.claim
569e7f84-fd66-458f-a150-129f2b0c92c3	true	userinfo.token.claim
569e7f84-fd66-458f-a150-129f2b0c92c3	emailVerified	user.attribute
569e7f84-fd66-458f-a150-129f2b0c92c3	true	id.token.claim
569e7f84-fd66-458f-a150-129f2b0c92c3	true	access.token.claim
569e7f84-fd66-458f-a150-129f2b0c92c3	email_verified	claim.name
569e7f84-fd66-458f-a150-129f2b0c92c3	boolean	jsonType.label
9486c1c0-f39d-44e2-952f-2eda6fd80c75	true	introspection.token.claim
9486c1c0-f39d-44e2-952f-2eda6fd80c75	true	userinfo.token.claim
9486c1c0-f39d-44e2-952f-2eda6fd80c75	email	user.attribute
9486c1c0-f39d-44e2-952f-2eda6fd80c75	true	id.token.claim
9486c1c0-f39d-44e2-952f-2eda6fd80c75	true	access.token.claim
9486c1c0-f39d-44e2-952f-2eda6fd80c75	email	claim.name
9486c1c0-f39d-44e2-952f-2eda6fd80c75	String	jsonType.label
8c62aec0-50da-4e62-af64-5e382a610fce	formatted	user.attribute.formatted
8c62aec0-50da-4e62-af64-5e382a610fce	country	user.attribute.country
8c62aec0-50da-4e62-af64-5e382a610fce	true	introspection.token.claim
8c62aec0-50da-4e62-af64-5e382a610fce	postal_code	user.attribute.postal_code
8c62aec0-50da-4e62-af64-5e382a610fce	true	userinfo.token.claim
8c62aec0-50da-4e62-af64-5e382a610fce	street	user.attribute.street
8c62aec0-50da-4e62-af64-5e382a610fce	true	id.token.claim
8c62aec0-50da-4e62-af64-5e382a610fce	region	user.attribute.region
8c62aec0-50da-4e62-af64-5e382a610fce	true	access.token.claim
8c62aec0-50da-4e62-af64-5e382a610fce	locality	user.attribute.locality
845ee161-9a11-4154-836b-8725b1da2315	true	introspection.token.claim
845ee161-9a11-4154-836b-8725b1da2315	true	userinfo.token.claim
845ee161-9a11-4154-836b-8725b1da2315	phoneNumber	user.attribute
845ee161-9a11-4154-836b-8725b1da2315	true	id.token.claim
845ee161-9a11-4154-836b-8725b1da2315	true	access.token.claim
845ee161-9a11-4154-836b-8725b1da2315	phone_number	claim.name
845ee161-9a11-4154-836b-8725b1da2315	String	jsonType.label
9f63c435-edb4-46fb-ab44-eb1b4a4e4a6f	true	introspection.token.claim
9f63c435-edb4-46fb-ab44-eb1b4a4e4a6f	true	userinfo.token.claim
9f63c435-edb4-46fb-ab44-eb1b4a4e4a6f	phoneNumberVerified	user.attribute
9f63c435-edb4-46fb-ab44-eb1b4a4e4a6f	true	id.token.claim
9f63c435-edb4-46fb-ab44-eb1b4a4e4a6f	true	access.token.claim
9f63c435-edb4-46fb-ab44-eb1b4a4e4a6f	phone_number_verified	claim.name
9f63c435-edb4-46fb-ab44-eb1b4a4e4a6f	boolean	jsonType.label
7d15cff5-3590-4c0e-bdf9-fb6bea48026c	true	introspection.token.claim
7d15cff5-3590-4c0e-bdf9-fb6bea48026c	true	multivalued
7d15cff5-3590-4c0e-bdf9-fb6bea48026c	foo	user.attribute
7d15cff5-3590-4c0e-bdf9-fb6bea48026c	true	access.token.claim
7d15cff5-3590-4c0e-bdf9-fb6bea48026c	realm_access.roles	claim.name
7d15cff5-3590-4c0e-bdf9-fb6bea48026c	String	jsonType.label
ab60d7bd-3bc3-4e24-b410-08613841b59e	true	introspection.token.claim
ab60d7bd-3bc3-4e24-b410-08613841b59e	true	access.token.claim
b86eeb7e-d5cb-464d-b7df-b3b0bcb6f09d	true	introspection.token.claim
b86eeb7e-d5cb-464d-b7df-b3b0bcb6f09d	true	multivalued
b86eeb7e-d5cb-464d-b7df-b3b0bcb6f09d	foo	user.attribute
b86eeb7e-d5cb-464d-b7df-b3b0bcb6f09d	true	access.token.claim
b86eeb7e-d5cb-464d-b7df-b3b0bcb6f09d	resource_access.${client_id}.roles	claim.name
b86eeb7e-d5cb-464d-b7df-b3b0bcb6f09d	String	jsonType.label
4828e108-cf36-4995-8f27-b9d5f4748ba8	true	introspection.token.claim
4828e108-cf36-4995-8f27-b9d5f4748ba8	true	access.token.claim
ba445554-3272-45e4-9cde-15359be2b823	true	introspection.token.claim
ba445554-3272-45e4-9cde-15359be2b823	true	multivalued
ba445554-3272-45e4-9cde-15359be2b823	foo	user.attribute
ba445554-3272-45e4-9cde-15359be2b823	true	id.token.claim
ba445554-3272-45e4-9cde-15359be2b823	true	access.token.claim
ba445554-3272-45e4-9cde-15359be2b823	groups	claim.name
ba445554-3272-45e4-9cde-15359be2b823	String	jsonType.label
fc15ac46-1417-4052-953c-1dcad433db7a	true	introspection.token.claim
fc15ac46-1417-4052-953c-1dcad433db7a	true	userinfo.token.claim
fc15ac46-1417-4052-953c-1dcad433db7a	username	user.attribute
fc15ac46-1417-4052-953c-1dcad433db7a	true	id.token.claim
fc15ac46-1417-4052-953c-1dcad433db7a	true	access.token.claim
fc15ac46-1417-4052-953c-1dcad433db7a	upn	claim.name
fc15ac46-1417-4052-953c-1dcad433db7a	String	jsonType.label
4730d3c7-bb0e-426f-b40e-816984a0ccd6	true	introspection.token.claim
4730d3c7-bb0e-426f-b40e-816984a0ccd6	true	id.token.claim
4730d3c7-bb0e-426f-b40e-816984a0ccd6	true	access.token.claim
08e7caf9-5a7d-4d21-a01d-efe6bdbacf27	true	multivalued
08e7caf9-5a7d-4d21-a01d-efe6bdbacf27	true	userinfo.token.claim
08e7caf9-5a7d-4d21-a01d-efe6bdbacf27	true	id.token.claim
08e7caf9-5a7d-4d21-a01d-efe6bdbacf27	true	access.token.claim
08e7caf9-5a7d-4d21-a01d-efe6bdbacf27	realm_access.roles	claim.name
08e7caf9-5a7d-4d21-a01d-efe6bdbacf27	String	jsonType.label
228ab354-18a1-4b85-8cb6-2ffcaba6931e	attendance-frontend	included.client.audience
228ab354-18a1-4b85-8cb6-2ffcaba6931e	true	id.token.claim
228ab354-18a1-4b85-8cb6-2ffcaba6931e	true	access.token.claim
228ab354-18a1-4b85-8cb6-2ffcaba6931e	attendance-frontend	included.custom.audience
228ab354-18a1-4b85-8cb6-2ffcaba6931e	true	userinfo.token.claim
8c33c6a5-bbce-4a1b-8113-42bc05d40f54	true	id.token.claim
8c33c6a5-bbce-4a1b-8113-42bc05d40f54	true	access.token.claim
8c33c6a5-bbce-4a1b-8113-42bc05d40f54	true	userinfo.token.claim
b7f0cad9-1303-43ea-bcca-ab50710fe049	true	userinfo.token.claim
b7f0cad9-1303-43ea-bcca-ab50710fe049	email	user.attribute
b7f0cad9-1303-43ea-bcca-ab50710fe049	true	id.token.claim
b7f0cad9-1303-43ea-bcca-ab50710fe049	true	access.token.claim
b7f0cad9-1303-43ea-bcca-ab50710fe049	email	claim.name
b7f0cad9-1303-43ea-bcca-ab50710fe049	String	jsonType.label
1e5816ce-576f-4486-8d56-32470d5929aa	true	introspection.token.claim
1e5816ce-576f-4486-8d56-32470d5929aa	true	userinfo.token.claim
1e5816ce-576f-4486-8d56-32470d5929aa	locale	user.attribute
1e5816ce-576f-4486-8d56-32470d5929aa	true	id.token.claim
1e5816ce-576f-4486-8d56-32470d5929aa	true	access.token.claim
1e5816ce-576f-4486-8d56-32470d5929aa	locale	claim.name
1e5816ce-576f-4486-8d56-32470d5929aa	String	jsonType.label
ce92c5f3-0099-4981-ab20-18a3777db358	1	claim.value
ce92c5f3-0099-4981-ab20-18a3777db358	true	userinfo.token.claim
ce92c5f3-0099-4981-ab20-18a3777db358	true	id.token.claim
ce92c5f3-0099-4981-ab20-18a3777db358	true	access.token.claim
ce92c5f3-0099-4981-ab20-18a3777db358	tenant_id	claim.name
ce92c5f3-0099-4981-ab20-18a3777db358	String	jsonType.label
0dd44e27-7bf3-40f3-a892-62eb092d28d1	1	claim.value
0dd44e27-7bf3-40f3-a892-62eb092d28d1	true	userinfo.token.claim
0dd44e27-7bf3-40f3-a892-62eb092d28d1	true	id.token.claim
0dd44e27-7bf3-40f3-a892-62eb092d28d1	true	access.token.claim
0dd44e27-7bf3-40f3-a892-62eb092d28d1	customer_id	claim.name
0dd44e27-7bf3-40f3-a892-62eb092d28d1	String	jsonType.label
5ec38456-45a4-4f87-84fb-29f3db1eeed3	1	claim.value
5ec38456-45a4-4f87-84fb-29f3db1eeed3	true	userinfo.token.claim
5ec38456-45a4-4f87-84fb-29f3db1eeed3	true	id.token.claim
5ec38456-45a4-4f87-84fb-29f3db1eeed3	true	access.token.claim
5ec38456-45a4-4f87-84fb-29f3db1eeed3	site_id	claim.name
5ec38456-45a4-4f87-84fb-29f3db1eeed3	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
2334ed90-f617-4b21-ad06-1f96d7b25bf2	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	029685e2-8b2c-4435-a9b6-e1ef371ccd6f	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	cff7d17c-27ad-4c95-845e-ee298190bb41	42472110-33db-45ac-99b8-71ef7ef94bc8	b9b47dc0-e7fa-45ce-a4cd-7e7e60a5f489	29cfc270-bf14-42d2-be61-a3897984294f	2ab3ce63-7e4f-4220-9329-7d4e277a70cb	2592000	f	900	t	f	91b0e79f-bdec-402f-9693-903474354aa7	0	f	0	0	3fa9929b-b50a-4f0f-9a65-fc7b4332fcc3
cca741d1-bc8c-4408-87d3-1831c344aac7	60	300	1800	frs2	keycloak	frs2	t	f	0	frs2	attendance	0	\N	f	f	t	f	NONE	1800	36000	f	f	49bc0012-4f89-4e8c-bc09-bf85e4bd4493	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	5dac7847-eca5-4ae9-9a26-04e9416d63fc	148ae55e-f124-42c2-a205-3a571b674529	9cbf69be-6177-422e-8287-f534d8798a63	2977955c-0fca-4eb0-a313-aac76f331163	2afd76ac-aff1-4c5a-b7f9-0fc07e5e4693	2592000	f	900	t	f	6c047f7e-bb7a-4072-9b2b-7c297d938486	0	f	0	0	f5ae953a-8a5e-417c-a285-592abc5146ae
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	2334ed90-f617-4b21-ad06-1f96d7b25bf2	
_browser_header.xContentTypeOptions	2334ed90-f617-4b21-ad06-1f96d7b25bf2	nosniff
_browser_header.referrerPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	no-referrer
_browser_header.xRobotsTag	2334ed90-f617-4b21-ad06-1f96d7b25bf2	none
_browser_header.xFrameOptions	2334ed90-f617-4b21-ad06-1f96d7b25bf2	SAMEORIGIN
_browser_header.contentSecurityPolicy	2334ed90-f617-4b21-ad06-1f96d7b25bf2	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	2334ed90-f617-4b21-ad06-1f96d7b25bf2	1; mode=block
_browser_header.strictTransportSecurity	2334ed90-f617-4b21-ad06-1f96d7b25bf2	max-age=31536000; includeSubDomains
bruteForceProtected	2334ed90-f617-4b21-ad06-1f96d7b25bf2	false
permanentLockout	2334ed90-f617-4b21-ad06-1f96d7b25bf2	false
maxTemporaryLockouts	2334ed90-f617-4b21-ad06-1f96d7b25bf2	0
maxFailureWaitSeconds	2334ed90-f617-4b21-ad06-1f96d7b25bf2	900
minimumQuickLoginWaitSeconds	2334ed90-f617-4b21-ad06-1f96d7b25bf2	60
waitIncrementSeconds	2334ed90-f617-4b21-ad06-1f96d7b25bf2	60
quickLoginCheckMilliSeconds	2334ed90-f617-4b21-ad06-1f96d7b25bf2	1000
maxDeltaTimeSeconds	2334ed90-f617-4b21-ad06-1f96d7b25bf2	43200
failureFactor	2334ed90-f617-4b21-ad06-1f96d7b25bf2	30
realmReusableOtpCode	2334ed90-f617-4b21-ad06-1f96d7b25bf2	false
firstBrokerLoginFlowId	2334ed90-f617-4b21-ad06-1f96d7b25bf2	1be0602f-3721-494f-804c-068ede67e9b2
displayName	2334ed90-f617-4b21-ad06-1f96d7b25bf2	Keycloak
displayNameHtml	2334ed90-f617-4b21-ad06-1f96d7b25bf2	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	2334ed90-f617-4b21-ad06-1f96d7b25bf2	RS256
offlineSessionMaxLifespanEnabled	2334ed90-f617-4b21-ad06-1f96d7b25bf2	false
offlineSessionMaxLifespan	2334ed90-f617-4b21-ad06-1f96d7b25bf2	5184000
permanentLockout	cca741d1-bc8c-4408-87d3-1831c344aac7	false
maxTemporaryLockouts	cca741d1-bc8c-4408-87d3-1831c344aac7	0
maxFailureWaitSeconds	cca741d1-bc8c-4408-87d3-1831c344aac7	900
minimumQuickLoginWaitSeconds	cca741d1-bc8c-4408-87d3-1831c344aac7	60
waitIncrementSeconds	cca741d1-bc8c-4408-87d3-1831c344aac7	60
quickLoginCheckMilliSeconds	cca741d1-bc8c-4408-87d3-1831c344aac7	1000
maxDeltaTimeSeconds	cca741d1-bc8c-4408-87d3-1831c344aac7	43200
realmReusableOtpCode	cca741d1-bc8c-4408-87d3-1831c344aac7	false
displayName	cca741d1-bc8c-4408-87d3-1831c344aac7	Attendance Intelligence
defaultSignatureAlgorithm	cca741d1-bc8c-4408-87d3-1831c344aac7	RS256
offlineSessionMaxLifespanEnabled	cca741d1-bc8c-4408-87d3-1831c344aac7	false
offlineSessionMaxLifespan	cca741d1-bc8c-4408-87d3-1831c344aac7	5184000
actionTokenGeneratedByAdminLifespan	cca741d1-bc8c-4408-87d3-1831c344aac7	43200
actionTokenGeneratedByUserLifespan	cca741d1-bc8c-4408-87d3-1831c344aac7	300
oauth2DeviceCodeLifespan	cca741d1-bc8c-4408-87d3-1831c344aac7	600
oauth2DevicePollingInterval	cca741d1-bc8c-4408-87d3-1831c344aac7	5
webAuthnPolicyRpEntityName	cca741d1-bc8c-4408-87d3-1831c344aac7	keycloak
webAuthnPolicySignatureAlgorithms	cca741d1-bc8c-4408-87d3-1831c344aac7	ES256
webAuthnPolicyRpId	cca741d1-bc8c-4408-87d3-1831c344aac7	
webAuthnPolicyAttestationConveyancePreference	cca741d1-bc8c-4408-87d3-1831c344aac7	not specified
webAuthnPolicyAuthenticatorAttachment	cca741d1-bc8c-4408-87d3-1831c344aac7	not specified
webAuthnPolicyRequireResidentKey	cca741d1-bc8c-4408-87d3-1831c344aac7	not specified
webAuthnPolicyUserVerificationRequirement	cca741d1-bc8c-4408-87d3-1831c344aac7	not specified
webAuthnPolicyCreateTimeout	cca741d1-bc8c-4408-87d3-1831c344aac7	0
webAuthnPolicyAvoidSameAuthenticatorRegister	cca741d1-bc8c-4408-87d3-1831c344aac7	false
webAuthnPolicyRpEntityNamePasswordless	cca741d1-bc8c-4408-87d3-1831c344aac7	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	cca741d1-bc8c-4408-87d3-1831c344aac7	ES256
webAuthnPolicyRpIdPasswordless	cca741d1-bc8c-4408-87d3-1831c344aac7	
webAuthnPolicyAttestationConveyancePreferencePasswordless	cca741d1-bc8c-4408-87d3-1831c344aac7	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	cca741d1-bc8c-4408-87d3-1831c344aac7	not specified
webAuthnPolicyRequireResidentKeyPasswordless	cca741d1-bc8c-4408-87d3-1831c344aac7	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	cca741d1-bc8c-4408-87d3-1831c344aac7	not specified
webAuthnPolicyCreateTimeoutPasswordless	cca741d1-bc8c-4408-87d3-1831c344aac7	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	cca741d1-bc8c-4408-87d3-1831c344aac7	false
cibaBackchannelTokenDeliveryMode	cca741d1-bc8c-4408-87d3-1831c344aac7	poll
cibaExpiresIn	cca741d1-bc8c-4408-87d3-1831c344aac7	120
cibaInterval	cca741d1-bc8c-4408-87d3-1831c344aac7	5
cibaAuthRequestedUserHint	cca741d1-bc8c-4408-87d3-1831c344aac7	login_hint
parRequestUriLifespan	cca741d1-bc8c-4408-87d3-1831c344aac7	60
firstBrokerLoginFlowId	cca741d1-bc8c-4408-87d3-1831c344aac7	9504779d-3196-40be-a17b-0b164a9f5a7d
bruteForceProtected	cca741d1-bc8c-4408-87d3-1831c344aac7	true
failureFactor	cca741d1-bc8c-4408-87d3-1831c344aac7	5
clientSessionIdleTimeout	cca741d1-bc8c-4408-87d3-1831c344aac7	0
clientSessionMaxLifespan	cca741d1-bc8c-4408-87d3-1831c344aac7	0
clientOfflineSessionIdleTimeout	cca741d1-bc8c-4408-87d3-1831c344aac7	0
clientOfflineSessionMaxLifespan	cca741d1-bc8c-4408-87d3-1831c344aac7	0
client-policies.profiles	cca741d1-bc8c-4408-87d3-1831c344aac7	{"profiles":[]}
client-policies.policies	cca741d1-bc8c-4408-87d3-1831c344aac7	{"policies":[]}
_browser_header.contentSecurityPolicyReportOnly	cca741d1-bc8c-4408-87d3-1831c344aac7	
_browser_header.xContentTypeOptions	cca741d1-bc8c-4408-87d3-1831c344aac7	nosniff
_browser_header.referrerPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	no-referrer
_browser_header.xRobotsTag	cca741d1-bc8c-4408-87d3-1831c344aac7	none
_browser_header.xFrameOptions	cca741d1-bc8c-4408-87d3-1831c344aac7	SAMEORIGIN
_browser_header.contentSecurityPolicy	cca741d1-bc8c-4408-87d3-1831c344aac7	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	cca741d1-bc8c-4408-87d3-1831c344aac7	1; mode=block
_browser_header.strictTransportSecurity	cca741d1-bc8c-4408-87d3-1831c344aac7	max-age=31536000; includeSubDomains
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
2334ed90-f617-4b21-ad06-1f96d7b25bf2	jboss-logging
cca741d1-bc8c-4408-87d3-1831c344aac7	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	2334ed90-f617-4b21-ad06-1f96d7b25bf2
password	password	t	t	cca741d1-bc8c-4408-87d3-1831c344aac7
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.redirect_uris (client_id, value) FROM stdin;
13144151-41b0-48a2-b08f-2e88309599c9	/realms/master/account/*
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	/realms/master/account/*
41f6de3e-281b-45b2-968a-da1822a5deaf	/admin/master/console/*
4158b612-6349-4ee8-bbe9-712e39fe3b18	/realms/attendance/account/*
810bae0c-bd22-473d-be9f-6802d42d21f5	/realms/attendance/account/*
bc5d5436-458e-43ce-b6ad-f300b9132ed1	/admin/attendance/console/*
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	http://172.20.100.222:5173/*
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	http://172.20.100.222:5173
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	http://localhost:5173/*
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	http://localhost:5173
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
4081da07-36f6-4436-9f71-124cba84b260	VERIFY_EMAIL	Verify Email	2334ed90-f617-4b21-ad06-1f96d7b25bf2	t	f	VERIFY_EMAIL	50
8403a85b-a441-412c-b9e8-fad3b1ca64a0	UPDATE_PROFILE	Update Profile	2334ed90-f617-4b21-ad06-1f96d7b25bf2	t	f	UPDATE_PROFILE	40
157aeca8-3890-4673-a3b6-d1b712ecd8cd	CONFIGURE_TOTP	Configure OTP	2334ed90-f617-4b21-ad06-1f96d7b25bf2	t	f	CONFIGURE_TOTP	10
0293183e-195c-4a8c-b513-f284c630e984	UPDATE_PASSWORD	Update Password	2334ed90-f617-4b21-ad06-1f96d7b25bf2	t	f	UPDATE_PASSWORD	30
c0bb4e9c-ba4e-49e3-b899-dd88198dd8c5	TERMS_AND_CONDITIONS	Terms and Conditions	2334ed90-f617-4b21-ad06-1f96d7b25bf2	f	f	TERMS_AND_CONDITIONS	20
2c4f98cd-d3cd-4ddf-bdd4-5ff05268ef27	delete_account	Delete Account	2334ed90-f617-4b21-ad06-1f96d7b25bf2	f	f	delete_account	60
6e7bc1fa-5f24-42a9-8f11-eaff093ad5d6	update_user_locale	Update User Locale	2334ed90-f617-4b21-ad06-1f96d7b25bf2	t	f	update_user_locale	1000
c679a367-4e12-446b-a3d2-34d81be68257	webauthn-register	Webauthn Register	2334ed90-f617-4b21-ad06-1f96d7b25bf2	t	f	webauthn-register	70
c827d9dc-6ce3-407c-8563-9bced8e7781e	webauthn-register-passwordless	Webauthn Register Passwordless	2334ed90-f617-4b21-ad06-1f96d7b25bf2	t	f	webauthn-register-passwordless	80
64f022eb-b075-47a1-9f94-b648504410c1	VERIFY_PROFILE	Verify Profile	2334ed90-f617-4b21-ad06-1f96d7b25bf2	t	f	VERIFY_PROFILE	90
3334d4ec-2ad3-43bc-a4ea-1deca5e19de7	VERIFY_EMAIL	Verify Email	cca741d1-bc8c-4408-87d3-1831c344aac7	t	f	VERIFY_EMAIL	50
618567fb-222d-426e-b73e-083e0edbc94c	UPDATE_PROFILE	Update Profile	cca741d1-bc8c-4408-87d3-1831c344aac7	t	f	UPDATE_PROFILE	40
5b2980e4-dadc-4f63-995d-9f34a72c2aaa	CONFIGURE_TOTP	Configure OTP	cca741d1-bc8c-4408-87d3-1831c344aac7	t	f	CONFIGURE_TOTP	10
0b83922d-fe03-4094-ac4a-d865eb6ca9ff	UPDATE_PASSWORD	Update Password	cca741d1-bc8c-4408-87d3-1831c344aac7	t	f	UPDATE_PASSWORD	30
5bfe5f87-a396-42b1-9655-c667dfebd388	TERMS_AND_CONDITIONS	Terms and Conditions	cca741d1-bc8c-4408-87d3-1831c344aac7	f	f	TERMS_AND_CONDITIONS	20
8e56c005-ed40-4e82-8cd8-24b0617e949f	delete_account	Delete Account	cca741d1-bc8c-4408-87d3-1831c344aac7	f	f	delete_account	60
0b4f3f9d-b636-4009-821d-9fccb956ae15	update_user_locale	Update User Locale	cca741d1-bc8c-4408-87d3-1831c344aac7	t	f	update_user_locale	1000
4dcaf250-488e-47fd-ac91-12cf27105612	webauthn-register	Webauthn Register	cca741d1-bc8c-4408-87d3-1831c344aac7	t	f	webauthn-register	70
87533ff7-6970-4d2e-a718-9eb5ff7b267f	webauthn-register-passwordless	Webauthn Register Passwordless	cca741d1-bc8c-4408-87d3-1831c344aac7	t	f	webauthn-register-passwordless	80
c7c20428-4580-40c4-8ff5-f31950512ad6	VERIFY_PROFILE	Verify Profile	cca741d1-bc8c-4408-87d3-1831c344aac7	t	f	VERIFY_PROFILE	90
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	070fa4d1-f3a4-450e-915d-3da2e77e1d8b
3cfab432-bb34-453a-bcc5-44c5e0f5fafa	c87123c9-d77c-4626-9222-4b03347de58e
810bae0c-bd22-473d-be9f-6802d42d21f5	745846b4-9b47-4473-b031-e0c6fa641540
810bae0c-bd22-473d-be9f-6802d42d21f5	b76c8eed-3084-44b9-83cf-10fa8bb7ac7c
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_attribute (name, value, user_id, id, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
b0dae712-f417-40ee-9546-c98c084c03e7	admin@company.com	admin@company.com	t	t	\N	Admin	User	cca741d1-bc8c-4408-87d3-1831c344aac7	admin@company.com	\N	\N	0
4b7f959d-0909-438c-9087-f458de0027c1	hr@company.com	hr@company.com	t	t	\N	HR	Manager	cca741d1-bc8c-4408-87d3-1831c344aac7	hr@company.com	\N	\N	0
52548f9e-606e-4e7c-88e8-b4e8cad4e0bc	\N	f5cc1c86-353e-4ad0-b895-74cb9b700bda	f	t	\N	\N	\N	2334ed90-f617-4b21-ad06-1f96d7b25bf2	admin	1774327646912	\N	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_group_membership (group_id, user_id) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
ba6cf79d-060a-4e25-8eb0-b99ce28a3ed2	b0dae712-f417-40ee-9546-c98c084c03e7
4aa44bd8-c0e2-435c-88fc-2605edc312a2	4b7f959d-0909-438c-9087-f458de0027c1
3fa9929b-b50a-4f0f-9a65-fc7b4332fcc3	52548f9e-606e-4e7c-88e8-b4e8cad4e0bc
8d09cc60-566c-4c44-a9db-c2657c461bb4	52548f9e-606e-4e7c-88e8-b4e8cad4e0bc
\.


--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_session (id, auth_method, ip_address, last_session_refresh, login_username, realm_id, remember_me, started, user_id, user_session_state, broker_session_id, broker_user_id) FROM stdin;
\.


--
-- Data for Name: user_session_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_session_note (user_session, name, value) FROM stdin;
\.


--
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.web_origins (client_id, value) FROM stdin;
41f6de3e-281b-45b2-968a-da1822a5deaf	+
bc5d5436-458e-43ce-b6ad-f300b9132ed1	+
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	http://172.20.100.222:5173
dc28b2f3-6250-407e-8b2d-b261f71cb6fd	http://localhost:5173
\.


--
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: client_user_session_note constr_cl_usr_ses_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT constr_cl_usr_ses_note PRIMARY KEY (client_session, name);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: client_session_role constraint_5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT constraint_5 PRIMARY KEY (client_session, role_id);


--
-- Name: user_session constraint_57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT constraint_57 PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client_session_note constraint_5e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT constraint_5e PRIMARY KEY (client_session, name);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: client_session constraint_8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT constraint_8 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: client_session_auth_status constraint_auth_status_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT constraint_auth_status_pk PRIMARY KEY (client_session, authenticator);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: client_session_prot_mapper constraint_cs_pmp_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT constraint_cs_pmp_pk PRIMARY KEY (client_session, protocol_mapper_id);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: user_session_note constraint_usn_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT constraint_usn_pk PRIMARY KEY (user_session, name);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_jkuwuvd56ontgsuhogm8uewrt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_jkuwuvd56ontgsuhogm8uewrt UNIQUE (client_id, client_storage_provider, external_client_id, user_id);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: fed_user_attr_long_values; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fed_user_attr_long_values ON public.fed_user_attribute USING btree (long_value_hash, name);


--
-- Name: fed_user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fed_user_attr_long_values_lower_case ON public.fed_user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_att_by_name_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_att_by_name_value ON public.client_attributes USING btree (name, substr(value, 1, 255));


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_client_session_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_session_session ON public.client_session USING btree (session_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_css_preload; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_css_preload ON public.offline_client_session USING btree (client_id, offline_flag);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_offline_uss_by_usersess; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_uss_by_usersess ON public.offline_user_session USING btree (realm_id, offline_flag, user_session_id);


--
-- Name: idx_offline_uss_createdon; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_uss_createdon ON public.offline_user_session USING btree (created_on);


--
-- Name: idx_offline_uss_preload; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_offline_uss_preload ON public.offline_user_session USING btree (offline_flag, created_on, user_session_id);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_us_sess_id_on_cl_sess; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_us_sess_id_on_cl_sess ON public.offline_client_session USING btree (user_session_id);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: user_attr_long_values; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_attr_long_values ON public.user_attribute USING btree (long_value_hash, name);


--
-- Name: user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_attr_long_values_lower_case ON public.user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: client_session_auth_status auth_status_constraint; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT auth_status_constraint FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: client_session_note fk5edfb00ff51c2736; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT fk5edfb00ff51c2736 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: user_session_note fk5edfb00ff51d3472; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT fk5edfb00ff51d3472 FOREIGN KEY (user_session) REFERENCES public.user_session(id);


--
-- Name: client_session_role fk_11b7sgqw18i532811v7o2dv76; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT fk_11b7sgqw18i532811v7o2dv76 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session_prot_mapper fk_33a8sgqw18i532811v7o2dk89; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT fk_33a8sgqw18i532811v7o2dk89 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session fk_b4ao2vcvat6ukau74wbwtfqo1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT fk_b4ao2vcvat6ukau74wbwtfqo1 FOREIGN KEY (session_id) REFERENCES public.user_session(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_user_session_note fk_cl_usr_ses_note; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT fk_cl_usr_ses_note FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

\unrestrict j4ihwSKwoV4KQ1LyBTzrh9OTEgorCNEnEzqdRE04OgFB1eEVTTTRWJwu32Z7PmX

