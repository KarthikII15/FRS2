--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-2.pgdg120+1)
-- Dumped by pg_dump version 15.4 (Debian 15.4-2.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: sync_face_enrolled(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_face_enrolled() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE hr_employee
      SET face_enrolled = TRUE
      WHERE pk_employee_id = NEW.employee_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE hr_employee
      SET face_enrolled = (
        EXISTS (
          SELECT 1 FROM employee_face_embeddings
          WHERE employee_id = OLD.employee_id
        )
      )
      WHERE pk_employee_id = OLD.employee_id;
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      NEW.updated_at = NOW();
      RETURN NEW;
    END;
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attendance_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_events (
    pk_attendance_event_id bigint NOT NULL,
    fk_employee_id bigint,
    fk_device_id uuid,
    fk_original_event_id uuid,
    event_type character varying(50) NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    confidence_score double precision,
    verification_method character varying(50),
    recognition_model_version character varying(50),
    frame_image_url text,
    face_bounding_box jsonb,
    location_zone character varying(120),
    entry_exit_direction character varying(20),
    fk_shift_id bigint,
    is_expected_entry boolean,
    is_on_time boolean,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: attendance_events_pk_attendance_event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_events_pk_attendance_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_events_pk_attendance_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_events_pk_attendance_event_id_seq OWNED BY public.attendance_events.pk_attendance_event_id;


--
-- Name: attendance_record; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_record (
    pk_attendance_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    fk_employee_id bigint NOT NULL,
    attendance_date date NOT NULL,
    check_in timestamp with time zone,
    check_out timestamp with time zone,
    break_start timestamp with time zone,
    break_end timestamp with time zone,
    status character varying(20) NOT NULL,
    working_hours numeric(8,2) DEFAULT 0 NOT NULL,
    break_duration_minutes integer DEFAULT 0 NOT NULL,
    overtime_hours numeric(8,2) DEFAULT 0 NOT NULL,
    is_late boolean DEFAULT false NOT NULL,
    is_early_departure boolean DEFAULT false NOT NULL,
    device_id character varying(80),
    location_label character varying(180),
    recognition_accuracy numeric(5,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    duration_minutes integer,
    CONSTRAINT attendance_record_status_check CHECK (((status)::text = ANY ((ARRAY['present'::character varying, 'late'::character varying, 'absent'::character varying, 'on-leave'::character varying, 'on-break'::character varying])::text[])))
);


--
-- Name: attendance_record_pk_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_record_pk_attendance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_record_pk_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_record_pk_attendance_id_seq OWNED BY public.attendance_record.pk_attendance_id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    pk_audit_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    fk_user_id bigint,
    action character varying(120) NOT NULL,
    details text NOT NULL,
    ip_address character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_name character varying(255),
    user_role character varying(50),
    user_agent character varying(500),
    method character varying(10),
    entity_type character varying(100),
    entity_id character varying(100),
    entity_name character varying(255),
    before_data text,
    after_data text,
    source character varying(50) DEFAULT 'ui'::character varying
);


--
-- Name: audit_log_pk_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_pk_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_pk_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_pk_audit_id_seq OWNED BY public.audit_log.pk_audit_id;


--
-- Name: auth_session_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_session_token (
    token_id uuid DEFAULT gen_random_uuid() NOT NULL,
    fk_user_id bigint NOT NULL,
    access_token character varying(128) NOT NULL,
    refresh_token character varying(128) NOT NULL,
    access_expires_at timestamp with time zone NOT NULL,
    refresh_expires_at timestamp with time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    user_agent character varying(512),
    ip_address character varying(45),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: device_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_events (
    pk_event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    fk_device_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    processing_status character varying(20) DEFAULT 'pending'::character varying,
    payload_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    detected_face_embedding jsonb,
    confidence_score double precision,
    frame_url text,
    processing_attempts integer DEFAULT 0,
    processing_error text,
    CONSTRAINT device_events_event_type_check CHECK (((event_type)::text = ANY ((ARRAY['FACE_DETECTED'::character varying, 'MOTION_DETECTED'::character varying, 'EMPLOYEE_ENTRY'::character varying, 'EMPLOYEE_EXIT'::character varying, 'DEVICE_HEARTBEAT'::character varying, 'DEVICE_ERROR'::character varying, 'FRAME_CAPTURED'::character varying])::text[]))),
    CONSTRAINT device_events_processing_status_check CHECK (((processing_status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'completed'::character varying, 'failed'::character varying, 'ignored'::character varying])::text[])))
);


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    pk_device_id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_code character varying(50) NOT NULL,
    device_name character varying(100),
    device_type character varying(20),
    fk_site_id uuid,
    location_description text,
    ip_address inet,
    mac_address character varying(17),
    keycloak_client_id character varying(100),
    api_key_hash character varying(64),
    status character varying(20) DEFAULT 'offline'::character varying,
    config_json jsonb DEFAULT '{}'::jsonb,
    capabilities jsonb DEFAULT '["face_detection"]'::jsonb,
    last_heartbeat_at timestamp with time zone,
    last_seen_at timestamp with time zone,
    firmware_version character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    camera_mode character varying(10) DEFAULT 'MIXED'::character varying,
    CONSTRAINT devices_device_type_check CHECK (((device_type)::text = ANY ((ARRAY['camera'::character varying, 'lpu'::character varying, 'sensor'::character varying, 'gateway'::character varying])::text[]))),
    CONSTRAINT devices_status_check CHECK (((status)::text = ANY ((ARRAY['online'::character varying, 'offline'::character varying, 'error'::character varying, 'maintenance'::character varying])::text[])))
);


--
-- Name: employee_face_embeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_face_embeddings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    employee_id bigint NOT NULL,
    embedding public.vector(512) NOT NULL,
    model_version character varying(50) DEFAULT 'arcface-r50-fp16'::character varying,
    quality_score double precision,
    is_primary boolean DEFAULT false,
    enrolled_by bigint,
    enrolled_at timestamp with time zone DEFAULT now()
);


--
-- Name: facility_device; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.facility_device (
    pk_device_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    external_device_id character varying(80) NOT NULL,
    name character varying(200) NOT NULL,
    location_label character varying(200) NOT NULL,
    ip_address character varying(64) NOT NULL,
    status character varying(20) NOT NULL,
    recognition_accuracy numeric(5,2) DEFAULT 0 NOT NULL,
    total_scans integer DEFAULT 0 NOT NULL,
    error_rate numeric(5,2) DEFAULT 0 NOT NULL,
    model character varying(120),
    last_active timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT facility_device_status_check CHECK (((status)::text = ANY ((ARRAY['online'::character varying, 'offline'::character varying, 'error'::character varying])::text[])))
);


--
-- Name: facility_device_pk_device_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.facility_device_pk_device_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: facility_device_pk_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.facility_device_pk_device_id_seq OWNED BY public.facility_device.pk_device_id;


--
-- Name: frs_building; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_building (
    pk_building_id integer NOT NULL,
    fk_site_id integer,
    name character varying(100) NOT NULL,
    address text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_building_pk_building_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_building_pk_building_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_building_pk_building_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_building_pk_building_id_seq OWNED BY public.frs_building.pk_building_id;


--
-- Name: frs_camera; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_camera (
    pk_camera_id integer NOT NULL,
    fk_nug_id integer,
    fk_floor_id integer,
    fk_zone_id integer,
    name character varying(100) NOT NULL,
    cam_id character varying(100),
    rtsp_url text,
    ip_address character varying(50),
    model character varying(100),
    status character varying(20) DEFAULT 'offline'::character varying,
    recognition_accuracy numeric(5,4) DEFAULT 0,
    total_scans integer DEFAULT 0,
    error_rate numeric(5,4) DEFAULT 0,
    last_active timestamp with time zone,
    map_x numeric(10,4),
    map_y numeric(10,4),
    map_angle numeric(6,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_camera_pk_camera_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_camera_pk_camera_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_camera_pk_camera_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_camera_pk_camera_id_seq OWNED BY public.frs_camera.pk_camera_id;


--
-- Name: frs_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_customer (
    pk_customer_id bigint NOT NULL,
    customer_name character varying(200) NOT NULL,
    fk_tenant_id bigint NOT NULL
);


--
-- Name: frs_customer_pk_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_customer_pk_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_customer_pk_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_customer_pk_customer_id_seq OWNED BY public.frs_customer.pk_customer_id;


--
-- Name: frs_customer_user_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_customer_user_map (
    fk_user_id bigint NOT NULL,
    fk_customer_id bigint NOT NULL
);


--
-- Name: frs_floor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_floor (
    pk_floor_id integer NOT NULL,
    fk_building_id integer,
    floor_number integer NOT NULL,
    floor_name character varying(100),
    floor_plan_url text,
    floor_plan_data jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_floor_pk_floor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_floor_pk_floor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_floor_pk_floor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_floor_pk_floor_id_seq OWNED BY public.frs_floor.pk_floor_id;


--
-- Name: frs_nug_box; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_nug_box (
    pk_nug_id integer NOT NULL,
    fk_site_id integer,
    fk_building_id integer,
    fk_floor_id integer,
    fk_zone_id integer,
    name character varying(100) NOT NULL,
    device_code character varying(100),
    ip_address character varying(50),
    port integer DEFAULT 5000,
    match_threshold numeric(4,3) DEFAULT 0.38,
    conf_threshold numeric(4,3) DEFAULT 0.35,
    cooldown_seconds integer DEFAULT 3,
    x_threshold integer DEFAULT 25,
    tracking_window integer DEFAULT 6,
    status character varying(20) DEFAULT 'offline'::character varying,
    cpu_percent numeric(5,2),
    memory_used_mb numeric(10,2),
    memory_total_mb numeric(10,2),
    gpu_percent numeric(5,2),
    temperature_c numeric(5,2),
    disk_used_gb numeric(10,2),
    uptime_seconds bigint,
    last_heartbeat timestamp with time zone,
    map_x numeric(10,4),
    map_y numeric(10,4),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_nug_box_pk_nug_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_nug_box_pk_nug_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_nug_box_pk_nug_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_nug_box_pk_nug_id_seq OWNED BY public.frs_nug_box.pk_nug_id;


--
-- Name: frs_site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_site (
    pk_site_id bigint NOT NULL,
    site_name character varying(200) NOT NULL,
    fk_customer_id bigint NOT NULL,
    timezone character varying(100) DEFAULT 'Asia/Manila'::character varying,
    timezone_label character varying(100) DEFAULT 'Philippine Standard Time (UTC+8)'::character varying,
    location_address text
);


--
-- Name: frs_site_pk_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_site_pk_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_site_pk_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_site_pk_site_id_seq OWNED BY public.frs_site.pk_site_id;


--
-- Name: frs_telemetry_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_telemetry_history (
    pk_history_id integer NOT NULL,
    fk_nug_id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    cpu numeric(5,2),
    gpu numeric(5,2),
    ram numeric(5,2)
);


--
-- Name: frs_telemetry_history_pk_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_telemetry_history_pk_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_telemetry_history_pk_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_telemetry_history_pk_history_id_seq OWNED BY public.frs_telemetry_history.pk_history_id;


--
-- Name: frs_tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_tenant (
    pk_tenant_id bigint NOT NULL,
    tenant_name character varying(200) NOT NULL
);


--
-- Name: frs_tenant_pk_tenant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_tenant_pk_tenant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_tenant_pk_tenant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_tenant_pk_tenant_id_seq OWNED BY public.frs_tenant.pk_tenant_id;


--
-- Name: frs_tenant_user_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_tenant_user_map (
    fk_user_id bigint NOT NULL,
    fk_tenant_id bigint NOT NULL
);


--
-- Name: frs_unit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_unit (
    pk_unit_id bigint NOT NULL,
    unit_name character varying(200) NOT NULL,
    fk_site_id bigint NOT NULL
);


--
-- Name: frs_unit_pk_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_unit_pk_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_unit_pk_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_unit_pk_unit_id_seq OWNED BY public.frs_unit.pk_unit_id;


--
-- Name: frs_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_user (
    pk_user_id bigint NOT NULL,
    email character varying(320) NOT NULL,
    username character varying(150) NOT NULL,
    fk_user_type_id integer NOT NULL,
    role character varying(20) NOT NULL,
    password_hash character varying(255),
    department character varying(150),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    keycloak_sub character varying(64),
    auth_provider character varying(20) DEFAULT 'internal'::character varying NOT NULL,
    last_identity_sync_at timestamp with time zone,
    CONSTRAINT frs_user_auth_provider_check CHECK (((auth_provider)::text = ANY ((ARRAY['internal'::character varying, 'keycloak'::character varying, 'federated'::character varying])::text[]))),
    CONSTRAINT frs_user_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'hr'::character varying])::text[])))
);


--
-- Name: frs_user_membership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_user_membership (
    pk_membership_id bigint NOT NULL,
    fk_user_id bigint NOT NULL,
    role character varying(20) NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    permissions text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT frs_user_membership_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'hr'::character varying])::text[])))
);


--
-- Name: frs_user_membership_pk_membership_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_user_membership_pk_membership_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_user_membership_pk_membership_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_user_membership_pk_membership_id_seq OWNED BY public.frs_user_membership.pk_membership_id;


--
-- Name: frs_user_pk_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_user_pk_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_user_pk_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_user_pk_user_id_seq OWNED BY public.frs_user.pk_user_id;


--
-- Name: frs_zone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frs_zone (
    pk_zone_id integer NOT NULL,
    fk_floor_id integer,
    zone_name character varying(100) NOT NULL,
    zone_type character varying(50) DEFAULT 'common'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: frs_zone_pk_zone_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frs_zone_pk_zone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frs_zone_pk_zone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frs_zone_pk_zone_id_seq OWNED BY public.frs_zone.pk_zone_id;


--
-- Name: hr_department; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_department (
    pk_department_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    name character varying(150) NOT NULL,
    code character varying(30) NOT NULL,
    color character varying(20)
);


--
-- Name: hr_department_pk_department_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hr_department_pk_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hr_department_pk_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hr_department_pk_department_id_seq OWNED BY public.hr_department.pk_department_id;


--
-- Name: hr_employee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_employee (
    pk_employee_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    fk_department_id bigint,
    fk_shift_id bigint,
    employee_code character varying(40) NOT NULL,
    full_name character varying(180) NOT NULL,
    email character varying(320) NOT NULL,
    position_title character varying(180) NOT NULL,
    location_label character varying(180),
    status character varying(20) NOT NULL,
    join_date date NOT NULL,
    phone_number character varying(40),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    face_enrolled boolean DEFAULT false,
    CONSTRAINT hr_employee_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'on-leave'::character varying])::text[])))
);


--
-- Name: hr_employee_pk_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hr_employee_pk_employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hr_employee_pk_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hr_employee_pk_employee_id_seq OWNED BY public.hr_employee.pk_employee_id;


--
-- Name: hr_leave_request; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_leave_request (
    pk_leave_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    fk_employee_id bigint NOT NULL,
    leave_type character varying(60) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    days integer DEFAULT 1 NOT NULL,
    reason text,
    status character varying(20) DEFAULT 'Pending'::character varying NOT NULL,
    approved_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hr_leave_request_status_check CHECK (((status)::text = ANY ((ARRAY['Pending'::character varying, 'Approved'::character varying, 'Rejected'::character varying])::text[])))
);


--
-- Name: hr_leave_request_pk_leave_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hr_leave_request_pk_leave_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hr_leave_request_pk_leave_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hr_leave_request_pk_leave_id_seq OWNED BY public.hr_leave_request.pk_leave_id;


--
-- Name: hr_shift; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_shift (
    pk_shift_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    name character varying(120) NOT NULL,
    shift_type character varying(30) NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    grace_period_minutes integer DEFAULT 10 NOT NULL,
    is_flexible boolean DEFAULT false NOT NULL,
    CONSTRAINT hr_shift_shift_type_check CHECK (((shift_type)::text = ANY ((ARRAY['morning'::character varying, 'evening'::character varying, 'night'::character varying, 'flexible'::character varying])::text[])))
);


--
-- Name: hr_shift_pk_shift_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hr_shift_pk_shift_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hr_shift_pk_shift_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hr_shift_pk_shift_id_seq OWNED BY public.hr_shift.pk_shift_id;


--
-- Name: system_alert; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_alert (
    pk_alert_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    customer_id bigint,
    site_id bigint,
    unit_id bigint,
    alert_type character varying(80) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(220),
    message text NOT NULL,
    fk_employee_id bigint,
    fk_device_id bigint,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT system_alert_severity_check CHECK (((severity)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[])))
);


--
-- Name: system_alert_pk_alert_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_alert_pk_alert_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_alert_pk_alert_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_alert_pk_alert_id_seq OWNED BY public.system_alert.pk_alert_id;


--
-- Name: attendance_events pk_attendance_event_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events ALTER COLUMN pk_attendance_event_id SET DEFAULT nextval('public.attendance_events_pk_attendance_event_id_seq'::regclass);


--
-- Name: attendance_record pk_attendance_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record ALTER COLUMN pk_attendance_id SET DEFAULT nextval('public.attendance_record_pk_attendance_id_seq'::regclass);


--
-- Name: audit_log pk_audit_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN pk_audit_id SET DEFAULT nextval('public.audit_log_pk_audit_id_seq'::regclass);


--
-- Name: facility_device pk_device_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device ALTER COLUMN pk_device_id SET DEFAULT nextval('public.facility_device_pk_device_id_seq'::regclass);


--
-- Name: frs_building pk_building_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_building ALTER COLUMN pk_building_id SET DEFAULT nextval('public.frs_building_pk_building_id_seq'::regclass);


--
-- Name: frs_camera pk_camera_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera ALTER COLUMN pk_camera_id SET DEFAULT nextval('public.frs_camera_pk_camera_id_seq'::regclass);


--
-- Name: frs_customer pk_customer_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer ALTER COLUMN pk_customer_id SET DEFAULT nextval('public.frs_customer_pk_customer_id_seq'::regclass);


--
-- Name: frs_floor pk_floor_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_floor ALTER COLUMN pk_floor_id SET DEFAULT nextval('public.frs_floor_pk_floor_id_seq'::regclass);


--
-- Name: frs_nug_box pk_nug_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box ALTER COLUMN pk_nug_id SET DEFAULT nextval('public.frs_nug_box_pk_nug_id_seq'::regclass);


--
-- Name: frs_site pk_site_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_site ALTER COLUMN pk_site_id SET DEFAULT nextval('public.frs_site_pk_site_id_seq'::regclass);


--
-- Name: frs_telemetry_history pk_history_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_telemetry_history ALTER COLUMN pk_history_id SET DEFAULT nextval('public.frs_telemetry_history_pk_history_id_seq'::regclass);


--
-- Name: frs_tenant pk_tenant_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant ALTER COLUMN pk_tenant_id SET DEFAULT nextval('public.frs_tenant_pk_tenant_id_seq'::regclass);


--
-- Name: frs_unit pk_unit_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_unit ALTER COLUMN pk_unit_id SET DEFAULT nextval('public.frs_unit_pk_unit_id_seq'::regclass);


--
-- Name: frs_user pk_user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user ALTER COLUMN pk_user_id SET DEFAULT nextval('public.frs_user_pk_user_id_seq'::regclass);


--
-- Name: frs_user_membership pk_membership_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership ALTER COLUMN pk_membership_id SET DEFAULT nextval('public.frs_user_membership_pk_membership_id_seq'::regclass);


--
-- Name: frs_zone pk_zone_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_zone ALTER COLUMN pk_zone_id SET DEFAULT nextval('public.frs_zone_pk_zone_id_seq'::regclass);


--
-- Name: hr_department pk_department_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_department ALTER COLUMN pk_department_id SET DEFAULT nextval('public.hr_department_pk_department_id_seq'::regclass);


--
-- Name: hr_employee pk_employee_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee ALTER COLUMN pk_employee_id SET DEFAULT nextval('public.hr_employee_pk_employee_id_seq'::regclass);


--
-- Name: hr_leave_request pk_leave_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request ALTER COLUMN pk_leave_id SET DEFAULT nextval('public.hr_leave_request_pk_leave_id_seq'::regclass);


--
-- Name: hr_shift pk_shift_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_shift ALTER COLUMN pk_shift_id SET DEFAULT nextval('public.hr_shift_pk_shift_id_seq'::regclass);


--
-- Name: system_alert pk_alert_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert ALTER COLUMN pk_alert_id SET DEFAULT nextval('public.system_alert_pk_alert_id_seq'::regclass);


--
-- Data for Name: attendance_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_events (pk_attendance_event_id, fk_employee_id, fk_device_id, fk_original_event_id, event_type, occurred_at, confidence_score, verification_method, recognition_model_version, frame_image_url, face_bounding_box, location_zone, entry_exit_direction, fk_shift_id, is_expected_entry, is_on_time, created_at) FROM stdin;
\.


--
-- Data for Name: attendance_record; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_record (pk_attendance_id, tenant_id, customer_id, site_id, unit_id, fk_employee_id, attendance_date, check_in, check_out, break_start, break_end, status, working_hours, break_duration_minutes, overtime_hours, is_late, is_early_departure, device_id, location_label, recognition_accuracy, created_at, duration_minutes) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (pk_audit_id, tenant_id, customer_id, site_id, unit_id, fk_user_id, action, details, ip_address, created_at, user_name, user_role, user_agent, method, entity_type, entity_id, entity_name, before_data, after_data, source) FROM stdin;
\.


--
-- Data for Name: auth_session_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_session_token (token_id, fk_user_id, access_token, refresh_token, access_expires_at, refresh_expires_at, revoked, user_agent, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: device_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_events (pk_event_id, fk_device_id, event_type, occurred_at, received_at, processed_at, processing_status, payload_json, detected_face_embedding, confidence_score, frame_url, processing_attempts, processing_error) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (pk_device_id, device_code, device_name, device_type, fk_site_id, location_description, ip_address, mac_address, keycloak_client_id, api_key_hash, status, config_json, capabilities, last_heartbeat_at, last_seen_at, firmware_version, created_at, updated_at, camera_mode) FROM stdin;
\.


--
-- Data for Name: employee_face_embeddings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_face_embeddings (id, employee_id, embedding, model_version, quality_score, is_primary, enrolled_by, enrolled_at) FROM stdin;
\.


--
-- Data for Name: facility_device; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.facility_device (pk_device_id, tenant_id, customer_id, site_id, unit_id, external_device_id, name, location_label, ip_address, status, recognition_accuracy, total_scans, error_rate, model, last_active) FROM stdin;
1	1	1	1	\N	jetson-orin-01	Jetson Orin NX	Main Entrance	172.18.3.202	offline	0.00	0	0.00	\N	2026-04-06 07:20:25.140181+00
2	1	1	1	\N	entrance-cam-01	Entrance Camera	Main Entrance	172.18.3.202	online	0.00	8283	0.00	\N	2026-04-07 01:59:33.154805+00
\.


--
-- Data for Name: frs_building; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_building (pk_building_id, fk_site_id, name, address, created_at) FROM stdin;
\.


--
-- Data for Name: frs_camera; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_camera (pk_camera_id, fk_nug_id, fk_floor_id, fk_zone_id, name, cam_id, rtsp_url, ip_address, model, status, recognition_accuracy, total_scans, error_rate, last_active, map_x, map_y, map_angle, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: frs_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_customer (pk_customer_id, customer_name, fk_tenant_id) FROM stdin;
1	Default Customer	1
\.


--
-- Data for Name: frs_customer_user_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_customer_user_map (fk_user_id, fk_customer_id) FROM stdin;
\.


--
-- Data for Name: frs_floor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_floor (pk_floor_id, fk_building_id, floor_number, floor_name, floor_plan_url, floor_plan_data, created_at) FROM stdin;
\.


--
-- Data for Name: frs_nug_box; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_nug_box (pk_nug_id, fk_site_id, fk_building_id, fk_floor_id, fk_zone_id, name, device_code, ip_address, port, match_threshold, conf_threshold, cooldown_seconds, x_threshold, tracking_window, status, cpu_percent, memory_used_mb, memory_total_mb, gpu_percent, temperature_c, disk_used_gb, uptime_seconds, last_heartbeat, map_x, map_y, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: frs_site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_site (pk_site_id, site_name, fk_customer_id, timezone, timezone_label, location_address) FROM stdin;
1	Main Site	1	Asia/Manila	Philippine Standard Time (UTC+8)	\N
\.


--
-- Data for Name: frs_telemetry_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_telemetry_history (pk_history_id, fk_nug_id, "timestamp", cpu, gpu, ram) FROM stdin;
\.


--
-- Data for Name: frs_tenant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_tenant (pk_tenant_id, tenant_name) FROM stdin;
1	Motivity Labs
\.


--
-- Data for Name: frs_tenant_user_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_tenant_user_map (fk_user_id, fk_tenant_id) FROM stdin;
\.


--
-- Data for Name: frs_unit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_unit (pk_unit_id, unit_name, fk_site_id) FROM stdin;
\.


--
-- Data for Name: frs_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_user (pk_user_id, email, username, fk_user_type_id, role, password_hash, department, created_at, keycloak_sub, auth_provider, last_identity_sync_at) FROM stdin;
1	admin@company.com	Admin User	1	admin		\N	2026-04-06 08:54:17.997509+00	91e0a27b-7d07-4dcb-b0bf-9bfcec0167cd	internal	\N
2	hr@company.com	HR Manager	1	hr		\N	2026-04-06 08:54:42.733671+00	f74294d7-388f-4bfc-9c8a-d96805bbd208	internal	\N
\.


--
-- Data for Name: frs_user_membership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_user_membership (pk_membership_id, fk_user_id, role, tenant_id, customer_id, site_id, unit_id, permissions) FROM stdin;
1	1	admin	1	1	1	\N	{users.read,users.manage,devices.read,devices.manage,attendance.read,attendance.manage,analytics.read,audit.read,facility.read,facility.manage,aiinsights.read}
2	2	hr	1	1	1	\N	{users.read,devices.read,attendance.read,attendance.manage,analytics.read,facility.read,aiinsights.read}
3	1	admin	1	1	1	\N	{devices.read,devices.write,users.read,users.write,facility.manage,audit.read,reports.read,attendance.read,attendance.write,employees.read,employees.write}
4	2	hr	1	1	1	\N	{attendance.read,attendance.write,employees.read,employees.write,reports.read,facility.manage}
\.


--
-- Data for Name: frs_zone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frs_zone (pk_zone_id, fk_floor_id, zone_name, zone_type, created_at) FROM stdin;
\.


--
-- Data for Name: hr_department; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hr_department (pk_department_id, tenant_id, name, code, color) FROM stdin;
\.


--
-- Data for Name: hr_employee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hr_employee (pk_employee_id, tenant_id, customer_id, site_id, unit_id, fk_department_id, fk_shift_id, employee_code, full_name, email, position_title, location_label, status, join_date, phone_number, created_at, face_enrolled) FROM stdin;
\.


--
-- Data for Name: hr_leave_request; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hr_leave_request (pk_leave_id, tenant_id, fk_employee_id, leave_type, start_date, end_date, days, reason, status, approved_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: hr_shift; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hr_shift (pk_shift_id, tenant_id, name, shift_type, start_time, end_time, grace_period_minutes, is_flexible) FROM stdin;
\.


--
-- Data for Name: system_alert; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_alert (pk_alert_id, tenant_id, customer_id, site_id, unit_id, alert_type, severity, title, message, fk_employee_id, fk_device_id, is_read, created_at) FROM stdin;
\.


--
-- Name: attendance_events_pk_attendance_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_events_pk_attendance_event_id_seq', 1, false);


--
-- Name: attendance_record_pk_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_record_pk_attendance_id_seq', 1, false);


--
-- Name: audit_log_pk_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_pk_audit_id_seq', 1, false);


--
-- Name: facility_device_pk_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.facility_device_pk_device_id_seq', 2, true);


--
-- Name: frs_building_pk_building_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_building_pk_building_id_seq', 1, false);


--
-- Name: frs_camera_pk_camera_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_camera_pk_camera_id_seq', 1, false);


--
-- Name: frs_customer_pk_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_customer_pk_customer_id_seq', 1, false);


--
-- Name: frs_floor_pk_floor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_floor_pk_floor_id_seq', 1, false);


--
-- Name: frs_nug_box_pk_nug_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_nug_box_pk_nug_id_seq', 1, false);


--
-- Name: frs_site_pk_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_site_pk_site_id_seq', 1, false);


--
-- Name: frs_telemetry_history_pk_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_telemetry_history_pk_history_id_seq', 1, false);


--
-- Name: frs_tenant_pk_tenant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_tenant_pk_tenant_id_seq', 1, false);


--
-- Name: frs_unit_pk_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_unit_pk_unit_id_seq', 1, false);


--
-- Name: frs_user_membership_pk_membership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_user_membership_pk_membership_id_seq', 4, true);


--
-- Name: frs_user_pk_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_user_pk_user_id_seq', 2, true);


--
-- Name: frs_zone_pk_zone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frs_zone_pk_zone_id_seq', 1, false);


--
-- Name: hr_department_pk_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hr_department_pk_department_id_seq', 1, false);


--
-- Name: hr_employee_pk_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hr_employee_pk_employee_id_seq', 1, false);


--
-- Name: hr_leave_request_pk_leave_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hr_leave_request_pk_leave_id_seq', 1, false);


--
-- Name: hr_shift_pk_shift_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hr_shift_pk_shift_id_seq', 1, false);


--
-- Name: system_alert_pk_alert_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_alert_pk_alert_id_seq', 1, false);


--
-- Name: attendance_events attendance_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events
    ADD CONSTRAINT attendance_events_pkey PRIMARY KEY (pk_attendance_event_id);


--
-- Name: attendance_record attendance_record_emp_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_emp_date_key UNIQUE (fk_employee_id, attendance_date);


--
-- Name: attendance_record attendance_record_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_pkey PRIMARY KEY (pk_attendance_id);


--
-- Name: attendance_record attendance_record_tenant_id_fk_employee_id_attendance_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_tenant_id_fk_employee_id_attendance_date_key UNIQUE (tenant_id, fk_employee_id, attendance_date);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (pk_audit_id);


--
-- Name: auth_session_token auth_session_token_access_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_token
    ADD CONSTRAINT auth_session_token_access_token_key UNIQUE (access_token);


--
-- Name: auth_session_token auth_session_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_token
    ADD CONSTRAINT auth_session_token_pkey PRIMARY KEY (token_id);


--
-- Name: auth_session_token auth_session_token_refresh_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_token
    ADD CONSTRAINT auth_session_token_refresh_token_key UNIQUE (refresh_token);


--
-- Name: device_events device_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_pkey PRIMARY KEY (pk_event_id);


--
-- Name: devices devices_device_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_device_code_key UNIQUE (device_code);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (pk_device_id);


--
-- Name: employee_face_embeddings employee_face_embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_face_embeddings
    ADD CONSTRAINT employee_face_embeddings_pkey PRIMARY KEY (id);


--
-- Name: facility_device facility_device_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_pkey PRIMARY KEY (pk_device_id);


--
-- Name: facility_device facility_device_tenant_id_external_device_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_tenant_id_external_device_id_key UNIQUE (tenant_id, external_device_id);


--
-- Name: frs_building frs_building_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_building
    ADD CONSTRAINT frs_building_pkey PRIMARY KEY (pk_building_id);


--
-- Name: frs_camera frs_camera_cam_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_cam_id_key UNIQUE (cam_id);


--
-- Name: frs_camera frs_camera_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_pkey PRIMARY KEY (pk_camera_id);


--
-- Name: frs_customer frs_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer
    ADD CONSTRAINT frs_customer_pkey PRIMARY KEY (pk_customer_id);


--
-- Name: frs_customer_user_map frs_customer_user_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer_user_map
    ADD CONSTRAINT frs_customer_user_map_pkey PRIMARY KEY (fk_user_id, fk_customer_id);


--
-- Name: frs_floor frs_floor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_floor
    ADD CONSTRAINT frs_floor_pkey PRIMARY KEY (pk_floor_id);


--
-- Name: frs_nug_box frs_nug_box_device_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_device_code_key UNIQUE (device_code);


--
-- Name: frs_nug_box frs_nug_box_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_pkey PRIMARY KEY (pk_nug_id);


--
-- Name: frs_site frs_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_site
    ADD CONSTRAINT frs_site_pkey PRIMARY KEY (pk_site_id);


--
-- Name: frs_telemetry_history frs_telemetry_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_telemetry_history
    ADD CONSTRAINT frs_telemetry_history_pkey PRIMARY KEY (pk_history_id);


--
-- Name: frs_tenant frs_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant
    ADD CONSTRAINT frs_tenant_pkey PRIMARY KEY (pk_tenant_id);


--
-- Name: frs_tenant_user_map frs_tenant_user_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant_user_map
    ADD CONSTRAINT frs_tenant_user_map_pkey PRIMARY KEY (fk_user_id, fk_tenant_id);


--
-- Name: frs_unit frs_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_unit
    ADD CONSTRAINT frs_unit_pkey PRIMARY KEY (pk_unit_id);


--
-- Name: frs_user frs_user_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user
    ADD CONSTRAINT frs_user_email_key UNIQUE (email);


--
-- Name: frs_user frs_user_keycloak_sub_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user
    ADD CONSTRAINT frs_user_keycloak_sub_key UNIQUE (keycloak_sub);


--
-- Name: frs_user_membership frs_user_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_pkey PRIMARY KEY (pk_membership_id);


--
-- Name: frs_user frs_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user
    ADD CONSTRAINT frs_user_pkey PRIMARY KEY (pk_user_id);


--
-- Name: frs_zone frs_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_zone
    ADD CONSTRAINT frs_zone_pkey PRIMARY KEY (pk_zone_id);


--
-- Name: hr_department hr_department_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_department
    ADD CONSTRAINT hr_department_pkey PRIMARY KEY (pk_department_id);


--
-- Name: hr_department hr_department_tenant_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_department
    ADD CONSTRAINT hr_department_tenant_id_code_key UNIQUE (tenant_id, code);


--
-- Name: hr_employee hr_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_pkey PRIMARY KEY (pk_employee_id);


--
-- Name: hr_employee hr_employee_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: hr_employee hr_employee_tenant_id_employee_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_tenant_id_employee_code_key UNIQUE (tenant_id, employee_code);


--
-- Name: hr_leave_request hr_leave_request_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request
    ADD CONSTRAINT hr_leave_request_pkey PRIMARY KEY (pk_leave_id);


--
-- Name: hr_shift hr_shift_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_shift
    ADD CONSTRAINT hr_shift_pkey PRIMARY KEY (pk_shift_id);


--
-- Name: system_alert system_alert_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_pkey PRIMARY KEY (pk_alert_id);


--
-- Name: idx_alert_scope_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_scope_created ON public.system_alert USING btree (tenant_id, site_id, created_at DESC);


--
-- Name: idx_attendance_employee_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_employee_date ON public.attendance_record USING btree (fk_employee_id, attendance_date DESC);


--
-- Name: idx_attendance_scope_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_scope_date ON public.attendance_record USING btree (tenant_id, site_id, attendance_date DESC);


--
-- Name: idx_audit_scope_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_scope_created ON public.audit_log USING btree (tenant_id, created_at DESC);


--
-- Name: idx_auth_session_token_access; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_session_token_access ON public.auth_session_token USING btree (access_token);


--
-- Name: idx_auth_session_token_refresh; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_session_token_refresh ON public.auth_session_token USING btree (refresh_token);


--
-- Name: idx_device_events_device_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_events_device_time ON public.device_events USING btree (fk_device_id, occurred_at DESC);


--
-- Name: idx_device_events_type_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_events_type_time ON public.device_events USING btree (event_type, occurred_at DESC);


--
-- Name: idx_device_events_unprocessed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_events_unprocessed ON public.device_events USING btree (processing_status);


--
-- Name: idx_device_scope_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_scope_status ON public.facility_device USING btree (tenant_id, site_id, status);


--
-- Name: idx_devices_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_code ON public.devices USING btree (device_code);


--
-- Name: idx_devices_heartbeat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_heartbeat ON public.devices USING btree (last_heartbeat_at);


--
-- Name: idx_devices_site; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_site ON public.devices USING btree (fk_site_id);


--
-- Name: idx_devices_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_status ON public.devices USING btree (status);


--
-- Name: idx_employee_face_hnsw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_face_hnsw ON public.employee_face_embeddings USING hnsw (embedding public.vector_cosine_ops) WITH (m='16', ef_construction='64');


--
-- Name: idx_employee_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_scope ON public.hr_employee USING btree (tenant_id, customer_id, site_id, unit_id);


--
-- Name: idx_frs_building_site; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_building_site ON public.frs_building USING btree (fk_site_id);


--
-- Name: idx_frs_camera_cam_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_camera_cam_id ON public.frs_camera USING btree (cam_id);


--
-- Name: idx_frs_camera_nug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_camera_nug ON public.frs_camera USING btree (fk_nug_id);


--
-- Name: idx_frs_floor_building; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_floor_building ON public.frs_floor USING btree (fk_building_id);


--
-- Name: idx_frs_nug_device_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_nug_device_code ON public.frs_nug_box USING btree (device_code);


--
-- Name: idx_frs_nug_site; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_nug_site ON public.frs_nug_box USING btree (fk_site_id);


--
-- Name: idx_frs_nug_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_nug_status ON public.frs_nug_box USING btree (status);


--
-- Name: idx_frs_user_keycloak_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_user_keycloak_sub ON public.frs_user USING btree (keycloak_sub);


--
-- Name: idx_frs_zone_floor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_frs_zone_floor ON public.frs_zone USING btree (fk_floor_id);


--
-- Name: idx_membership_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_membership_scope ON public.frs_user_membership USING btree (tenant_id, customer_id, site_id, unit_id);


--
-- Name: idx_membership_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_membership_user ON public.frs_user_membership USING btree (fk_user_id);


--
-- Name: idx_shift_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shift_tenant ON public.hr_shift USING btree (tenant_id);


--
-- Name: idx_telemetry_nug_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_telemetry_nug_time ON public.frs_telemetry_history USING btree (fk_nug_id, "timestamp" DESC);


--
-- Name: uq_membership_user_scope_role; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_membership_user_scope_role ON public.frs_user_membership USING btree (fk_user_id, role, tenant_id, customer_id, site_id, unit_id);


--
-- Name: employee_face_embeddings trg_sync_face_enrolled; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_face_enrolled AFTER INSERT OR DELETE ON public.employee_face_embeddings FOR EACH ROW EXECUTE FUNCTION public.sync_face_enrolled();


--
-- Name: devices update_devices_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_devices_updated_at BEFORE UPDATE ON public.devices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: attendance_events attendance_events_fk_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events
    ADD CONSTRAINT attendance_events_fk_employee_id_fkey FOREIGN KEY (fk_employee_id) REFERENCES public.hr_employee(pk_employee_id);


--
-- Name: attendance_events attendance_events_fk_original_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events
    ADD CONSTRAINT attendance_events_fk_original_event_id_fkey FOREIGN KEY (fk_original_event_id) REFERENCES public.device_events(pk_event_id);


--
-- Name: attendance_events attendance_events_fk_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events
    ADD CONSTRAINT attendance_events_fk_shift_id_fkey FOREIGN KEY (fk_shift_id) REFERENCES public.hr_shift(pk_shift_id);


--
-- Name: attendance_record attendance_record_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: attendance_record attendance_record_fk_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_fk_employee_id_fkey FOREIGN KEY (fk_employee_id) REFERENCES public.hr_employee(pk_employee_id);


--
-- Name: attendance_record attendance_record_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: attendance_record attendance_record_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: attendance_record attendance_record_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_record
    ADD CONSTRAINT attendance_record_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: audit_log audit_log_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: audit_log audit_log_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: audit_log audit_log_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: audit_log audit_log_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: auth_session_token auth_session_token_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session_token
    ADD CONSTRAINT auth_session_token_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: employee_face_embeddings employee_face_embeddings_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_face_embeddings
    ADD CONSTRAINT employee_face_embeddings_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.hr_employee(pk_employee_id) ON DELETE CASCADE;


--
-- Name: employee_face_embeddings employee_face_embeddings_enrolled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_face_embeddings
    ADD CONSTRAINT employee_face_embeddings_enrolled_by_fkey FOREIGN KEY (enrolled_by) REFERENCES public.frs_user(pk_user_id);


--
-- Name: facility_device facility_device_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: facility_device facility_device_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: facility_device facility_device_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: facility_device facility_device_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facility_device
    ADD CONSTRAINT facility_device_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: frs_camera frs_camera_fk_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_fk_floor_id_fkey FOREIGN KEY (fk_floor_id) REFERENCES public.frs_floor(pk_floor_id) ON DELETE SET NULL;


--
-- Name: frs_camera frs_camera_fk_nug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_fk_nug_id_fkey FOREIGN KEY (fk_nug_id) REFERENCES public.frs_nug_box(pk_nug_id) ON DELETE SET NULL;


--
-- Name: frs_camera frs_camera_fk_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_camera
    ADD CONSTRAINT frs_camera_fk_zone_id_fkey FOREIGN KEY (fk_zone_id) REFERENCES public.frs_zone(pk_zone_id) ON DELETE SET NULL;


--
-- Name: frs_customer frs_customer_fk_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer
    ADD CONSTRAINT frs_customer_fk_tenant_id_fkey FOREIGN KEY (fk_tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: frs_customer_user_map frs_customer_user_map_fk_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer_user_map
    ADD CONSTRAINT frs_customer_user_map_fk_customer_id_fkey FOREIGN KEY (fk_customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: frs_customer_user_map frs_customer_user_map_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_customer_user_map
    ADD CONSTRAINT frs_customer_user_map_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: frs_floor frs_floor_fk_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_floor
    ADD CONSTRAINT frs_floor_fk_building_id_fkey FOREIGN KEY (fk_building_id) REFERENCES public.frs_building(pk_building_id) ON DELETE CASCADE;


--
-- Name: frs_nug_box frs_nug_box_fk_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_fk_building_id_fkey FOREIGN KEY (fk_building_id) REFERENCES public.frs_building(pk_building_id) ON DELETE SET NULL;


--
-- Name: frs_nug_box frs_nug_box_fk_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_fk_floor_id_fkey FOREIGN KEY (fk_floor_id) REFERENCES public.frs_floor(pk_floor_id) ON DELETE SET NULL;


--
-- Name: frs_nug_box frs_nug_box_fk_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_nug_box
    ADD CONSTRAINT frs_nug_box_fk_zone_id_fkey FOREIGN KEY (fk_zone_id) REFERENCES public.frs_zone(pk_zone_id) ON DELETE SET NULL;


--
-- Name: frs_site frs_site_fk_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_site
    ADD CONSTRAINT frs_site_fk_customer_id_fkey FOREIGN KEY (fk_customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: frs_telemetry_history frs_telemetry_history_fk_nug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_telemetry_history
    ADD CONSTRAINT frs_telemetry_history_fk_nug_id_fkey FOREIGN KEY (fk_nug_id) REFERENCES public.frs_nug_box(pk_nug_id) ON DELETE CASCADE;


--
-- Name: frs_tenant_user_map frs_tenant_user_map_fk_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant_user_map
    ADD CONSTRAINT frs_tenant_user_map_fk_tenant_id_fkey FOREIGN KEY (fk_tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: frs_tenant_user_map frs_tenant_user_map_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_tenant_user_map
    ADD CONSTRAINT frs_tenant_user_map_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: frs_unit frs_unit_fk_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_unit
    ADD CONSTRAINT frs_unit_fk_site_id_fkey FOREIGN KEY (fk_site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: frs_user_membership frs_user_membership_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: frs_user_membership frs_user_membership_fk_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_fk_user_id_fkey FOREIGN KEY (fk_user_id) REFERENCES public.frs_user(pk_user_id);


--
-- Name: frs_user_membership frs_user_membership_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: frs_user_membership frs_user_membership_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: frs_user_membership frs_user_membership_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_user_membership
    ADD CONSTRAINT frs_user_membership_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: frs_zone frs_zone_fk_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frs_zone
    ADD CONSTRAINT frs_zone_fk_floor_id_fkey FOREIGN KEY (fk_floor_id) REFERENCES public.frs_floor(pk_floor_id) ON DELETE CASCADE;


--
-- Name: hr_department hr_department_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_department
    ADD CONSTRAINT hr_department_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: hr_employee hr_employee_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: hr_employee hr_employee_fk_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_fk_department_id_fkey FOREIGN KEY (fk_department_id) REFERENCES public.hr_department(pk_department_id);


--
-- Name: hr_employee hr_employee_fk_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_fk_shift_id_fkey FOREIGN KEY (fk_shift_id) REFERENCES public.hr_shift(pk_shift_id);


--
-- Name: hr_employee hr_employee_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: hr_employee hr_employee_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: hr_employee hr_employee_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_employee
    ADD CONSTRAINT hr_employee_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- Name: hr_leave_request hr_leave_request_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request
    ADD CONSTRAINT hr_leave_request_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.frs_user(pk_user_id);


--
-- Name: hr_leave_request hr_leave_request_fk_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request
    ADD CONSTRAINT hr_leave_request_fk_employee_id_fkey FOREIGN KEY (fk_employee_id) REFERENCES public.hr_employee(pk_employee_id);


--
-- Name: hr_leave_request hr_leave_request_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_leave_request
    ADD CONSTRAINT hr_leave_request_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: hr_shift hr_shift_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_shift
    ADD CONSTRAINT hr_shift_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: system_alert system_alert_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.frs_customer(pk_customer_id);


--
-- Name: system_alert system_alert_fk_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_fk_device_id_fkey FOREIGN KEY (fk_device_id) REFERENCES public.facility_device(pk_device_id);


--
-- Name: system_alert system_alert_fk_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_fk_employee_id_fkey FOREIGN KEY (fk_employee_id) REFERENCES public.hr_employee(pk_employee_id);


--
-- Name: system_alert system_alert_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.frs_site(pk_site_id);


--
-- Name: system_alert system_alert_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.frs_tenant(pk_tenant_id);


--
-- Name: system_alert system_alert_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alert
    ADD CONSTRAINT system_alert_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.frs_unit(pk_unit_id);


--
-- PostgreSQL database dump complete
--

